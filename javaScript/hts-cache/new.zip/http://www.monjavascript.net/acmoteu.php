<html>
<head>
<title>Mon JavaScript - moteurs et referencements</title>
<meta name="Description" lang="fr" content="Webmasters, Mon JavaScript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">

<meta name="author" content="monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
<script>
<!--
var monsite = "monjavascript.net"
document.write(unescape("%3Cscript%20language%3D%22JavaScript%22%3E%0D%0A%3C%21--%0D%0A//PLF-http%3A//www.monjavascript.net/%0D%0A%0D%0Afunction%20multi%28form%29%7B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20rech%20%3D%20form.moteur.options%5Bform.moteur.selectedIndex%5D.value%09%09%09%09%09%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20switch%28rech%29%7B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20case%20%221%22%20%3A%0D%0A%09%09%09%09%09window.open%28%27http%3A//www.google.com/search%3Fq%3D%27+form.q.value+%27%26btnG%3DRecherche+Google%26hl%3Dfr%26lr%3Dlang_fr%27%2C%27%27%2C%27toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%27%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%220%22%3A%0D%0A%09var%20mess%3D%22Vous%20n%27avez%20pas%20s%E9lectionn%E9%20de%20moteur%20%21%22%0D%0A%20%09alert%28mess%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%221%22%3A%0D%0A%09window.open%28%20%22http%3A//www.google.com/search%3Fq%3D%22+form.q.value+%22%26btnG%3DRecherche+Google%26hl%3Dfr%26lr%3Dlang_fr%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%222%22%3A%0D%0A%09window.open%28%20%22http%3A//www.alltheweb.com/search%3Fquery%3D%22+form.q.value+%22%26cat%3Dweb%26charset%3Dutf-8%26submit%3DWeb+Search%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%0D%0A%09%09%09%09%20%20%20%20break%3B%0D%0Acase%20%223%22%3A%0D%0A%09window.open%28%20%22http%3A//www.altavista.com/cgi-bin/query%3Fpg%3Dq%26what%3Dweb%26fmt%3Dd%26q%3D%22+form.q.value%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%224%22%3A%0D%0A%09window.open%28%20%22http%3A//www.recherche.aol.fr/rech%3Fenc%3Diso%26q%3D%22+form.q.value+%22%26v%3D0%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%225%22%3A%0D%0A%09window.open%28%20%22http%3A//fr.web.caloga.com/html/search_result.php%3Fn%3D30%26sel%3Ds%26lr%3Dlang_fr%26q%3D%22+form.q.value%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%226%22%3A%0D%0A%09window.open%28%20%22http%3A//search.dmoz.org/cgi-bin/search%3Fsearch%3D%22+form.q.value+%22%26cat%3DWorld%252FFran%2525c3%2525a7ais%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%227%22%3A%0D%0A%09window.open%28%20%22http%3A//search-dyn.excite.fr/search.php%3Fkey%3D%22+form.q.value+%22%26submit%3DRecherche+Excite%26external%3D1%26language%3Dfr%26collection%3Dweb%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%228%22%3A%0D%0A%09window.open%28%20%22http%3A//recherche.francite.com/cgi-win/recherche.exe%3Fbd%3Dfrancite%26name%3D%22+form.q.value%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%229%22%3A%0D%0A%09window.open%28%20%22http%3A//hotbot.lycos.com/%3FMT%3D%22+form.q.value+%22%26SM%3DMC%26DV%3D0%26LG%3Dany%26DC%3D10%26DE%3D2%26BT%3DH%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2210%22%3A%0D%0A%09window.open%28%20%22http%3A//www.fr.lycos.de/cgi-bin/pursuit%3Fmatchmode%3Dand%26lang%3Dfr%26mtemp%3Dmain.sites%26query%3D%22+form.q.value+%22%26cat%3Dlycos%26x%3D19%26y%3D10%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2211%22%3A%0D%0A%09window.open%28%20%22http%3A//search.metacrawler.com/texis/search%3Fbrand%3Dmetacrawler%26q%3D%22+form.q.value+%22%26redirect%3D%26top%3D1%26method%3D0%26rpp%3D20%26hpe%3D10%26region%3D0%26timeout%3D0%26sort%3D0%26theme%3Dclassic%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2212%22%3A%0D%0A%09window.open%28%20%22http%3A//search.msn.fr/results.asp%3Fq%3D%22+form.q.value+%22%26origq%3D%26RS%3DCHECKED%26FORM%3DSMCRT%26v%3D1%26cfg%3DSMCINITIAL%26nosp%3D0%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2213%22%3A%0D%0A%09window.open%28%20%22http%3A//rechercher.nomade.tiscali.fr/recherche.asp%3FMT%3D%22+form.q.value+%22%26s%22+form.q.value+%22%26opt%3D0%26x%3D43%26y%3D8%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2214%22%3A%0D%0A%09window.open%28%20%22http%3A//www.overture.com/d/search/%3Ftype%3Dhome%26mkt%3Dfr%26tm%3D1%26Keywords%3D%22+form.q.value%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2215%22%3A%0D%0A%09window.open%28%20%22http%3A//www.sharelook.fr/sldb/SLDB_db.php%3Fkeyword%3D%22+form.q.value+%22%26suche_starten%3DRecherche%26seite%3D700001%26template%3Dfr_suchen%26next_results%3D0%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%09%0D%0Acase%20%2216%22%3A%0D%0A%09window.open%28%20%22http%3A//recherche.toile.qc.ca/cgi-bin/recherche%3Flang%3Dfr%26query%3D%22+form.q.value%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2217%22%3A%0D%0A%09window.open%28%20%22http%3A//www.trouvez.com/cgi-bin/cgsearch/cgsearch.cgi%3Fquery%3D%22+form.q.value%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2218%22%3A%0D%0A%09window.open%28%20%22http%3A//r.voila.fr/se%3Fdblg%3Dfr%26ctx%3Dvoila%26lg%3DFR%26sev%3D2%26ref%3Dext%26db%3Dweb%26kw%3D%22+form.q.value+%22%26%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2219%22%3A%0D%0A%09window.open%28%20%22http%3A//fr.search.yahoo.com/search/fr%3Fp%3D%22+form.q.value+%22%26y%3Dy%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2220%22%3A%0D%0A%09window.open%28%20%22http%3A//search.yahoo.com/bin/search%3Fp%3D%22+form.q.value%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2221%22%3A%0D%0A%09window.open%28%20%22http%3A//www.google.fr/search%3Flr%3D%26cr%3D%26q%3D%22+form.q.value+%22%26hl%3Dfr%26ie%3DUTF-8%26oe%3DUTF-8%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2222%22%3A%0D%0A%09window.open%28%20%22http%3A//fr.altavista.com/image/results%3Fpg%3Dq%26stype%3Dsimage%26imgset%3D2%26q%3D%22+form.q.value+%22%26avkw%3Dxytx%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%09%0D%0Acase%20%2223%22%3A%0D%0A%09window.open%28%20%22http%3A//www.alltheweb.com/search%3Fquery%3D%22+form.q.value+%22%26cat%3Dmp3%26charset%3Dutf-8%26submit%3DMP3+Search%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0Acase%20%2224%22%3A%0D%0A%09window.open%28%20%22http%3A//www.google.com/search%3Fhl%3Dfr%26ie%3DUTF-8%26oe%3DUTF-8%26q%3D%22+form.q.value%20+%22+site%253A%22+monsite+%22%26btnG%3DRecherche+Google%26lr%3D%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%09%09%09%09%09%0D%0Acase%20%2225%22%3A%0D%0A%09window.open%28%20%22http%3A//www.monjavascript.net/moteur.php%22%2C%22%22%2C%22toolbar%3Dyes%2Clocation%3Dyes%2Cstatus%3Dyes%2Cmenubar%3Dyes%2Cscrollbars%3Dyes%2Cresizable%3Dyes%22%29%3B%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20break%3B%0D%0A%09%0D%0A%7D%7D%0D%0A//--%3E%0D%0A%3C/script%3E"));
//-->
</script>
</head>
<body bgcolor="#FFFFFF" >
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
		
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/cours_jjs/index.php" >Cours de javascript</a><br>
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="center"> 
              <p align="center"><b><font color="#990066" size="+2">Moteurs de 
                recherches</font></b> <br>
              </p>
              <form>
                <div align="center"> 
                  <table border="0" cellpadding="5" cellspacing="0" bgcolor="#9966FF" width="560">
                    <tr> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                    <tr valign="middle"> 
                      <td colspan="2" nowrap><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><strong>Mots 
                        &agrave; Rechercher : </strong> </font></td>
                      <td><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                        <input type="text" name="q" size="35">
                        </font></td>
                      <td> 
                        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFFFF"><a href="http://www.monjavascript.net/moteur.php" target="_blank">Ce 
                          Service sur Votre Site</a></font></div>
                      </td>
                    </tr>
                    <tr valign="middle"> 
                      <td colspan="2"> 
                        <div align="center"> 
                          <div align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><strong>Rechercher 
                            sur :</strong></font></div>
                        </div>
                      </td>
                      <td> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                        <script>
<!--
document.write(unescape("%3Cscript%20language%3D%22JavaScript%22%3E%0D%0A%09%09%09%09%09%09%3C%21--%0D%0A%09%09%09%09%09%09document.write%28%27%3Cselect%20name%3D%22moteur%22%3E%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20selected%20value%3D%220%22%3E---%20Choisisez%20votre%20moteur%20---%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%220%22%3E%20%27+%0D%0A%09%09%09%09%09%09%20%20%27%3Coption%20value%3D%2225%22%3Ece%20moteur%20sur%20votre%20site%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%221%22%3EGoogle%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%222%22%3EAll%20the%20Web%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%223%22%3EAlta%20Vista%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%224%22%3EAOL.FR%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%225%22%3ECaloga.com%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%226%22%3Edmoz%27+%20%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%227%22%3EExcite%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%228%22%3EFrancit%E9%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%229%22%3EHotBot%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2210%22%3ELycos%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2211%22%3EMetacrawler%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2212%22%3EMSN%20Search%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2213%22%3ENomade%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2214%22%3EOverture%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2215%22%3EShareLook%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2216%22%3ELa%20toile%20du%20quebec%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2217%22%3ETrouvez.com%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2218%22%3EVoila%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2219%22%3EYahoo%20France%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2220%22%3EYahoo%20international%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2221%22%3EGoogle%20international%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2222%22%3EAlta%20Vista%20Image%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3Coption%20value%3D%2223%22%3EAll%20the%20Web%20MP3%20%27+%0D%0A%09%09%09%09%09%09%20%20%27%3Coption%20value%3D%2224%22%3ESur%20mon%20site%20avec%20Google%27+%0D%0A%09%09%09%09%09%09%20%20%27%3Coption%20value%3D%2225%22%3EService%20Je%20JavaScript.net%20%27+%0D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%27%3C/select%3E%27%29%0D%0A%09%09%09%09%09%09//--%3E%0D%0A%09%09%09%09%09%09%3C/script%3E"));
//-->
</script>
                        </font></td>
                      <td> 
                        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                          <input onClick=multi(this.form) type=button value="Rechercher" name=button>
                          </font></div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
                </div>
              </form>
              <br>
              <table width="570" border="0" align="center">
                <tr> 
                  <td valign="top" width="33%"> 
                    <table width="100%" border="0">
                      <tr> 
                        <td height="20"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><img src="im/fleche.gif" width="11" height="11"><a href="http://www.google.fr/" target="_blank">Google</a> 
                          C'est le moteur de recherche simple et rapide par lequel 
                          nombreux d'entre vous arrivent sur Mon javascript<br>
                          <img src="im/fleche.gif" width="11" height="11"><a href="http://www.alltheweb.com/" target="_blank">Alltheweb.com</a> 
                          Moteur de recherche rapide (Sites, Photos, MP3, Video, 
                          FTP) </font></td>
                      </tr>
                      <tr>
                        <td height="20">                          <div align="center">
                            <p><b><a href="/acmoteujjs.php"><font size="2">Rechercher
                                    sur<br>
        Mon javascript</font></a></b></p>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td height="20"><div align="center"><br>
  					</tr>
                    </table>
                  </td>
                  <td valign="top" width="33%"> 
                    <table width="100%" border="0">
                      <tr> 
                        <td height="20"> 
                          <div align="center"><b><font color="#990066"><br>
                            <!--Code � ins�rer jjspub --><br><br><img src="http://www.monjavascript.net/im/mjs-logo.gif" width="90" height="85" border="0" alt="Mon JavaScript  http://www.monjavascript.net">
<br><br><br><br>
<!--Code � ins�rer jjspub -->
                            </font></b></div>
                        </td>
                      </tr>
                      <tr>
                        <td height="20">
                          <div align="center">
                            <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><a href="recheche.php">Moteur
                                    de recherches<br>
        Pres de 3000 JavaScripts sur le Web</a></b></font></p>
                          </div>
                        </td>
                      </tr>
                    </table>
                  </td>
                  <td valign="top" width="33%"> 
                    <table width="100%" border="0">
                      <tr>
                        <td height="20">
                          <div align="center"><b><font color="#990066">R&eacute;f&eacute;rencement
                                Automatique Gratuit</font></b></div>
                        </td>
                      </tr>
                      <tr>
                        <td height="20"><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="im/fleche.gif" width="11" height="11"><a href="http://www.abondance.com/audit/referencement.html" target="_blank"> Abondance
                              R&eacute;f&eacute;rencement automatique de site
                              Web</a><br>
                                  </font></td>
                      </tr>
                      <tr>
                        <td height="20">
                          <div align="center">
                            <p><b><font color="#990066">R&eacute;f&eacute;rencement
                                  Manuel<br>
        (la meilleure solution)</font></b></p>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td height="20"><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="http://www.google.fr/intl/fr/addurl.html" target="_blank">Google.fr</a> - <a href="http://www.alltheweb.com/add_url.php" target="_blank">Alltheweb.com</a><br>
							  <a href="http://guide-voila.search.ke.voila.fr/Soumission/" target="_blank">Voila</a> - <br>
                              <a target=_blank href="http://addurl.altavista.com/addurl/new">Altavista</a> - <a href="http://fr.docs.yahoo.com/info/ajouter.html" target="_blank">Yahou</a> <br>
                              <a target=_blank href="http://dmoz.org/World/Fran%C3%A7ais/add.html">dmoz </a> - <a target=_blank href="http://categorie.francite.com/fr/categories.asp">Francit&eacute;</a><br>
                              <a target=_blank href="http://www.fr.abacho.com/anmelden.html">Abacho</a> - <a target=_blank href="http://www.abrahamsearch.com/inserimento.php">Abraham</a><br>
                              <a target=_blank href="http://www.entireweb.com/eng/basic/">Entireweb</a> - <a target=_blank href="http://www.exactseek.com/add.html">Exactseek</a> <br>
                              <a target=_blank href="http://www.searchit.com/addurl.htm">Searchit</a><br>
                                   <a target=_blank href="http://search.myglobalwebsite.com/moses_addurl.html">My
                                    Global Website</a><br>
                                          <a target=_blank href="http://www.splatsearch.com/submit.html">Splat</a> - <a target=_blank href="http://www.surfgopher.com/addurl.htm">Surfgopher</a><br>
                                          </font></td>
                      </tr>
                      <tr>
                        <td height="20">&nbsp;</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              <div align="center">                
                <p><br>
                    <!--Code � ins�rer jjspub -->
                    <script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
                    <!--Code � ins�rer jjspub -->
                    </p>
                <p><br>                
                      <font size="+1">                </font>
                 </p>
              </div>
                  <!-- SiteSearch Google -->
                  <form method="get" action="http://www.google.fr/custom" target="google_window">
                    <table border="0" bgcolor="#9966FF">
                      <tr>
                        <td nowrap="nowrap" valign="top" align="left" height="32"> </td>
                        <td nowrap="nowrap">
                          <input type="hidden" name="domains" value="www.monjavascript.net">
                          <input name="q" type="text" id="q" value="" size="30" maxlength="255">
                        </td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td nowrap="nowrap">
                          <table>
                            <tr>
                              <td>
                                <input type="radio" name="sitesearch" value="" checked="checked">
                                <font size="-1" color="#000000">Web</font> </td>
                              <td>
                                <input type="radio" name="sitesearch" value="www.monjavascript.net">
                                <font size="-1" color="#000000">www.monjavascript.net</font> </td>
                            </tr>
                          </table>
                          <input type="submit" name="sa" value="Recherche Google">
                          <input type="hidden" name="client" value="pub-2085185646476169">
                          <input type="hidden" name="forid" value="1">
                          <input type="hidden" name="ie" value="ISO-8859-1">
                          <input type="hidden" name="oe" value="ISO-8859-1">
                          <input type="hidden" name="cof" value="GALT:#008000;GL:1;DIV:#9966FF;VLC:663399;AH:center;BGC:FFFFFF;LBGC:9966FF;ALC:0000FF;LC:0000FF;T:000000;GFNT:0000FF;GIMP:0000FF;LH:50;LW:158;L:http://www.monjavascript.net/im/jjs-net2.gif;S:http://www.monjavascript.net/;FORID:1">
                          <input type="hidden" name="hl" value="fr">
                        </td>
                      </tr>
                    </table>
                  </form>
                  <!-- SiteSearch Google -->
                  <p>&nbsp;</p>
              <p>
              <form action="http://www.alltheweb.com/search" method="get" target="_blank">
                <p><img src="http://www.alltheweb.com/g/atwlogo_small.gif"
width="94" height="16" alt="AllTheWeb"> 
                  <input name="query" size="30">
                  <input name="cat" type="hidden" value="web">
                  <input name="charset" type="hidden" value="utf-8">
                  <input type="submit" value="Web Search" name="submit">
                </p>
              </form>
              <form action="http://www.alltheweb.com/search" method="get" target="_blank">
                <p><img src="http://www.alltheweb.com/g/atwlogo_small.gif"
width="94" height="16" alt="AllTheWeb"> 
                  <input name="query" size="30">
                  <input name="cat" type="hidden" value="mp3">
                  <input name="charset" type="hidden" value="utf-8">
                  <input type="submit" value="MP3 Search" name="submit">
                </p>
              </form>
              <p>&nbsp;</p>
              <p><br>
              </p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>