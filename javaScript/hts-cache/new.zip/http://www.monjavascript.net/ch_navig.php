<html>
<head>
<title>Mon JavaScript - choix navigateur</title>
<meta name="Description" lang="fr" content="Webmasters, Mon JavaScript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">

<meta name="author" content="monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

</head>

<body>
<p align="center"><b><font size="6" color="#0000FF">SCRIPT CHOIX DU NAVIGATEUR</font></b></p>
<script LANGUAGE="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
var navig = navigator.appName

switch(navig) {
	case "Microsoft Internet Explorer" :
	page=("ch_navig/page-mie.php");
	break;
	case "Netscape" :
	page=("ch_navig/page-net.php");
	break;
	default :
	page=("ch_navig/page-def.php");//autres navigateurs
}
window.location=page
//-->
</script>
</body>
</html>
