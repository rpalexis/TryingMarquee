<html>
<head>
<title>Mon javascript - Cours de javascript</title>
<meta name="Description" lang="fr" content="Webmasters, Mon javascript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="Monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF- http://www.Monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
</head>
<body bgcolor="#FFFFFF">
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
	<div align="center"><a href="index.php">Cours de Javascript</a><a href="index.php">
</a></div>
<p>  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js01intro.php">Introduction au Javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js02implant.php">Implantation du code</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js03var.php">Variables javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js04tab.php">Tableaux javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js05char.php">Cha&icirc;ne de caract&egrave;res</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js06even.php">&Eacute;v&eacute;nements
  javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js07oper.php">Op&eacute;rateurs</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js08cond.php">Structures conditionnelles</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js09fonc.php">Fonctions</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js10meth.php">M&eacute;thodes</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js11dial.php">Bo&icirc;tes
  de dialogue</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js12objet.php">La notion d'objet</a><br>
  <font color="#CCCCCC"><strong>Objets de Javascript</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js13noyau.php">Objets du noyau</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js14array.php">Objet Array</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js15boolean.php">Objet Boolean</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js16date.php">Objet Date</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js17math.php">Objet Math</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js18regexp.php">Objet RegExp</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js19string.php">Objet String</a><br>
  <font color="#CCCCCC"><strong>Objets du navigateur</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js20objets.php">Pr&eacute;sentation
  des objets</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js21window.php">Objet window</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js22navig.php">Objet navigator</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js23history.php">Objet history</a></p>
<p align="center"><font color="#FFFFFF">- - - - - - - -</font> </p> 

	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td colspan="2" valign="top" bordercolor="#E8E8E8" bgcolor="#CC99FF"> 
            <div align="left"> 
              <h2 align="center"> 
              Les variables</h2>
              <table width="300" border="0" align="right">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js02implant.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js04tab.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>
              <h2>&nbsp;</h2>
              <h2><br>
              <a name="variables" class="ancre"></a>Le concept de variable</h2>
              <p align="justify">Une variable est un objet rep&eacute;r&eacute; par
                son nom, pouvant contenir des donn&eacute;es, qui pourront &ecirc;tre
                modifi&eacute;es lors de l'ex&eacute;cution du programme.
              <p align="justify">En Javascript, les noms de variables peuvent &ecirc;tre
                aussi long que l'on d&eacute;sire, mais doivent r&eacute;pondre &agrave; certains
                crit&egrave;res&nbsp;:
              <ul>
                <li>un nom de variable doit commencer par une lettre (majuscule
                  ou minuscule) ou un &quot;_&quot;</li>
                <li>un nom de variables peut comporter des lettres, des chiffres
                  et les caract&egrave;res _ et & (les espaces ne sont pas autoris&eacute;s!)
                <li>Les noms de variables ne peuvent pas &ecirc;tre les noms
                  suivants (qui sont des noms r&eacute;serv&eacute;s)&nbsp;:
                    <ul>
                      <li>abstract</li>
                      <li>boolean break byte</li>
                      <li>case catch char class const continue</li>
                      <li>debugger default delete do double</li>
                      <li>else export extends</li>
                      <li>false final finally float for function</li>
                      <li>goto</li>
                      <li>if, implements, import, in, infinity, instanceof, int,
                        interface</li>
                      <li>label, long</li>
                      <li>native, new, null</li>
                      <li>package, private, protected, public</li>
                      <li>return</li>
                      <li>short, static, super, switch, synchronized</li>
                      <li>this, throw, throws, transient, true, try, typeof</li>
                      <li>var, void, volatile</li>
                      <li>while, with</li>
                      <li>sont &eacute;galement consid&eacute;r&eacute;s comme
                        mots r&eacute;serv&eacute;s le nom des <a href="js12objet.php">objets
                        Javascript</a></li>
                    </ul>
                </li>
              </ul>
              <p align="justify">
              <table class="ccm">
                <tr>
                  <th>Nom de variable correct</th>
                  <th>Nom de variable incorrect</th>
                  <th>Raison</th>
                </tr>
                <tr>
                  <td>Variable</td>
                  <td>Nom de Variable </td>
                  <td>comporte des espaces</td>
                </tr>
                <tr>
                  <td>Nom_De_Variable</td>
                  <td>123Nom_De_Variable </td>
                  <td>commence par un chiffre</td>
                </tr>
                <tr>
                  <td>nom_de_variable</td>
                  <td>toto@mailcity.com </td>
                  <td>caract&egrave;re sp&eacute;cial @</td>
                </tr>
                <tr>
                  <td>nom_de_variable_123</td>
                  <td>Nom-de-variable </td>
                  <td>signe - interdit</td>
                </tr>
                <tr>
                  <td>_707</td>
                  <td>transient </td>
                  <td>nom r&eacute;serv&eacute;</td>
                </tr>
              </table>
              <p align="justify">              
              <table border="0">
                <tr>
                  <td> <img src="images/warning.gif" alt="" width="47" height="39"> </td>
                  <td> Les noms de variables sont sensibles &agrave; la casse
                    (le Javascript fait la diff&eacute;rence entre un nom en
                    majuscule et un nom en minuscules), il faut donc veiller &agrave; utiliser
                    des noms comportant la m&ecirc;me casse! </td>
                </tr>
              </table>
              <a name="declaration" class="ancre"></a>
              <h2>La d&eacute;claration de variables</h2>
              <p align="justify">Le Javascript &eacute;tant tr&egrave;s souple
                au niveau de l'&eacute;criture (&agrave; double-tranchant car
                il laisse passer des erreurs...), la d&eacute;claration des variables
                peut se faire de deux fa&ccedil;ons&nbsp;:
              <ul>
                <li>soit de fa&ccedil;on explicite, en faisant pr&eacute;c&eacute;der
                  la variable du mot cl&eacute; <i>var</i> qui permet d'indiquer
                  de fa&ccedil;on rigoureuse qu'il s'agit d'une variable&nbsp;:
                    <pre class="Code"> var chaine= &quot;bonjour&quot;</pre>
                </li>
                <li>soit de fa&ccedil;on implicite, en laissant le navigateur
                  d&eacute;terminer qu'il s'agit d'une d&eacute;claration de
                  variable. Pour d&eacute;clarer implicitement une variable,
                  il suffit d'&eacute;crire le nom de la variable suivie du caract&egrave;re <i>=</i> et
                  de la valeur &agrave; affecter&nbsp;:
    <pre class="Code"> chaine= &quot;bonjour&quot;</pre>
                </li>
              </ul>
              M&ecirc;me si une d&eacute;claration implicite est tout &agrave; fait
              reconnue par le navigateur, il est
plus rigoureux de d&eacute;clarer les variables de fa&ccedil;on explicite avec
le mot <i>var</i>.
<p align="justify">Voici un exemple dans lequel deux variables sont d&eacute;clar&eacute;es&nbsp;:
<pre class="Code">&lt;SCRIPT language="Javascript"&gt;
&lt;!--
var MaVariable;
var MaVariable2 = 3;
MaVariable = 2;
document.write(MaVariable*MaVariable2);
//--&gt;
&lt;/SCRIPT&gt;</pre>
<div align="center"><a name="portee" class="ancre"></a>
      <!--Code � ins�rer jjspub -->
      <script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
      <!--Code � ins�rer jjspub -->
    </div>
<h2>Port&eacute;e (visibilit&eacute;) des variables</h2>
<p align="justify">Selon l'endroit o&ugrave; une variable est d&eacute;clar&eacute;e,
  celle-ci pourra &ecirc;tre accessible (visible) de partout dans le script ou
  bien uniquement dans une portion confin&eacute;e du code, on parle de &laquo;&nbsp;<b>port&eacute;e</b>&nbsp;&raquo; d'une
  variable.
<p align="justify">Lorsqu'une variable est d&eacute;clar&eacute;e sans le mot
  cl&eacute; <i>var</i>, c'est-&agrave;-dire <b>de fa&ccedil;on implicite</b>,
  elle est accessible de partout dans le script (n'importe quelle fonction du
  script peut faire appel &agrave; cette variable). On parle alors de <b>variable
  globale</b>
<p align="justify">La port&eacute;e d'une variable d&eacute;clar&eacute;e <b>de
    fa&ccedil;on explicite</b> (pr&eacute;c&eacute;d&eacute;e du mot-cl&eacute; <i>var</i>),
    d&eacute;pend de l'endroit o&ugrave; elle est d&eacute;clar&eacute;e.
<ul>
  <li>Une variable d�clar�e au d�but du script, avant toute fonction, sera globale.
    Elle peut �tre utilis�e n'importe o� dans le script&nbsp;.</li>
  <li>Une variable d�clar�e explicitement dans une fonction aura une port�e limit�e � cette
    seule fonction, c'est-&agrave;-dire qu'elle est inutilisable ailleurs. On
    parle alors de &laquo;&nbsp;<b>variable locale</b>&nbsp;&raquo;.</li>
</ul>
<p align="justify">Voici deux exemples permettant de l'illustrer&nbsp;:
<pre class="Code">&lt;SCRIPT language="Javascript"&gt;
&lt;!--
var a = 12;
var b = 4;

function MultipliePar2(b) {
   var a = b * 2;
   return a;
}
document.write("Le double de ",b," est ",MultipliePar2(b));
document.write("La valeur de a est ",a);
//--&gt;
&lt;/SCRIPT&gt;</pre>
<p align="justify">Dans l'exemple ci-dessus, la variable <i>a</i> est d&eacute;clar&eacute;e
  explicitement en d&eacute;but de script, ainsi que dans la fonction. Voici
  ce qu'affiche ce script&nbsp;:
<pre class="Code">Le double de 4 est 8
La valeur de a est 12</pre>
<p align="justify">Voici un autre exemple dans lequel <i>a</i> est d&eacute;clar&eacute;e
  implicitement dans la fonction&nbsp;:
<pre class="Code">&lt;SCRIPT language="Javascript"&gt;
&lt;!--
var a = 12;
var b = 4;

function MultipliePar2(b) {
   a = b * 2;
   return a;
}
document.write("Le double de ",b," est ",MultipliePar2(b));
document.write("La valeur de a est ",a);
//--&gt;
&lt;/SCRIPT&gt;</pre>
<p align="justify">Voici ce qu'affiche ce script&nbsp;:
<pre class="Code">Le double de 4 est 8
La valeur de a est 8</pre>
<p align="justify">
<table border="0">
  <tr>
    <td><img src="images/warning.gif" width="47" height="39"></td>
    <td>Ces exemples montrent la n&eacute;cessit&eacute; de d&eacute;clarer syst&eacute;matiquement
      des nouvelles variables avec le mot cl&eacute; <i>var</i></td>
  </tr>
</table>
<a name="types" class="ancre"></a>
<h2>Les types de donn&eacute;es dans les variables</h2>
<p align="justify">En Javascript il n'est pas n&eacute;cessaire de d&eacute;clarer
  le type des variables, contrairement &agrave; des langages &eacute;volu&eacute;s
  tels que le langage C ou le Java pour
  lesquels il faut pr&eacute;ciser s'il s'agit d'entier (<i>int</i>), de nombre &agrave; virgule
  flottante (<i>float</i>) ou de caract&egrave;res (<i>char</i>).
<p align="justify">En fait, le Javascript n'autorise la manipulation que de 4
  types de donn&eacute;es&nbsp;:
<ul>
  <li>des <b>nombres</b>: entiers ou &agrave; virgules</li>
  <li>des <b>cha&icirc;nes de caract&egrave;res</b> (string): une suite de caract&egrave;res</li>
  <li>des <b>bool&eacute;ens</b>: des variables permettant de v&eacute;rifier
    une condition. Les boll&eacute;ens peuvent prendre deux &eacute;tats&nbsp;:
    <ul>
      <li><i>true</i> : si le r&eacute;sultat est vrai&nbsp;;</li>
      <li><i>false</i> : lors d'un r&eacute;sultat faux.</li>
    </ul>
  </li>
  <li>des <b>variables de type <i>null</i></b>: un mot caract&egrave;ristique
    pour indiquer que la variable ne contient aucune donn&eacute;e.</li>
</ul>
<a name="entier" class="ancre"></a>
<h3>Nombre entier</h3>
<p align="justify">Un nombre entier est un nombre sans virgule, qui peut &ecirc;tre
  exprim&eacute; dans diff&eacute;rentes bases&nbsp;:
<ul>
  <li>Base d&eacute;cimale: L'entier est repr&eacute;sent&eacute; par
    une suite de chiffre unitaires (de 0 &agrave; 9) ne devant pas commencer
    par le chiffre 0</li>
  <li>Base hexad&eacute;cimale: L'entier est
    repr&eacute;sent&eacute; par une suite d'unit&eacute;s (de 0 &agrave; 9 ou
    de A &agrave; F (ou a &agrave; f)) devant commencer par <i>0x</i> ou <i>0X</i></li>
  <li>Base octale: L'entier est repr&eacute;sent&eacute; par
    une suite d'unit&eacute;s (incluant uniquement des chiffres de 0 &agrave; 7)
    devant commencer par <i>0</i></li>
</ul>
<p align="justify">
<table border="0">
  <tr>
    <td><img src="images/warning.gif" width="47" height="39"></td>
    <td>Les angles dans Javascript sont toujours exprim&eacute;s en radians (lorsque
      l'on utilise par exemple <a href="js17math.php">les m&eacute;thodes trigonom&eacute;riques
      de l'objet Math</a>.</td>
  </tr>
</table>
<a name="float" class="ancre"></a>
<h3>Nombre &agrave; virgule (<i>float</i>)</h3>
<p align="justify">Un nombre &agrave; virgule flottante est un nombre &agrave; virgule,
  il peut toutefois &ecirc;tre repr&eacute;sent&eacute; de diff&eacute;rentes
  fa&ccedil;ons&nbsp;:
<ul>
  <li>un entier d&eacute;cimal: 895</li>
  <li>un nombre comportant un point (et non une virgule): 845.32</li>
  <li>une fraction: 27/11</li>
  <li>un nombre exponentiel, c'est-&agrave;-dire un nombre (&eacute;ventuellement &agrave; virgule)
    suivi de la lettre <i>e</i> (ou <i>E</i>), puis d'un entier correspondant &agrave; la
    puissance de 10 (sign&eacute; ou non, c'est-&agrave;-dire pr&eacute;c&eacute;d&eacute; d'un
    + ou d'un -)
    <pre class="Code">var a = 2.75e-2;
var b = 35.8E+10;
var c = .25e-2;</pre>
  </li>
</ul>
<a name="chaine" class="ancre"></a>
<h3>Cha&icirc;ne de caract&egrave;res (<i>string</i>)</h3>
<p align="justify">Une cha&icirc;ne de caract&egrave;re est, comme son nom l'indique,
  une suite de caract&egrave;res. Les cha&icirc;nes de caract&egrave;res sont
  trait&eacute;es en d&eacute;tail dans <a href="js19string.php">l'article consacr&eacute; &agrave; ce
  sujet</a>. Voici deux fa&ccedil;ons dont une variable peut &ecirc;tre d&eacute;clar&eacute; pour &ecirc;tre
  interpr&eacute;t&eacute;e comme une cha&icirc;ne de caract&egrave;re&nbsp;:
<pre class="Code">var a = "Bonjour";
var b = 'Au revoir !';</pre>
<a name="booleens" class="ancre"></a>
<h3>Bool&eacute;ens (<i>booleans</i>)</h3>
<p align="justify">Un bool&eacute;en est une variable sp&eacute;ciale servant &agrave; &eacute;valuer
  une condition, il peut donc poss&eacute;der deux valeurs&nbsp;:
<ul>
  <li><i>Vrai</i> (en anglais <i>True</i>) : repr&eacute;sent&eacute; par la
    valeur 1</li>
  <li><i>Faux</i> (en anglais <i>False</i>) : repr&eacute;sent&eacute; par la
    valeur 0</li>
</ul>
<a name="conversion" class="ancre"></a>
<h2>Conversions de types</h2>
<p align="justify">M&ecirc;me si Javascript g&egrave;re de fa&ccedil;on transparente
  les changements de type des variables, il est parfois n&eacute;cessaire de
  forcer la conversion du type. Ainsi Javascript fournit deux fonctions natives
  permettant de convertir le type des variables pass&eacute;es en param&egrave;tre&nbsp;:
<ul>
  <li><a href="#parseint">parseInt()</a> permet de convertir une variable en
    nombre
  <li><a href="#parsefloat">parseFloat()</a> permet de convertir une variable
    en nombre d&eacute;cimal
</ul>
<a name="parseint" class="ancre"></a>
<h3>parseInt()</h3>
<p align="justify">La fonction <i>parseInt()</i> permet de convertir une variable
  pass&eacute;e en param&egrave;tre (soit en tant que cha&icirc;ne de caract&egrave;re,
  soit en tant que nombre dans la base pr&eacute;cis&eacute;e en second param&egrave;tre)
  et le convertit en nombre entier (en base d&eacute;cimale).La syntaxe de la
  fonction <i>parseInt()</i> est la suivante&nbsp;:
<pre class="Code">parseInt(chaine[, base]);</pre>
<p align="justify">Pour que la fonction <i>parseInt()</i> retourne un entier,
  la chaine pass&eacute;e en param&egrave;tre doit commencer par des caract&egrave;re
  valides c'est-&agrave;-dire les chiffres [0-9] ou le pr&eacute;fixe hexad&eacute;cimal <i>0x</i>,
  et/ou les caract&egrave;res <i>+, -, E</i> et <i>e</i>. Dans le cas contraire
  la fonction <i>parseInt()</i> retournera la valeur <i>NaN</i> (<i>Not a Number</i>).
<p align="justify">
<table border="0">
  <tr>
    <td><img src="images/warning.gif" width="47" height="39"></td>
    <td>Dans les navigateurs supportant une version de Javascript ant&eacute;rieure &agrave; la
      version 1.1, le chiffre 0 sera renvoy&eacute;.</td>
  </tr>
</table>
<p align="justify">Si les caract&egrave;res suivants ne sont pas valides, ils
  seront ignor&eacute;s par la fonction <i>parseInt()</i>. Si la cha&icirc;ne
  pass&eacute;e en param&egrave;tre repr&eacute;sente un nombre poss&eacute;dant
  une partie litt&eacute;rale, celle-ci sera tronqu&eacute;e.
<p align="justify">Le param&egrave;tre <i>base</i> est un entier facultatif permettant
  de pr&eacute;ciser la base devant &ecirc;tre
  utilis&eacute;e pour interpr&eacute;ter la cha&icirc;ne. Il vaut 10 par d&eacute;faut
  . Si le param&egrave;tre <i>base</i> n'est pas pr&eacute;cis&eacute; (ou s'il
  est fix&eacute; &agrave; la valeur 10), la base utilis&eacute;e sera la base
  d&eacute;cimale; la base sera 16 si la cha&icirc;ne commence par <i>0x</i>,
  elle sera 8 si la cha&icirc;ne commence par <i>0</i>.
<p align="justify">Pour illustrer l'int&eacute;r&ecirc;t de la fonction <i>parseInt()</i> rien
  de tel qu'un exemple. Soient les variables <i>a</i> et <i>b</i>&nbsp;:
<pre class="Code">var a = "123";
var b = "456";</pre>
<p align="justify">Selon que l'on utilise la fonction <i>parseInt()</i> ou non,
  l'utilisation de l'op&eacute;rateur <i>+</i> avec ces deux variables donnera
  un r&eacute;sultat diff&eacute;rent&nbsp;:
<pre class="Code">document.write(a+b,"&lt;BR&gt;"); // Affiche 123456
document.write(parseInt(a)+parseInt(b),"&lt;BR&gt;"); // Affiche 579</pre>
<p align="justify">Le tableau suivant donne des exemples d'utilisation de la
  fonction <i>ParseInt()</i>&nbsp;:
<p align="justify">
<table class="ccm">
  <tr>
    <th width="300">Exemple</th>
    <th>R&eacute;sultat</th>
  </tr>
  <tr>
    <td>parseInt(&quot;128.34&quot;);</td>
    <td><script language="Javascript">
<!--
document.write(parseInt("128.34"));
-->
</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;12.3E-6&quot;);</td>
    <td><script language="Javascript">
<!--
document.write(parseInt("12.3E-6"));
-->
</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;12E+6&quot;);</td>
    <td><script language="Javascript">
<!--
document.write(parseInt("12E+6"));
-->
</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;Bonjour&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("Bonjour"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;24Bonjour38&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("24Bonjour38"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;Bonjour3824&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("Bonjour3824"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;AF8BEF&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("AF8BEF"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;0284&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("0284"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;0284&quot;,8);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("0284",8));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;AF8BEF&quot;,16);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("AF8BEF",16));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;AB882F&quot;,16);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("AB882F",16));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;0xAB882F&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("0xAB882F"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;0xAB882F&quot;,16);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("0xAB882F",16));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;00100110&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("00100110"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;00100110&quot;,2);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("00100110",2));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;00100110&quot;,8);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("00100110",8));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;00100110&quot;,10);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("00100110",10));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseInt(&quot;00100110&quot;,16);</td>
    <td><script language="Javascript">

<!--
document.write(parseInt("00100110",16));

-->

</script>
    </td>
  </tr>
</table>
<a name="parsefloat" class="ancre"></a>
<h3>parseFloat()</h3>
<p align="justify">La fonction <i>parseFloat()</i> est une fonction du noyau
  Javascript permettant de convertir une variable pass&eacute;e en param&egrave;tre
  en nombre en virgule flottante (nombre avec une partie d&eacute;cimale). La
  syntaxe de la fonction <i>parseFloat()</i> est la suivante&nbsp;:
<pre class="Code">parseFloat(chaine);</pre>
<p align="justify">Pour que la fonction <i>parseFloat()</i> retourne un flottant,
  la chaine pass&eacute;e en param&egrave;tre doit commencer par des caract&egrave;re
  valides c'est-&agrave;-dire les chiffres [0-9] et/ou les caract&egrave;res <i>+,
  -, E</i> et <i>e</i>. Dans le cas contraire la fonction <i>parseFloat()</i> retournera
  la valeur <i>NaN</i> (<i>Not a Number</i>).
<p align="justify">
<table border="0">
  <tr>
    <td><img src="images/warning.gif" width="47" height="39"></td>
    <td>Dans les navigateurs supportant une version de Javascript ant&eacute;rieure &agrave; la
      version 1.1, le chiffre 0 sera renvoy&eacute;.</td>
  </tr>
</table>
<p align="justify">Si les caract&egrave;res suivants ne sont pas valides, ils
  seront ignor&eacute;s par la fonction <i>parseFloat()</i>. Si la cha&icirc;ne
  pass&eacute;e en param&egrave;tre repr&eacute;sente un nombre poss&eacute;dant
  une partie litt&eacute;rale, celle-ci sera tronqu&eacute;e.
<p align="justify">Le tableau suivant donne des exemples d'utilisation de la
  fonction <i>parseFloat()</i>&nbsp;:
<p align="justify">
<table class="ccm">
  <tr>
    <th width="300">Exemple</th>
    <th>R&eacute;sultat</th>
  </tr>
  <tr>
    <td>parseFloat(&quot;128.34&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseFloat("128.34"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseFloat(&quot;128,34&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseFloat("128,34"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseFloat(&quot;12.3E-6&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseFloat("12.3E-6"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseFloat(&quot;Bonjour&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseFloat("Bonjour"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseFloat(&quot;24.568Bonjour38&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseFloat("24.568Bonjour38"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseFloat(&quot;Bonjour38.24&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseFloat("Bonjour38.24"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseFloat(&quot;AF8BEF&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseFloat("AF8BEF"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseFloat(&quot;0284&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseFloat("0284"));

-->

</script>
    </td>
  </tr>
  <tr>
    <td>parseFloat(&quot;0xAB882F&quot;);</td>
    <td><script language="Javascript">

<!--
document.write(parseFloat("0xAB882F"));

-->

</script>
    </td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="500" border="0">
                <tr>
                  <td width="100" align="center"><div align="center">
                    <!--Code � ins�rer jjspub -->
                    <!-- SiteSearch Google -->
                    
                    <form method="get" action="http://www.google.fr/custom" target="google_window">
                          <table height="40" border="0" bgcolor="#9966FF">
                            <tr>
                              <td nowrap="nowrap">
                                  <div align="left">
                                    <input type="hidden" name="domains" value="www.Monjavascript.net">
                                    <input type="text" name="q" size="32" maxlength="255">
                                  </div></td>

                              <td nowrap="nowrap">
                                      <input type="radio" name="sitesearch" value="" checked="checked">
                                      <font size="-1" color="#000000">Web</font> </td>
                              <td nowrap="nowrap">
                                      <input type="radio" name="sitesearch" value="www.Monjavascript.net">
                                      <font size="-1" color="#000000">Monjavascript
                                      </font></td>
                              <td nowrap="nowrap">
                                <div align="center"></div>
                                <div align="center">
                                  <input type="submit" name="sa" value="Recherche Google">
                                  <input type="hidden" name="client" value="pub-2085185646476169">
                                  <input type="hidden" name="forid" value="1">
                                  <input type="hidden" name="ie" value="ISO-8859-1">
                                  <input type="hidden" name="oe" value="ISO-8859-1">
                                  <input type="hidden" name="cof" value="GALT:#008000;GL:1;DIV:#9966FF;VLC:663399;AH:center;BGC:FFFFFF;LBGC:9966FF;ALC:0000FF;LC:0000FF;T:000000;GFNT:0000FF;GIMP:0000FF;LH:50;LW:158;L:http://www.Monjavascript.net/im/jjs-net2.gif;S:http://www.Monjavascript.net/;FORID:1">
                                  <input type="hidden" name="hl" value="fr">
                                </div></td>
                            </tr>
                          </table>
                    </form>
                        <!-- SiteSearch Google -->
                    <!--Code � ins�rer jjspub -->
</div>
                  </td>
                  <td width="100"><div align="center"><a href="js02implant.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js04tab.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>
              <hr>

              <p align="justify"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Ce
                  document intitul&eacute; &laquo;Javascript - Les variables&raquo; issu
                de l'encyclop&eacute;die
                informatique Comment &Ccedil;a Marche (<a href="http://www.commentcamarche.net/" target="_blank">www.commentcamarche.net</a>)
                est mis &agrave; disposition sous les termes de la licence Creative
                Commons. Vous pouvez copier, modifier des copies de cette page,
                dans les conditions fix&eacute;es par la licence, tant que cette
              note appara&icirc;t clairement. </font></p>
              <p align="center">&nbsp;</p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
