<html>
<head>
<title>Mon javascript - Cours de javascript</title>
<meta name="Description" lang="fr" content="Webmasters, Mon javascript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="Monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF- http://www.Monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
</head>
<body bgcolor="#FFFFFF">
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
	<div align="center"><a href="index.php">Cours de Javascript</a><a href="index.php">
</a></div>
<p>  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js01intro.php">Introduction au Javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js02implant.php">Implantation du code</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js03var.php">Variables javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js04tab.php">Tableaux javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js05char.php">Cha&icirc;ne de caract&egrave;res</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js06even.php">&Eacute;v&eacute;nements
  javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js07oper.php">Op&eacute;rateurs</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js08cond.php">Structures conditionnelles</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js09fonc.php">Fonctions</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js10meth.php">M&eacute;thodes</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js11dial.php">Bo&icirc;tes
  de dialogue</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js12objet.php">La notion d'objet</a><br>
  <font color="#CCCCCC"><strong>Objets de Javascript</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js13noyau.php">Objets du noyau</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js14array.php">Objet Array</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js15boolean.php">Objet Boolean</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js16date.php">Objet Date</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js17math.php">Objet Math</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js18regexp.php">Objet RegExp</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js19string.php">Objet String</a><br>
  <font color="#CCCCCC"><strong>Objets du navigateur</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js20objets.php">Pr&eacute;sentation
  des objets</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js21window.php">Objet window</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js22navig.php">Objet navigator</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js23history.php">Objet history</a></p>
<p align="center"><font color="#FFFFFF">- - - - - - - -</font> </p> 

	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="left"> 
              <h2 align="center"> 
                Les &eacute;v&eacute;nements<br>
              </h2>
              
              <table width="300" border="0" align="right">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js05char.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js07oper.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>
              <h2 align="center">&nbsp;              </h2>
              <h2><br>
              Qu'appelle-t-on un &eacute;v&eacute;nement ?</h2>
              <p align="justify">Les &eacute;v&eacute;nements sont des actions
                de l'utilisateur, qui vont pouvoir donner lieu &agrave; une interactivit&eacute;.
                L'&eacute;v&eacute;nement par excellence est le clic de souris,
                car c'est le seul que le HTML g&egrave;re. Gr&acirc;ce au Javascript
                il est possible d'associer des fonctions, des m&eacute;thodes &agrave; des &eacute;v&eacute;nements
                tels que le passage de la souris au-dessus d'une zone, le changement
                d'une valeur, ...
              <p align="justify">Ce sont les gestionnaires d'&eacute;v&eacute;nements
                qui permettent d'associer une action &agrave; un &eacute;v&eacute;nement.
                La syntaxe d'un gestionnaire d'&eacute;v&eacute;nement est la
                suivante&nbsp;:
              <pre class="Code">on<i>Evenement</i>=&quot;Action_Javascript_ou_Fonction();&quot;</pre>
              <p align="justify">Lorsqu'il est utilis&eacute; dans un lien hypertexte,
                par exemple, la syntaxe sera la suivante&nbsp;:
              <pre class="Code">&lt;A href=&quot;URL&quot; &quot;on<i>Evenement</i>='Action_Javascript_ou_Fonction();'&quot;&gt;Lien&lt;/a&gt;</pre>
              <p align="justify">Les gestionnaires d'&eacute;v&eacute;nements
                sont associ&eacute;s &agrave; des objets, et leur code s'ins&egrave;rent
                dans la balise de ceux-ci... <a name="liste" class="ancre"></a>
              <h2>Liste des &eacute;v&eacute;nements</h2>
              <p align="justify">
              <table class="ccm" width="550">
                <tr>
                  <th>Ev&eacute;nement</th>
                  <th>Description</th>
                  <th>Test</th>
                  <th>Effet</th>
                </tr>
                <tr>
                  <td><b>Abort</b> <br/>
                    (onAbort)</td>
                  <td>Cet &eacute;v&eacute;nement a lieu lorsque l'utilisateur
                    interrompt le chargement de l'image</td>
                  <td align="center">&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><b>Blur</b> <br/>
                    (onBlur)</td>
                  <td>Se produit lorsque l'&eacute;l&eacute;ment perd le focus,
                    c'est-&agrave;-dire que l'utilisateur clique hors de cet &eacute;l&eacute;ment,
                    celui-ci n'est alors plus s&eacute;lectionn&eacute; comme &eacute;tant
                    l'&eacute;l&eacute;ment actif.</td>
                  <td><form>
                      <input name="Text" type="Text" onBlur="document.blur.src='images/on.gif';" size=6>
                    </form>
                  </td>
                  <td><img name="blur" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td><b>Change</b> <br/>
                    (onChange)</td>
                  <td>Se produit lorsque l'utilisateur modifie le contenu d'un
                    champ de donn&eacute;es.</td>
                  <td><form>
                      <input name="Text2" type="Text" onChange="document.images['change'].src='images/on.gif';" size=6>
                    </form>
                  </td>
                  <td><img name="change" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td rowspan="2"><b>Click</b> <br/>
                    (onClick)</td>
                  <td rowspan="2">Se produit lorsque l'utilisateur clique sur
                    l'&eacute;l&eacute;ment associ&eacute; &agrave; l'&eacute;v&eacute;nement.</td>
                  <td align="center"><a href="javascript:;" onClick="document.images['img_click'].src='images/on.gif';">Test</a></td>
                  <td><img name="img_click" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td valign="bottom"><br/>
                      <form name="onSubmit">
                        <input name="button" type="button" onClick="document.images['img_click2'].src='images/on.gif';" value="Tester">
                      </form>
                  </td>
                  <td><img name="img_click2" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td rowspan="2"><b>dblclick</b> <br/>
                    (onDblclick)</td>
                  <td rowspan="2">Se produit lorsque l'utilisateur double-clique
                    sur l'&eacute;l&eacute;ment associ&eacute; &agrave; l'&eacute;v&eacute;nement
                    (un lien hypertexte ou un &eacute;l&eacute;ment de formulaire).
                    Cet &eacute;v&eacute;nement n'est support&eacute; que par
                    les versions de Javascript 1.2 et sup&eacute;rieures</td>
                  <td align="center"><a href="javascript:;" onDblClick="document.images['img_dblclick'].src='images/on.gif';">Test</a></td>
                  <td><img name="img_dblclick" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td valign="bottom"><br/>
                      <form name="onDblClick">
                        <input name="button" type="button" onDblClick="document.images['img_dblclick2'].src='images/on.gif';" value="Tester">
                      </form>
                  </td>
                  <td><img name="img_dblclick2" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td><b>dragdrop</b> <br/>
                    (onDragdrop)</td>
                  <td>Se produit lorsque l'utilisateur effectue un <i>glisser-d&eacute;poser</i> sur
                    la fen&ecirc;tre du navigateur. <br/>
                    Cet &eacute;v&eacute;nement n'est support&eacute; que par
                    les versions de Javascript 1.2 et sup&eacute;rieures</td>
                  <td align="center">&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><b>error</b> <br/>
                    (onError)</td>
                  <td>Se d&eacute;clenche lorsqu'une erreur appara&icirc;t durant
                    le chargement de la page.<br/>
      Cet &eacute;v&eacute;nement fait partie du Javascript 1.1.</td>
                  <td align="center">&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><b>Focus</b> <br/>
                    (onFocus)</td>
                  <td>Se produit lorsque l'utilisateur donne le focus &agrave; un &eacute;l&eacute;ment,
                    c'est-&agrave;-dire que cet &eacute;l&eacute;ment est s&eacute;lectionn&eacute; comme &eacute;tant
                    l'&eacute;l&eacute;ment actif</td>
                  <td><form>
                      <input name="Text2" type="Text" onFocus="document.focus.src='images/on.gif';" size=6>
                    </form>
                  </td>
                  <td><img name="focus" src="images/off.gif"></td>
                </tr>
                <script language="Javascript">

<!--
//if () ie = true;

//else ns = True;

ns = (navigator.appName == "Netscape") ? 1:0
ie = (navigator.appName == "Microsoft Internet Explorer") ? 1:0
function CaptureKeyPress(e) {     
  
if (ns) var key = String.fromCharCode(e.which);       
else if (ie) var key = String.fromCharCode(event.keyCode);     
document.forms["test_keypress"].reception.value +=  key;

return;

}

function CaptureResize(e) {     
document.img_resize.src='images/on.gif';

return;

}

function CaptureSelect(e) {     
document.img_select.src='images/on.gif';

return;

}

function CaptureDragdrop(e) { 
netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");   
return false;

}

if (ns) document.captureEvents(Event.KEYPRESS);

if (ns) window.captureEvents(Event.RESIZE|Event.DRAGDROP);

document.onkeypress = CaptureKeyPress;

window.onresize = CaptureResize;

//window.ondragdrop = CaptureDragdrop;

window.ondragdrop = function (evt) { return false; };

//window.document.forms["test_select"].onselect = CaptureSelect;

// .forms['test_keypress'].emission
-->

              </script>
                <tr>
<td><b>keydown</b> <br/>(onKeydown)</td>
<td>Se produit lorsque l'utilisateur appuie sur une touche de son clavier.

<br/>Cet &eacute;v&eacute;nement n'est support&eacute; que par les versions de Javascript 1.2 et sup&eacute;rieures</td>
<td><form name="test_keyup"><input type="Text" name="emission" size=6></textarea></td>
<td><br/><input type="hidden" name="reception" size=6></form></td>
</tr>
<tr>
<td><b>keypress</b> <br/>(onKeypress)</td>
<td>Se produit lorsque l'utilisateur maintient une touche de son clavier enfonc&eacute;e.

<br/>Cet &eacute;v&eacute;nement n'est support&eacute; que par les versions de Javascript 1.2 et sup&eacute;rieures</td>
<td><form name="test_keypress"><input type="Text" name="emission" size=6></textarea></td>
<td><br/><input type="Text" name="reception" size=6></form></td>
</tr>
<tr>
<td><b>keyup</b> <br/>(onKeyup)</td>
<td>Se produit lorsque l'utilisateur rel&acirc;che une touche de son clavier pr&eacute;alablement enfonc&eacute;e.

<br/>Cet &eacute;v&eacute;nement n'est support&eacute; que par les versions de Javascript 1.2 et sup&eacute;rieures</td>
<td><form name="test_keyup"><input type="Text" name="emission" size=6></textarea></td>
<td><br/><input type="hidden" name="reception" size=6></form></td>
</tr>
                <tr>
                  <td><b>Load</b> <br/>
                    (onLoad)</td>
                  <td>Se produit lorsque le navigateur de l'utilisateur charge
                    la page en cours</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><b>MouseOver</b> <br/>
                    (onMouseOver)</td>
                  <td>Se produit lorsque l'utilisateur positionne le curseur
                    de la souris au-dessus d'un &eacute;l&eacute;ment</td>
                  <td align="center"><a href="javascript:;"
onMouseOver="document.img_over.src='images/on.gif';">Test</a></td>
                  <td><img name="img_over" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td><b>MouseOut</b> <br/>
                    (onMouseOut)</td>
                  <td>Se produit lorsque le curseur de la souris quitte un &eacute;l&eacute;ment.<br/>
      Cet &eacute;v&eacute;nement fait partie du Javascript 1.1.</td>
                  <td align="center"><a href="javascript:;" onMouseOut="document.out.src='images/on.gif';">Test</a></td>
                  <td><img name="out" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td><b>Reset</b> <br/>
                    (onReset)</td>
                  <td>Se produit lorsque l'utilisateur efface les donn&eacute;es
                    d'un formulaire &agrave; l'aide du bouton Reset.</td>
                  <td><form onReset="document.images['img_reset'].src='images/on.gif';">
                      <input name="Reset" type="Reset" value="Reset">
                    </form>
                  </td>
                  <td><img name="img_reset" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td><b>Resize</b> <br/>
                    (onResize)</td>
                  <td>Se produit lorsque l'utilisateur redimensionne la fen&ecirc;tre
                    du navigateur</td>
                  <td>&nbsp;</td>
                  <td><img name="img_resize" src="images/off.gif"></td>
                </tr>
                <tr>
                  <td><b>Select</b> <br/>
                    (onSelect)</td>
                  <td>Se produit lorsque l'utilisateur s&eacute;lectionne un
                    texte (ou une partie d'un texte) dans un champ de type "text" ou "textarea"</td>
                  <td><form name="test_select">
                      <input type="Text" value="Test" name="emission" onSelect="CaptureSelect();" size=6>
                    </form>
                  </td>
                  <td><img name="img_select" src="images/off.gif"> </td>
                </tr>
                <tr>
                  <td><b>Submit</b> <br/>
                    (onSubmit)</td>
                  <td>Se produit lorsque l'utilisateur clique sur le bouton de
                    soumission d'un formulaire (le bouton qui permet d'envoyer
                    le formulaire)</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><b>Unload</b> <br/>
                    (onUnload)</td>
                  <td>Se produit lorsque le navigateur de l'utilisateur quitte
                    la page en cours</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
              </table>
              <a name="objets" class="ancre"></a>
              <h2>Association des &eacute;v&eacute;nements aux objets</h2>
              <p align="justify">Chaque &eacute;v&eacute;nement ne peut pas &ecirc;tre
                associ&eacute; &agrave; n'importe quel objet. Il est &eacute;vident
                par exemple qu'un &eacute;v&eacute;nement <i>OnChange</i> ne
                pourra pas s'appliquer &agrave; un lien hypertexte. Voici un
                tableau r&eacute;capitulant les objets auxquels peuvent &ecirc;tre
                associ&eacute;s chaque &eacute;v&eacute;nement&nbsp;:
              <p align="justify">
              <table class="ccm">
                <tr>
                  <th>Ev&eacute;nements</th>
                  <th>Objets concern&eacute;s</th>
                </tr>
                <tr>
                  <td align="center">abort</td>
                  <td align="center">Image</td>
                </tr>
                <tr>
                  <td align="center">blur</td>
                  <td align="center">Button, Checkbox, FileUpload, Layer, Password,
                    Radio, Reset, Select, Submit, Text, TextArea, window</td>
                </tr>
                <tr>
                  <td align="center">change</td>
                  <td align="center">FileUpload, Select, Submit, Text, TextArea</td>
                </tr>
                <tr>
                  <td align="center">click</td>
                  <td align="center">Button, document, Checkbox, Link, Radio,
                    Reset, Select, Submit</td>
                </tr>
                <tr>
                  <td align="center">dblclick</td>
                  <td align="center">document, Link</td>
                </tr>
                <tr>
                  <td align="center">dragdrop</td>
                  <td align="center">window</td>
                </tr>
                <tr>
                  <td align="center">error</td>
                  <td align="center">Image, window</td>
                </tr>
                <tr>
                  <td align="center">focus</td>
                  <td align="center">Button, Checkbox, FileUpload, Layer, Password,
                    Radio, Reset, Select, Submit, Text, TextArea, window</td>
                </tr>
                <tr>
                  <td align="center">keydown</td>
                  <td align="center">document, Image, Link, TextArea</td>
                </tr>
                <tr>
                  <td align="center">keypress</td>
                  <td align="center">document, Image, Link, TextArea</td>
                </tr>
                <tr>
                  <td align="center">keyup</td>
                  <td align="center">document, Image, Link, TextArea</td>
                </tr>
                <tr>
                  <td align="center">load</td>
                  <td align="center">Image, Layer, window</td>
                </tr>
                <tr>
                  <td align="center">mousedown</td>
                  <td align="center">Button, document, Link</td>
                </tr>
                <tr>
                  <td align="center">mousemove</td>
                  <td align="center">Aucun sp&eacute;cifiquement</td>
                </tr>
                <tr>
                  <td align="center">mouseout</td>
                  <td align="center">Layer, Link</td>
                </tr>
                <tr>
                  <td align="center">mouseover</td>
                  <td align="center">Area, Layer, Link</td>
                </tr>
                <tr>
                  <td align="center">mouseup</td>
                  <td align="center">Button, document, Link</td>
                </tr>
                <tr>
                  <td align="center">move</td>
                  <td align="center">window</td>
                </tr>
                <tr>
                  <td align="center">reset</td>
                  <td align="center">form</td>
                </tr>
                <tr>
                  <td align="center">resize</td>
                  <td align="center">window</td>
                </tr>
                <tr>
                  <td align="center">select</td>
                  <td align="center">text, Textarea</td>
                </tr>
                <tr>
                  <td align="center">submit</td>
                  <td align="center">Form</td>
                </tr>
                <tr>
                  <td align="center">unload</td>
                  <td align="center">window</td>
                </tr>
              </table>
              <a name="exemples" class="ancre"></a>
              <h2>Quelques exemples d'&eacute;v&eacute;nements</h2>
              <p align="justify">Le mieux pour apprendre &agrave; se servir des &eacute;v&eacute;nements
                est de s'entra&icirc;ner &agrave; &eacute;crire de petits codes... <br/>
                Pour vous inspirer, pensez &agrave; regarder les fichiers sources
                de certaines pages web, mais pensez toujours &agrave; respecter
                les auteurs des codes en ne faisant pas un copier-coller de leurs
                scripts sans leur accord (il est g&eacute;n&eacute;ralement de
                bon ton de citer la source du javascript que l'on r&eacute;cup&egrave;re...). <a name="dialogbox" class="ancre"></a>
              <h3>Ouverture d'une bo&icirc;te de dialogue lors d'un click</h3>
              <p align="justify">Le code correspondant &agrave; une bo&icirc;te
                de dialogue est tr&egrave;s simple&nbsp;:
              <pre class="Code">window.alert("Votre Texte"); </pre>
              <p align="justify">Il s'agit d&eacute;sormais de l'appeler &agrave; l'aide
                d'un &eacute;v&eacute;nement dans l'attribut &laquo;&nbsp;href&nbsp;&raquo; d'un
                lien hypertexte&nbsp;:
              <pre class="Code">&lt;html&gt;
&lt;head&gt;
&lt;title&gt;Ouverture d'une bo&icirc;te de dialogue lors d'un click&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&nbsp;
&lt;a href=&quot;javascript:;&quot;
onClick=&quot;window.alert('Message d\'alerte � utiliser avec moderation');&quot;&gt;
Cliquez ici!&lt;/a&gt;
&nbsp;
&lt;/body&gt;
&lt;/html&gt;</pre>
              <p align="justify"><b>Analyse du script:</b>
              <ul>
                <li>le gestionnaire d'&eacute;v&eacute;nement <i>onClick</i> a &eacute;t&eacute; ins&eacute;r&eacute; dans
                  la balise de lien hypertexte <i>&lt;A href...</i></li>
                <li>le seul but du script est de faire appara&icirc;tre une bo&icirc;te
                  de dialogue, ainsi on ne d&eacute;sire pas que le lien nous
                  entra&icirc;ne sur une autre page, il faut alors ins&eacute;rer "javascript:;" dans
                  l'attribut <i>href</i> pour signaler au navigateur que l'on
                  d&eacute;sire rester sur la page en cours. Il ne faut pas mettre
                  un attribut vide au risque de r&eacute;v&eacute;ler le contenu
                  de votre r&eacute;pertoire &agrave; vos visiteurs...</li>
                <li>Remarquez l'emploi de <i>\'</i> dans la phrase &quot;Message
                  d'alerte a utiliser avec moderation&quot; <br/>
                  Le signe antislash (\) pr&eacute;c&eacute;dant le guillemet
                  permet de signaler au navigateur qu'il ne faut pas l'interpr&eacute;ter
                  comme un d&eacute;limiteur de cha&icirc;ne mais comme un simple
                  caract&egrave;re pour &eacute;viter qu'il g&eacute;n&egrave;re
                  une erreur!</li>
              </ul>
              <p align="justify"><b>Aper&ccedil;u de l'effet du script:</b> <br/>
                  <a href="javascript:;" onClick="alert('Message d\'alerte a utiliser avec moderation')">Cliquez
                  ici!</a> <a name="flipflap" class="ancre"></a>
              <h3>Modification d'une image lors du survol d'un lien par le pointeur
                de la souris</h3>
              <p align="justify">Il peut &ecirc;tre agr&eacute;able de jouer
                avec le gestionnaire <i>OnMouseOver</i> pour cr&eacute;er un
                menu interactif qui se modifie au passage de la souris. On peut
                m&ecirc;me ajouter le gestionnaire <i>OnMouseOut</i> pour r&eacute;tablir
                l'image originale lorsque le curseur quitte l'image (<b>Rappel:
                Son utilisation est limit&eacute;e aux navigateurs supportant
                javascript 1.1 et sup&eacute;rieur!)</b>. Ce type d'effet est
                appel&eacute; <i>rollover</i>.
              <p align="justify"><b>Script:</b><br/>
&nbsp;
              <pre class="Code">&lt;html&gt;
&lt;head&gt;
&lt;title&gt;Modification d'une image lors du passage de la souris&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&nbsp;
&lt;a href=&quot;javascript:;&quot;
onMouseOver=&quot;document.img_1.src='image2.gif';&quot;
onMouseOut=&quot;document.img_1.src='image1.gif';&quot;&gt;
&lt;img name=&quot;img_1&quot; src=&quot;image1.gif"&gt; &lt;/a&gt;
&nbsp;
&lt;/body&gt;
&lt;/html&gt;</pre>
              <p align="justify"><b>Analyse du script:</b>
              <ul>
                <li>Pour pouvoir associer un &eacute;v&eacute;nement &agrave; une
                  image il faut que celle-ci soit consid&eacute;r&eacute;e comme
                  un lien, ainsi on place la balise <i>&lt;img ...&gt;</i> entre
                  les balises <i>&lt;a ...&gt;</i> et <i>&lt;/a&gt;</i>
                <li>L'&eacute;v&eacute;nement <i>onMouseOut</i> est limit&eacute; aux
                  navigateurs supportant javascript 1.1 et sup&eacute;rieur
              </ul>
              <p align="justify"><b>Aper&ccedil;u de l'effet du script:</b> <br/>
                  <a href="javascript:;" onMouseOver="document.img_1.src='images/off.gif';" onMouseOut="document.img_1.src='images/on.gif';"> <img name="img_1" src='images/on.gif' border=0> </a>
              <p align="justify">&nbsp;              
              <table width="300" border="0">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js05char.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js07oper.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>
              <hr>

              <p align="justify"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Ce
                  document intitul&eacute; &laquo;Javascript - Les &eacute;v&eacute;nements&raquo; issu
                de l'encyclop&eacute;die
                informatique Comment &Ccedil;a Marche (<a href="http://www.commentcamarche.net/" target="_blank">www.commentcamarche.net</a>)
                est mis &agrave; disposition sous les termes de la licence Creative
                Commons. Vous pouvez copier, modifier des copies de cette page,
                dans les conditions fix&eacute;es par la licence, tant que cette
              note appara&icirc;t clairement. </font></p>
              <p align="center">&nbsp;</p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
