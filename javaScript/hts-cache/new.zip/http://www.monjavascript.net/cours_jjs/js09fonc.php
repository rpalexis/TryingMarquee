<html>
<head>
<title>Mon javascript - Cours de javascript</title>
<meta name="Description" lang="fr" content="Webmasters, Mon javascript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="Monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF- http://www.Monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
<SCRIPT language="Javascript">

<!--
function Affiche1() {
alert('Texte 1');

}

function Affiche2() {
alert('Texte2');

}

function Affiche(Texte) {
alert(Texte);

}

//-->

</SCRIPT>
</head>
<body bgcolor="#FFFFFF">
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
	<div align="center"><a href="index.php">Cours de Javascript</a><a href="index.php">
</a></div>
<p>  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js01intro.php">Introduction au Javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js02implant.php">Implantation du code</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js03var.php">Variables javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js04tab.php">Tableaux javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js05char.php">Cha&icirc;ne de caract&egrave;res</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js06even.php">&Eacute;v&eacute;nements
  javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js07oper.php">Op&eacute;rateurs</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js08cond.php">Structures conditionnelles</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js09fonc.php">Fonctions</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js10meth.php">M&eacute;thodes</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js11dial.php">Bo&icirc;tes
  de dialogue</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js12objet.php">La notion d'objet</a><br>
  <font color="#CCCCCC"><strong>Objets de Javascript</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js13noyau.php">Objets du noyau</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js14array.php">Objet Array</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js15boolean.php">Objet Boolean</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js16date.php">Objet Date</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js17math.php">Objet Math</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js18regexp.php">Objet RegExp</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js19string.php">Objet String</a><br>
  <font color="#CCCCCC"><strong>Objets du navigateur</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js20objets.php">Pr&eacute;sentation
  des objets</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js21window.php">Objet window</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js22navig.php">Objet navigator</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js23history.php">Objet history</a></p>
<p align="center"><font color="#FFFFFF">- - - - - - - -</font> </p> 

	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="left"> 
              <h2 align="center"> 
                Les fonctions              </h2>
              <table width="300" border="0" align="right">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js08cond.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js10meth.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>              
              <h2>&nbsp;</h2>
              <h2><br>
              <a name="fonction" class="ancre"></a>La notion de fonction</h2>
              <p align="justify">On appelle <i>fonction</i> un sous-programme
                qui permet d'effectuer un ensemble d'instructions par simple
                appel de la fonction dans le <b>corps</b> du programme principal.
                Cette notion de sous-programme est g&eacute;n&eacute;ralement
                appel&eacute;e fonction dans les langages autres que le Javascript
                (toutefois leur syntaxe est g&eacute;n&eacute;ralement diff&eacute;rente...).
                Les fonctions permettent d'ex&eacute;cuter dans plusieurs parties
                du programme une s&eacute;rie d'instructions, cela permet une
                simplicit&eacute; du code et donc une taille de programme minimale.
                D'autre part, une fonction peut faire appel &agrave; elle-m&ecirc;me,
                on parle alors de fonction r&eacute;cursive (il ne faut pas oublier
                dans ce cas de mettre une condition de sortie au risque sinon
                de ne pas pouvoir arr&ecirc;ter le programme...).
              <p align="justify">Javascript contient des fonctions pr&eacute;d&eacute;finies
                qui peuvent s'appliquer pour un ou plusieurs types d'objets sp&eacute;cifiques,
                on appelle ces fonctions des <i><a href="js10meth.php">m&eacute;thodes</a></i>. <a name="declaration" class="ancre"></a>
              <h2>La d&eacute;claration d'une fonction</h2>
              <p align="justify">Avant d'&ecirc;tre utilis&eacute;e, une fonction
                doit &ecirc;tre d&eacute;finie car pour l'appeler dans le corps
                du programme il faut que le navigateur la connaisse, c'est-&agrave;-dire
                qu'il connaisse son nom, ses arguments et les instructions qu'elle
                contient. La d&eacute;finition d'une fonction s'appelle &quot;<i>d&eacute;claration&quot;</i>.
                La d&eacute;claration d'une fonction se fait gr&acirc;ce au mot
                cl&eacute; function selon la syntaxe suivante&nbsp;:
              <pre class="Code">function Nom_De_La_Fonction(argument1, argument2, ...) {
	liste d'instructions
}</pre>
              <p align="justify"><b>Remarques: </b>
              <ul>
                <li>le mot cl&eacute; function est suivi du nom que l'on donne &agrave; la
                  fonction</li>
                <li>le nom de la fonction suit les m&ecirc;mes r&egrave;gles
                  que les <a href="js03var.php">noms de variables</a>&nbsp;:
                    <ul>
                      <li>le nom doit commencer par une lettre</li>
                      <li>un nom de fonction peut comporter des lettres, des
                        chiffres et les caract&egrave;res _ et & (les espaces
                        ne sont pas autoris&eacute;s!)</li>
                      <li>le nom de la fonction, comme celui des variables est
                        sensible &agrave; la casse (diff&eacute;renciation entre
                        les minuscules et majuscules)</li>
                    </ul>
                </li>
                <li>Les arguments sont facultatifs, mais s'il n'y a pas d'arguments,
                  les parenth&egrave;ses doivent rester pr&eacute;sentes</li>
                <li>Il ne faut pas oublier de refermer les accolades</li>
              </ul>
              <p align="justify">
              <table border="0">
                <tr>
                  <td><img src="images/warning.gif" width="47" height="39"></td>
                  <td>
                    <ul>
                      <li>Le nombre d'accolades ouvertes (fonction, boucles et
                        autres structures) doit &ecirc;tre &eacute;gal au nombre
                        d'accolades ferm&eacute;es!</li>
                      <li>La m&ecirc;me chose s'applique pour les parenth&egrave;ses,
                        les crochets ou les guillemets!</li>
                    </ul>
                  </td>
                </tr>
              </table>
              Une fois cette &eacute;tape franchie, votre fonction ne s'ex&eacute;cutera
              pas tant que l'on ne fait pas appel &agrave; elle quelque part
              dans la page! <a name="appel" class="ancre"></a>
              <h2>Appel de fonction</h2>
              <p align="justify">Pour ex&eacute;cuter une fonction, il suffit
                de faire appel &agrave; elle en &eacute;crivant son nom (une
                fois de plus en respectant la casse) suivie d'une parenth&egrave;se
                ouverte (&eacute;ventuellement des arguments) puis d'une parenth&egrave;se
                ferm&eacute;e&nbsp;:
              <pre class="Code">Nom_De_La_Fonction();</pre>
              <p align="justify"><b>Remarques: </b>
              <ul>
                <li>le point virgule signifie la fin d'une instruction et permet
                  au navigateur de distinguer les diff&eacute;rents blocs d'instructions</li>
                <li>si jamais vous avez d&eacute;fini des arguments dans la d&eacute;claration
                  de la fonction, il faudra veiller &agrave; les inclure lors
                  de l'appel de la fonction (le m&ecirc;me nombre d'arguments
                  s&eacute;par&eacute;s par des virgules!)</li>
              </ul>
              <p align="justify">
              <table border="0">
                <tr>
                  <td><img src="images/warning.gif" width="47" height="39"></td>
                  <td> Veillez toujours &agrave; ce qu'une fonction soit d&eacute;clar&eacute;e
                    avant d'&eacute;tre appel&eacute;e, sachant que le navigateur
                    traite la page de haut en bas (Pour &eacute;viter des erreurs
                    de ce type on d&eacute;clare g&eacute;n&eacute;ralement les
                    fonctions dans des balises SCRIPT situ&eacute;es dans l'en-t&ecirc;te
                    de la page, c'est-&agrave;-dire entre les balises &lt;HEAD&gt; et &lt;/HEAD&gt;) </td>
                </tr>
              </table>
              <p align="justify">Gr&acirc;ce au gestionnaire d'&eacute;v&eacute;nement <i>onLoad</i> (&agrave; placer
                dans la balise BODY) il est possible d'ex&eacute;cuter une fonction
                au chargement de la page, comme par exemple l'initialisation
                des variables pour votre script, et/ou le test du navigateur
                pour savoir si celui-ci est apte &agrave; faire fonctionner le
                script. Il s'utilise de la mani&egrave;re suivante&nbsp;:
              <pre class="Code">&lt;HTML&gt;
&lt;HEAD&gt;
&lt;SCRIPT language=&quot;Javascript&quot;&gt;
&lt;!--
&nbsp;
function Chargement() {
	alert('Bienvenue sur le site');
}
&nbsp;
//--&gt;
&lt;/SCRIPT&gt;
&lt;/HEAD&gt;
&lt;BODY onLoad=&quot;Chargement();&quot; &gt;
&nbsp;
Code Javascript qui ne sert absolument &agrave; rien si ce n'est d&eacute;ranger vos visiteurs...
&nbsp;
&lt;/BODY&gt;
&lt;/HTML&gt;</pre>
              <a name="parametres" class="ancre"></a>
              <h2>Les param&egrave;tres d'une fonction</h2>
              <p align="justify">Il est possible de passer des param&egrave;tres &agrave; une
                fonction, c'est-&agrave;-dire lui fournir une valeur ou le nom
                d'une variable afin que la fonction puisse effectuer des op&eacute;rations
                sur ces param&egrave;tres ou bien gr&acirc;ce &agrave; ces param&egrave;tres. <br/>
  Lorsque vous passez plusieurs param&egrave;tres &agrave; une fonction il faut
  les s&eacute;parer par des virgules, aussi bien dans la d&eacute;claration
  que dans l'appel et il faudra veiller &agrave; bien passer le bon nombre de
  param&egrave;tres lors de l'appel au risque sinon de cr&eacute;er une erreur
  dans votre Javascript...
              <p align="justify">Imaginons que l'on veuille cr&eacute;er une
                page Web qui affiche une bo&icirc;te de dialogue (les bo&icirc;tes
                de dialogues sont &agrave; &eacute;viter dans vos pages car elles
                sont &eacute;nervantes, mais c'est toutefois une mani&egrave;re
                simple d'apprendre le Javascript) qui affiche un texte diff&eacute;rent
                selon le lien sur lequel on appuie. <br/>
  La m&eacute;thode de base consiste &agrave; faire une fonction pour chaque
  texte &agrave; afficher&nbsp;:
              <pre class="Code">&lt;HTML&gt;
&lt;HEAD&gt;
&lt;SCRIPT language=&quot;Javascript&quot;&gt;
&lt;!--
&nbsp;
function Affiche1() {
         alert('Texte 1');
}
function Affiche2() {
         alert('Texte2');
}
&nbsp;
//--&gt;
&lt;/SCRIPT&gt;
&lt;/HEAD&gt;
&lt;BODY&gt;
&nbsp;
&lt;A href=&quot;javascript:;&quot; onClick=&quot;Affiche1();&quot;&gt;Texte1&lt;/A&gt;
&lt;A href=&quot;javascript:;&quot; onClick=&quot;Affiche2();&quot;&gt;Texte2&lt;/A&gt;
&nbsp;
&lt;/BODY&gt;
&lt;/HTML&gt;</pre>
              <p align="justify">Ce qui donne ceci&nbsp;: 
<br><a href="javascript:;" onclick="Affiche1();">Texte1</a>
<br><a href="javascript:;" onclick="Affiche2();">Texte2</a>
              <p align="justify">Il existe toutefois une methode plus &quot;classe&quot; qui
                consiste &agrave; cr&eacute;er une fonction qui a comme param&egrave;tre
                le texte &agrave; afficher&nbsp;:
              <pre class="Code">&lt;HTML&gt;
&lt;HEAD&gt;
&lt;SCRIPT language=&quot;Javascript&quot;&gt;
&lt;!--
&nbsp;
function Affiche(Texte) {
	alert(Texte);
}
&nbsp;
//--&gt;
&lt;/SCRIPT&gt;
&lt;/HEAD&gt;
&lt;BODY&gt;
&nbsp;
&lt;A href=&quot;javascript:;&quot; onClick=&quot;Affiche('Texte1');&quot;&gt;Texte1&lt;/A&gt;
&lt;A href=&quot;javascript:;&quot; onClick=&quot;Affiche('Texte2');&quot;&gt;Texte2&lt;/A&gt;
&nbsp;
&lt;/BODY&gt;
&lt;/HTML&gt;</pre>
              <p align="justify">Ce qui donne ceci&nbsp;: 
<br><a href="javascript:;" onclick="Affiche('Texte 1');">Texte1</a>
<br><a href="javascript:;" onclick="Affiche('Texte 2');">Texte2</a>
              <p align="justify"><b>R&eacute;sultat</b>: Aucune diff&eacute;rence
                visuellement mais vous n'avez plus qu'une seule fonction qui
                peut vous afficher n'importe quel texte... <a name="valeur" class="ancre"></a>
              <h2>Travailler sur des variables dans les fonctions</h2>
              <p align="justify">Lorsque vous manipulerez des variables dans
                des fonctions, il vous arrivera de constater que la variable
                retrouve sa valeur d'origine d&egrave;s que l'on sort de la fonction,
                malgr&eacute; toutes les affectations faites au sein de celle-ci
                ...
              <p align="justify">Cela est d&ucirc; &agrave; la port&eacute;e
                des variables, c'est-&agrave;-dire selon qu'elles ont &eacute;t&eacute; d&eacute;finies
                comme <a href="js03var.php">variables globales ou locales</a>.
              <ul>
                <li>Une variable d&eacute;clar&eacute;e implicitement dans la
                  fonction (non pr&eacute;c&eacute;d&eacute;e du mot-cl&eacute; <i>var</i>)
                  sera globale , c'est-&agrave;-dire accessible apr&egrave;s
                  ex&eacute;cution de la fonction</li>
                <li>Une variable d&eacute;clar&eacute;e explicitement (pr&eacute;c&eacute;d&eacute;e
                  du mot-cl&eacute; <i>var</i>) sera locale , c'est-&agrave;-dire
                  accessible uniquement dans la fonction, toute r&eacute;f&eacute;rence &agrave; cette
                  variable hors de la fonction provoquera une erreur (variable
                  inconnue)...</li>
              </ul>
              <a name="objets" class="ancre"></a>
              <h2>Le mot-cl&eacute; <i>this</i></h2>
              <p align="justify">Lorsque vous fa&icirc;tes appel &agrave; une
                fonction &agrave; partir d'un objet, par exemple un formulaire,
                le mot cl&eacute; <i>this</i> fait r&eacute;f&eacute;rence &agrave; l'objet
                en cours et vous &eacute;vite d'avoir &agrave; d&eacute;finir
                l'objet en tapant <i>window.objet1.objet2...</i> ainsi lorsque
                l'on passe l'objet en cours en param&egrave;tre d'une fonction,
                il suffit de taper <i>nom_de_la_fonction(this)</i> pour pouvoir
                manipuler cet objet &agrave; partir de la fonction.
              <p align="justify">Pour manipuler les propri&eacute;t&eacute;s
                de l'objet il suffira de taper <i>this.propriete</i> (o&ugrave; <i>propriete</i> repr&eacute;sente
                bien s&ucirc;r le nom de la propri&eacute;t&eacute;). <a name="defobj" class="ancre"></a>
              <p align="center">
                <!--Code � ins�rer jjspub -->
                <script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
                <!--Code � ins�rer jjspub -->
                
              <h2>D&eacute;finir des objets avec les fonctions</h2>
              <p align="justify">Les navigateurs ont leurs propres objets avec
                leur propri&eacute;t&eacute;s respectives. Il est toutefois possible
                de cr&eacute;er ses propres objets avec les propri&eacute;t&eacute;s
                qu'on leur d&eacute;finit. <br/>
  Imaginons que l'on veuille par exemple cr&eacute;er un objet arbre avec ses
  propri&eacute;t&eacute;s&nbsp;:
              <ul>
                <li>type</li>
                <li>taille</li>
                <li>age</li>
              </ul>
              <p align="justify">Il est possible de cr&eacute;er l'objet <i>Arbre</i> en
                cr&eacute;ant une fonction dont le nom est <i>Arbre</i> et qui
                d&eacute;finit les propri&eacute;t&eacute;s de l'objet en cours
                gr&acirc;ce au mot-cl&eacute; <i>this</i>, en passant en param&egrave;tre
                chacune des propri&eacute;t&eacute;s&nbsp;:
              <pre class="Code">function Arbre(Type, Taille, Age) {
this.Type = Type;

this.Taille = Taille;

this.Age = Age;

}</pre>
              <p align="justify">Gr&acirc;ce au mot-cl&eacute; <i>new</i>, il
                va &ecirc;tre possible de cr&eacute;er des instances de l'objet <i>Arbre</i> (c'est-&agrave;-dire
                des objets poss&eacute;dant les propri&eacute;t&eacute;s de l'objet <i>Arbre</i>)&nbsp;:
              <pre class="Code">Arbre1 = new Arbre("peuplier", 14, 20)</pre>
              <br/>
              On peut ainsi cr&eacute;er autant d'instances que l'on d&eacute;sire...
              <p align="justify">Il est de plus possible d'ajouter un objet existant
                en tant que propri&eacute;t&eacute; d'un autre objet. Imaginons
                que vous cr&eacute;iez un objet proprietaire&nbsp;:
              <pre class="Code">function Proprietaire(Nom, Prenom) {
this.Nom = Nom;
this.Prenom = Prenom;
}</pre>
              <p align="justify">D&eacute;finissons maintenant l'objet <i>Arbre</i> comme
                suit&nbsp;:
              <pre class="Code">function Arbre(Type, Taille, Age, Proprietaire) {
this.Type = Type;
this.Taille = Taille;
this.Age = Age;
this.Proprietaire = Proprietaire;
}</pre>
              <p align="justify">Il est alors possible de trouver le nom du propri&eacute;taire
                d'un arbre&nbsp;:
              <pre class="Code">Arbre.Proprietaire.Nom</pre>
              <br/>
              Ainsi que de le modifier si jamais le propri&eacute;taire change&nbsp;:
              <pre class="Code">Arbre1.Proprietaire.Nom = 'Dupont';</pre>
              <pre class="Code">Arbre1.Proprietaire.Prenom = 'Ren�';</pre>
              <p align="center">&nbsp;</p>
              <table width="300" border="0">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js08cond.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js10meth.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>
              <hr>

              <p align="justify"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Ce
                  document intitul&eacute; &laquo;Javascript - Les fonctions&raquo; issu
                de l'encyclop&eacute;die
                informatique Comment &Ccedil;a Marche (<a href="http://www.commentcamarche.net/" target="_blank">www.commentcamarche.net</a>)
                est mis &agrave; disposition sous les termes de la licence Creative
                Commons. Vous pouvez copier, modifier des copies de cette page,
                dans les conditions fix&eacute;es par la licence, tant que cette
              note appara&icirc;t clairement. </font></p>
              <p align="center">&nbsp;</p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
