<html>
<head>
<title>Mon javascript - Cours de javascript</title>
<meta name="Description" lang="fr" content="Webmasters, Mon javascript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="Monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF- http://www.Monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
</head>
<body bgcolor="#FFFFFF">
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
	<div align="center"><a href="index.php">Cours de Javascript</a><a href="index.php">
</a></div>
<p>  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js01intro.php">Introduction au Javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js02implant.php">Implantation du code</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js03var.php">Variables javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js04tab.php">Tableaux javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js05char.php">Cha&icirc;ne de caract&egrave;res</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js06even.php">&Eacute;v&eacute;nements
  javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js07oper.php">Op&eacute;rateurs</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js08cond.php">Structures conditionnelles</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js09fonc.php">Fonctions</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js10meth.php">M&eacute;thodes</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js11dial.php">Bo&icirc;tes
  de dialogue</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js12objet.php">La notion d'objet</a><br>
  <font color="#CCCCCC"><strong>Objets de Javascript</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js13noyau.php">Objets du noyau</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js14array.php">Objet Array</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js15boolean.php">Objet Boolean</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js16date.php">Objet Date</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js17math.php">Objet Math</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js18regexp.php">Objet RegExp</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js19string.php">Objet String</a><br>
  <font color="#CCCCCC"><strong>Objets du navigateur</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js20objets.php">Pr&eacute;sentation
  des objets</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js21window.php">Objet window</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js22navig.php">Objet navigator</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js23history.php">Objet history</a></p>
<p align="center"><font color="#FFFFFF">- - - - - - - -</font> </p> 

	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="left"> 
              <h2 align="center"> 
                Les m&eacute;thodes              </h2>
              
              <table width="300" border="0" align="right">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js09fonc.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js11dial.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>
              <h2>&nbsp;</h2>
              <h2><br>
              <a name="methode" class="ancre"></a>Qu'appelle-t-on une m&eacute;thode ?</h2>
              <p align="justify">Une m&eacute;thode est une fonction associ&eacute;e &agrave; un
                objet, c'est-&agrave;-dire une action que l'on peut faire ex&eacute;cuter &agrave; un
                objet. Les m&eacute;thodes des objets du navigateur sont des
                fonctions d&eacute;finies &agrave; l'avance par les normes HTML,
                on ne peut donc pas les modifier, il est toutefois possible de
                cr&eacute;er une m&eacute;thode personnelle pour un objet que
                l'on a cr&eacute;&eacute; soi-m&ecirc;me. Prenons par exemple
                une page HTML, elle est compos&eacute;e d'un objet appel&eacute; <b><i>document</i></b>.
                L'objet <b><i>document</i></b> a par exemple la m&eacute;thode
                write() qui lui est associ&eacute;e et qui permet de modifier
                le contenu de la page HTML en affichant du texte. Une m&eacute;thode
                s'appelle un peu comme une propri&eacute;t&eacute;, c'est-&agrave;-dire
                de la mani&egrave;re suivante&nbsp;:
              <pre class="Code">window.objet1.objet2.methode()</pre>
              <p align="justify">Dans le cas de la m&eacute;thode <b><i>write()</i></b>,
                l'appel se fait comme suit&nbsp;:
              <pre class="Code">window.document.write()</pre>
              <a name="write" class="ancre"></a>
              <h2>La m&eacute;thode <i>write</i></h2>
              <p align="justify">La m&eacute;thode <i>write()</i> de l'objet <i>document</i> permet
                de modifier de fa&ccedil;on dynamique le contenu d'une page HTML.
                Voici la syntaxe de la m&eacute;thode <i>write()</i>&nbsp;:
              <pre class="Code">window.document.write(expression1, expression2, ...)</pre>
              <p align="justify">Cette m&eacute;thode permet d'&eacute;crire
                le r&eacute;sultat des expressions pass&eacute;es en param&egrave;tre
                dans le document dans lequel elle est utilis&eacute;e. Il est
                ainsi possible d'uttiliser la m&eacute;thode <i>write()</i> de
                diff&eacute;rentes fa&ccedil;ons&nbsp;:
              <ul>
                <li>soit en passant directement le texte en param&egrave;tres&nbsp;: <br/>
                    <b>document.write("bonjour");</b> <br/>
                    qui aura pour effet de concat&eacute;ner la cha&icirc;ne
                    'bonjour' &agrave; l'endroit o&ugrave; est plac&eacute; le
                    script</li>
                <li>soit en passant le texte par l'interm&eacute;diaire d'une
                  variable&nbsp;:
                    <pre class="Code">Chaine='bonjour';

document.write(Chaine);</pre>
    Ce qui aura pour effet de concat&eacute;ner la cha&icirc;ne 'bonjour' (contenue
    dans la variable <i>Chaine</i>)&agrave; l'endroit o&ugrave; est plac&eacute; le
    script</li>
                <li>soit en utilisant les deux&nbsp;:
                    <pre class="Code">Chaine='bonjour';

document.write('je vous passe le ' + Chaine);</pre>
                    <br/>
                    Ce qui aura pour effet de concat&eacute;ner la cha&icirc;ne
                    'bonjour' (contenue dans la variable <i>Chaine</i>) &agrave; la
                    suite de la cha&icirc;ne de caract&egrave;re 'je vous passe
                    le' dans la page HTML </li>
                <li>soit en ins&eacute;rant directement une expression, qui sera &eacute;valu&eacute;e
                  dans un premier temps et dont le r&eacute;sultat sera ensuite
                  affich&eacute;:
    <pre class="Code">Chaine='La racine carr&eacute;e de 2 vaut : ';

document.write(Chaine+Math.sqrt(2));</pre>
                </li>
              </ul>
              Il est notamment possible d'utiliser des balises
              HTML &agrave; l'int&eacute;rieur m&ecirc;me de la
m&eacute;thode <i>write</i>&nbsp;:
<pre class="Code">document.write('&lt;font color="#FF0000"&gt;Bonjour&lt;/font&gt;');</pre>
<p><a name="writein" class="ancre"></a>
</p>
<p align="center">
  <!--Code � ins�rer jjspub -->
  <script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
  <!--Code � ins�rer jjspub -->
</p>
<h2>La m&eacute;thode <i>writeln</i></h2>
<p align="justify">La m&eacute;thode <i>writeln()</i> fonctionne exactement comme
  la m&eacute;thode <i>write()</i> &agrave; la seule diff&eacute;rence qu'elle
  ajoute un retour chariot &agrave; la fin de la cha&icirc;ne. <br/>
  Or un retour chariot (en HTML) est ignor&eacute; par le navigateur (Rappel:
  un retour &agrave; la ligne se fait avec la balise &lt;BR&gt;). Cette m&eacute;thode
  n'a donc un avantage que lorsqu'elle est utilis&eacute;e dans des &eacute;l&eacute;ments
  HTML sensibles aux retours &agrave; la ligne, par exemple entre les balises &lt;PRE&gt; et &lt;/PRE&gt; qui
  formattent le texte comme dans un fichier texte (et qui prend donc en compte
  les retours &agrave; la ligne). <a name="propre" class="ancre"></a>
<h2>D&eacute;finir une m&eacute;thode pour un objet</h2>
<p align="justify">Il est possible de d&eacute;finir une m&eacute;thode pour
  un type d'<a href="js09fonc.php#defobj">objet que l'on a cr&eacute;&eacute;</a> en
  incluant une fonction en tant que propri&eacute;t&eacute; d'un objet. Reprenons
  l'exemple de l'arbre&nbsp;:
<p align="justify">On d&eacute;finit tout d'abord un propri&eacute;taire&nbsp;:
<pre class="Code">function Proprietaire(Nom, Prenom) {
Proprietaire.Nom = Nom;

Proprietaire.Prenom = Prenom;

}</pre>
<p align="justify">Puis on cr&eacute;e une fonction qui affiche le nom du propri&eacute;taire
  d'un arbre ainsi que quelques caract&eacute;ristiques de celui-ci&nbsp;:
<pre class="Code">function AfficheInfos() {
alert(this.Proprietaire.Prenom + this.Proprietaire.Nom + 'possede un' + this.Type);

}</pre>
<p align="justify">Il suffit maintenant de d&eacute;finir l'objet <i>Arbre</i> comme
  suit&nbsp;:
<pre class="Code">function Arbre(Type, Taille, Age, Proprietaire, AfficheInfos) {
this.Type = Type;

this.Taille = Taille;

this.Age = Age;

this.Proprietaire = Proprietaire;

this.AfficheInfos = AfficheInfos;

}</pre>
<p align="justify">Le fait de taper <i>Arbre1.AfficheInfos()</i> aura pour effet
  de produire un message d'alerte du type&nbsp;:
<pre class="Code">Ren&eacute; Dupont poss&egrave;de un tilleul</pre>
<br/>
Car la m&eacute;thode <i>AfficheInfos()</i> est appliqu&eacute;e &agrave; l'objet <i>Arbre1</i>.
<p align="center">&nbsp;  </p>
              <table width="300" border="0">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js09fonc.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js11dial.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>
              <hr>

              <p align="justify"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Ce
                  document intitul&eacute; &laquo;Javascript - Les m&eacute;thodes&raquo; issu
                de l'encyclop&eacute;die
                informatique Comment &Ccedil;a Marche (<a href="http://www.commentcamarche.net/" target="_blank">www.commentcamarche.net</a>)
                est mis &agrave; disposition sous les termes de la licence Creative
                Commons. Vous pouvez copier, modifier des copies de cette page,
                dans les conditions fix&eacute;es par la licence, tant que cette
              note appara&icirc;t clairement. </font></p>
              <p align="center">&nbsp;</p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
