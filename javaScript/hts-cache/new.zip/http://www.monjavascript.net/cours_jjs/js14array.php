<html>
<head>
<title>Mon javascript - Cours de javascript</title>
<meta name="Description" lang="fr" content="Webmasters, Mon javascript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="Monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF- http://www.Monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
</head>
<body bgcolor="#FFFFFF">
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
	<div align="center"><a href="index.php">Cours de Javascript</a><a href="index.php">
</a></div>
<p>  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js01intro.php">Introduction au Javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js02implant.php">Implantation du code</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js03var.php">Variables javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js04tab.php">Tableaux javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js05char.php">Cha&icirc;ne de caract&egrave;res</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js06even.php">&Eacute;v&eacute;nements
  javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js07oper.php">Op&eacute;rateurs</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js08cond.php">Structures conditionnelles</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js09fonc.php">Fonctions</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js10meth.php">M&eacute;thodes</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js11dial.php">Bo&icirc;tes
  de dialogue</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js12objet.php">La notion d'objet</a><br>
  <font color="#CCCCCC"><strong>Objets de Javascript</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js13noyau.php">Objets du noyau</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js14array.php">Objet Array</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js15boolean.php">Objet Boolean</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js16date.php">Objet Date</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js17math.php">Objet Math</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js18regexp.php">Objet RegExp</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js19string.php">Objet String</a><br>
  <font color="#CCCCCC"><strong>Objets du navigateur</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js20objets.php">Pr&eacute;sentation
  des objets</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js21window.php">Objet window</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js22navig.php">Objet navigator</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js23history.php">Objet history</a></p>
<p align="center"><font color="#FFFFFF">- - - - - - - -</font> </p> 

	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="left"> 
              <h2 align="center"> 
                L'objet Array<br>
              </h2>
              <table width="300" border="0" align="right">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js13noyau.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js15boolean.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>              
              <h2>&nbsp;</h2>
              <h2><br>
                <a name="string" class="ancre"></a>Les particularit&eacute;s
                de l'objet <i>Array</i></h2>
              <p align="justify">L'objet Array est un objet du noyau Javascript
                permettant de cr&eacute;er et de manipuler des <a href="js04tab.php">tableaux</a>.
              <pre align="justify">Voici la syntaxe &agrave; utiliser pour cr&eacute;er                 une variable tableau&nbsp;:              </pre>
              <pre class="Code">var x = new Array(element1[, element2, ...]);</pre>
Si aucun &eacute;l&eacute;ment n'est pr&eacute;cis&eacute; en param&egrave;tre,
le tableau
est vide &agrave; la cr&eacute;ation. Dans le cas contraire, il sera initialis&eacute; avec
les valeurs des &eacute;l&eacute;ments pass&eacute;s en param&egrave;tres. <a name="proprietes" class="ancre"></a>
<h2>Les propri&eacute;t&eacute;s de l'objet <i>Array</i></h2>
<p align="justify">L'objet Array poss&egrave;de deux propri&eacute;t&eacute;s
  caract&eacute;ristiques: les propri&eacute;t&eacute;s <i>input</i> et <i>length</i>.
<p align="justify">Le tableau suivant d&eacute;crit les propri&eacute;t&eacute;s
  de l'objet <i>Array</i>.
<p align="justify">
<table class="ccm">
  <tr>
    <th>Propri&eacute;t&eacute;</th>
    <th>description</th>
  </tr>
  <tr>
    <td><b>constructor</b></td>
    <td>Cette propri&eacute;t&eacute; contient le constructeur de l'objet <i>Array</i>.</td>
  </tr>
  <tr>
    <td><b>input</b></td>
    <td>Cette propri&eacute;t&eacute; permet de faire une recherche dans le tableau &agrave; l'aide
      d'une expression r&eacute;guli&egrave;re</td>
  </tr>
  <tr>
    <td><b>length</b></td>
    <td>Cette propri&eacute;t&eacute; contient le nombre d'&eacute;l&eacute;ments
      du tableau.</td>
  </tr>
  <tr>
    <td><b>prototype</b></td>
    <td>Cette propri&eacute;t&eacute; permet d'ajouter des propri&eacute;t&eacute;s
      personnalis&eacute;es &agrave; l'objet.</td>
  </tr>
</table>
<a name="methodes" class="ancre"></a>
<h2>Les m&eacute;thodes standards de l'objet <i>Array</i></h2>
<p align="justify">Le tableau suivant d&eacute;crit les m&eacute;thodes de l'objet <i>Array</i>.
<p align="justify">
<table class="ccm">
  <tr>
    <th>M&eacute;thode</th>
    <th>description</th>
  </tr>
  <tr>
    <td><b>concat(</b>tab1, tab2[, tab3, ...]<b>)</b></td>
    <td>Cette m&eacute;thode permet de concat&eacute;ner plusieurs tableaux,
      c'est-&agrave;-dire de cr&eacute;er un tableau &agrave; partir des diff&eacute;rents
      tableaux pass&eacute;s en param&egrave;tre.</td>
  </tr>
  <tr>
    <td><b>join(</b>tableau<b>)</b> ou <b>Tableau.join()</b></td>
    <td>Cette m&eacute;thode renvoie une cha&icirc;ne de caract&egrave;res contenant
      tous les &eacute;l&eacute;ments du tableau.</td>
  </tr>
  <tr>
    <td><b>pop(</b>tableau<b>)</b> ou <b>Tableau.pop()</b></td>
    <td>Cette m&eacute;thode supprime le dernier &eacute;l&eacute;ment du tableau
      et retourne sa valeur.</td>
  </tr>
  <tr>
    <td><b>Tableau.push(</b>valeur1[, valeur2, ...]<b>)</b></td>
    <td>Cette m&eacute;thode ajoute un ou plusieurs &eacute;l&eacute;ments au
      tableau.</td>
  </tr>
  <tr>
    <td><b>Tableau.reverse()</b></td>
    <td>Cette m&eacute;thode inverse l'ordre des &eacute;l&eacute;ments du tableau.</td>
  </tr>
  <tr>
    <td><b>Tableau.shift()</b></td>
    <td>Cette m&eacute;thode supprime le premier &eacute;l&eacute;ment du tableau.</td>
  </tr>
  <tr>
    <td><b>Tableau.slice()</b></td>
    <td>Cette m&eacute;thode renvoie un tableau contenant une partie (extraction)
      des &eacute;l&eacute;ments d'un tableau.</td>
  </tr>
  <tr>
    <td><b>Tableau.splice()</b></td>
    <td>Cette m&eacute;thode ajoute/retire des &eacute;l&eacute;ments d'un tableau.</td>
  </tr>
  <tr>
    <td><b>Tableau.sort()</b></td>
    <td>Cette m&eacute;thode permet de trier les &eacute;l&eacute;ments d'un
      tableau.</td>
  </tr>
  <tr>
    <td><b>Tableau.unshift(</b>valeur1[, valeur2, ...]<b>)</b></td>
    <td>Cette m&eacute;thode renvoie le code source qui a permis de cr&eacute;er
      l'objet <i>Array</i>.</td>
  </tr>
  <tr>
    <td><b>Tableau.toString()</b></td>
    <td>Cette m&eacute;thode renvoie la cha&icirc;ne de caract&egrave;res correspond &agrave; l'instruction
      qui a permis de cr&eacute;er l'objet <i>Array</i>.</td>
  </tr>
  <tr>
    <td><b>Tableau.unshift()</b></td>
    <td>Cette m&eacute;thode permet dajouter un ou plusieurs &eacute;l&eacute;ment
      au d&eacute;but du tableau.</td>
  </tr>
  <tr>
    <td><b>Tableau.valueOf</b></td>
    <td>Cette m&eacute;thode retourne tout simplement la valeur de l'objet <i>Array</i> auquel
      elle fait r&eacute;f&eacute;rence.</td>
  </tr>
</table>
<p align="center">
  <!--Code � ins�rer jjspub -->
  <script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
  <!--Code � ins�rer jjspub -->
</p>
              <table width="300" border="0">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js13noyau.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js15boolean.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>
              <hr>

              <p align="justify"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Ce
                  document intitul&eacute; &laquo;Javascript - L'objet Array&raquo; issu
                de l'encyclop&eacute;die
                informatique Comment &Ccedil;a Marche (<a href="http://www.commentcamarche.net/" target="_blank">www.commentcamarche.net</a>)
                est mis &agrave; disposition sous les termes de la licence Creative
                Commons. Vous pouvez copier, modifier des copies de cette page,
                dans les conditions fix&eacute;es par la licence, tant que cette
              note appara&icirc;t clairement. </font></p>
              <p align="center">&nbsp;</p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
