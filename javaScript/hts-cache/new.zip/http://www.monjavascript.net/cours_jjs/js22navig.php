<html>
<head>
<title>Mon javascript - Cours de javascript</title>
<meta name="Description" lang="fr" content="Webmasters, Mon javascript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="Monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF- http://www.Monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
</head>
<body bgcolor="#FFFFFF">
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
	<div align="center"><a href="index.php">Cours de Javascript</a><a href="index.php">
</a></div>
<p>  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js01intro.php">Introduction au Javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js02implant.php">Implantation du code</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js03var.php">Variables javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js04tab.php">Tableaux javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js05char.php">Cha&icirc;ne de caract&egrave;res</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js06even.php">&Eacute;v&eacute;nements
  javascript</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js07oper.php">Op&eacute;rateurs</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js08cond.php">Structures conditionnelles</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js09fonc.php">Fonctions</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js10meth.php">M&eacute;thodes</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js11dial.php">Bo&icirc;tes
  de dialogue</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js12objet.php">La notion d'objet</a><br>
  <font color="#CCCCCC"><strong>Objets de Javascript</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js13noyau.php">Objets du noyau</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js14array.php">Objet Array</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js15boolean.php">Objet Boolean</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js16date.php">Objet Date</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js17math.php">Objet Math</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js18regexp.php">Objet RegExp</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js19string.php">Objet String</a><br>
  <font color="#CCCCCC"><strong>Objets du navigateur</strong></font><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js20objets.php">Pr&eacute;sentation
  des objets</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js21window.php">Objet window</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js22navig.php">Objet navigator</a><br>
  <img src="http://www.Monjavascript.net/im/flechep.gif" width="7" height="7"><a href="js23history.php">Objet history</a></p>
<p align="center"><font color="#FFFFFF">- - - - - - - -</font> </p> 

	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="left"> 
              <h2 align="center"> 
                L'objet Navigator <br>
              </h2>
              <table width="300" border="0" align="right">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js21window.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js23history.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>              
              <h2>&nbsp;</h2>
              <h2><br>
                <a name="navig" class="ancre"></a>Les particularit&eacute;s
                de l'objet <i>navigator</i></h2>
              <p align="justify">L'objet <i>navigator</i> est un objet qui permet
                de r&eacute;cup&eacute;rer des informations sur le navigateur
                qu'utilise le visiteur. Cela para&icirc;t totalement inutile &agrave; premi&egrave;re
                vue, toutefois, comme vous le savez s&ucirc;rement, il existe
                de grandes diff&eacute;rences entre diff&eacute;rentes versions
                d'un m&ecirc;me navigateur (int&egrave;gration de nouvelles technologies),
                ainsi qu'entre des navigateurs de types diff&eacute;rents (les
                deux antagonistes sont g&eacute;n&eacute;ralement Netscape Navigator &copy; et
                Microsoft Internet Explorer qui d'une part n'interpr&egrave;tent
                pas toutes les balises HTML et les instructions Javascript de
                la m&ecirc;me mani&egrave;re, et qui, d'autre part, poss&egrave;de
                parfois des balises HTML propri&egrave;taires, c'est-&agrave;-dire
                qui leur sont propres...).
              <p align="justify">Toutes les propri&eacute;t&eacute;s de l'objet <i>navigator</i> sont
                en lecture seule, elles servent uniquement &agrave; r&eacute;cup&eacute;rer
                des informations et non &agrave; les modifier (il serait idiot
                de vouloir modifier les informations d'un navigateur...). <a name="propriete" class="ancre"></a>
              <h2>Les propri&eacute;t&eacute;s de l'objet <i>navigator</i></h2>
              <p align="justify">Les propri&eacute;t&eacute;s de l'objet <i>navigator</i> sont
                peu nombreuses, elles permettent en fait de retourner des portions
                de l'information sur votre navigateur qui est en fait une cha&icirc;ne
                de caract&egrave;res. Etant donn&eacute; que ces propri&eacute;t&eacute;s
                sont statiques, il est n&eacute;cessaires de les faire pr&eacute;c&eacute;der
                par <i>navigator</i>&nbsp;:
              <pre class="Code">navigator.propriete</pre>
Dans le tableau suivant, la colonne de droite donne le r&eacute;sultat fourni
par la propri&eacute;t&eacute; pour votre
navigateur&nbsp;:
<pre class="Code">&lt;script language="Javascript"&gt;

&lt;!--
document.write(navigator.propriete);

//--&gt;

&lt;/script&gt;</pre>
<p align="justify">
<table class="ccm">
  <tr>
    <th>Propri&eacute;t&eacute;</th>
    <th>Description</th>
    <th>Pour votre navigateur</th>
  </tr>
  <tr>
    <td><i>appCodeName</i></td>
    <td> retourne le code du navigateur. Un navigateur a g&eacute;n&eacute;ralement
      pour nom de code <i>Mozilla</i>, le moteur utilis� par la plupart des navigateurs
      (internet explorer, netscape, mais aussi beaucoup de navigateurs sous Unix...).
      Cette valeur sera diff�rente si le navigateur du client est pas bas� sur
      un autre moteur (e.g. Opera, ...). </td>
    <td>&nbsp;
        <script language="Javascript">

<!--
document.write(navigator.appCodeName);

// -->

  </script>
    </td>
  </tr>
  <tr>
    <td><i>appName</i></td>
    <td> retourne le nom du navigateur (la plupart du temps la marque). Cette
      propri&eacute;t&eacute; est utile pour diff&eacute;rencier les navigateurs
      de Netscape et de Microsoft). </td>
    <td>&nbsp;
        <script language="Javascript">

<!--
document.write(navigator.appName);

// -->

  </script>
    </td>
  </tr>
  <tr>
    <td><i>appVersion</i></td>
    <td> retourne la version du navigateur. Cette propri&eacute;t&eacute; prend
      la forme suivante&nbsp;: <br/>
      Num&eacute;ro de version( plateforme (syst&egrave;me d'exploitation), nationalit&eacute;) <br/>
      Elle est utile pour conna&icirc;tre le syst&egrave;me d'exploitation de
      l'utilisateur, mais surtout, associ&eacute;e avec la propri&eacute;t&eacute; <i>navigator.appName</i> elle
      permet de conna&icirc;tre les fonctionnlit&eacute;s que supporte le navigateur
      de votre visiteur. </td>
    <td>&nbsp;
        <script language="Javascript">

<!--
document.write(navigator.appVersion);

// -->

  </script>
    </td>
  </tr>
  <tr>
    <td><i>language</i></td>
    <td> renvoie une cha&icirc;ne de caract&egrave;re donnant la langue utilis&eacute;e
      par la navigateur du client. Cette propri&eacute;t&eacute; n'est comprise
      que par les navigateurs supportant les versions 1.2 et sup&eacute;rieures
      de Javascript. </td>
    <td>&nbsp;
        <script language="Javascript">

<!--
document.write(navigator.language);

// -->

  </script>
    </td>
  </tr>
  <tr>
    <td><i>mimeTypes</i></td>
    <td> Cette propri&eacute;t&eacute; renvoie un tableau r&eacute;pertoriant
      les types MIME support&eacute;s par le navigateur, c'est-&agrave;-dire
      les types de fichiers enregistr&eacute;s. </td>
    <td>&nbsp;
        <script language="Javascript">

<!--
for(var i=0;i<navigator.mimeTypes.length;i++) {
document.write('<br>'+navigator.mimeTypes[i].type);

}

// -->

  </script>
    </td>
  </tr>
  <tr>
    <td><i>platform</i></td>
    <td> Cette propri&eacute;t&eacute; renvoie une cha&icirc;ne de caract&egrave;re
      indiquant la plateforme sur laquelle le navigateur fonctionne, c'est-&agrave;-dire
      le syst&egrave;me d'exploitation du client. Cette propri&eacute;t&eacute; n'est
      comprise que par les navigateurs supportant les versions 1.2 et sup&eacute;rieures
      de Javascript. </td>
    <td>&nbsp;
        <script language="Javascript">

<!--
document.write(navigator.platform);

// -->

  </script>
    </td>
  </tr>
  <tr>
    <td><i>plugins</i></td>
    <td> Cette propri&eacute;t&eacute; renvoie un tableau contenant la liste
      des plugins install&eacute;s sur la machine cliente. </td>
    <td>&nbsp;
        <script language="Javascript">

<!--
for(var i=0;i<navigator.plugins.length;i++) {
document.write('<br>'+navigator.plugins[i].filename);

}

// -->

  </script>
    </td>
  </tr>
  <tr>
    <td><i>userAgent</i></td>
    <td> retourne la cha&icirc;ne de caract&egrave;re qui comprend toutes les
      informations sur le navigateur de client. Les propri&eacute;t&eacute;s
      ci-dessus offrent un moyen pratique de r&eacute;cup&eacute;rer une partie
      de cette information. </td>
    <td>&nbsp;
        <script language="Javascript">

<!--
document.write(navigator.userAgent);

// -->

  </script>
    </td>
  </tr>
</table>
<a name="methodes" class="ancre"></a>
<h2>Les m&eacute;thodes de l'objet <i>navigator</i></h2>
<p align="justify">Les m&eacute;thodes de l'objet <i>navigator</i> permettent
  d'effectuer certaines op&eacute;rations concernant le navigateur du client.
  Dans la mesure o&ugrave; il s'agit de m&eacute;thodes statiques, il est indispensable
  de les faire pr&eacute;c&eacute;der par <i>navigator</i>.
<p align="justify">
<table class="ccm">
  <tr>
    <th>M&eacute;thode</th>
    <th>Description</th>
    <th>Pour votre navigateur</th>
  </tr>
  <tr>
    <td><i>javaEnabled()</i></td>
    <td> Cette m&eacute;thode permet de v&eacute;rifier si le navigateur du client
      est configur&eacute; pour ex&eacute;cuter des applets <a href="../java/javaintro.php3">Java</a>. </td>
    <td>&nbsp;
        <script language="Javascript">

<!--
document.write(navigator.javaEnabled());

// -->

  </script>
    </td>
  </tr>
  <tr>
    <td><i>plugins.refresh()</i></td>
    <td> La m&eacute;thode <i>refresh()</i> de la propri&eacute;t&eacute; <i>plugin</i> permet
      de rafra&icirc;chir la liste des plugins install&eacute;s sur le poste
      client. </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><i>preference("preference",valeur)</i></td>
    <td> Cette m&eacute;thode support&eacute;e &agrave; partir de la version
      1.2 de Javascript permet &agrave; un script sign&eacute; de red&eacute;finir
      les pr&eacute;f&eacute;rences du navigateur. Le script doit ainsi obtenir
      les privil&egrave;ges suffisants pour pouvoir effectuer ces actions. </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><i>SavePreferences()</i></td>
    <td> Cette m&eacute;thode support&eacute;e &agrave; partir de la version
      1.2 de Javascript permet de sauvegarder les modifications apport&eacute;es
      aux pr&eacute;f&eacute;rences du navigateur du client. </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><i>taintEnabled()</i></td>
    <td> Cette m&eacute;thode permet de v&eacute;rifier que la protection des
      donn&eacute;es a &eacute;t&eacute; activ&eacute;e gr&acirc;ce &agrave; la
      m&eacute;thode <i>taint()</i> de Javascript. Cette m&eacute;thode est obsol&egrave;te
      depuis la version 1.2 de Javascript, et ne fonctionne ainsi que sur <i>Netscape
      Navigator 3</i>. </td>
    <td>&nbsp;</td>
  </tr>
</table>
<a name="utiliser" class="ancre"></a>
<h2>Utiliser efficacement ces propri&eacute;t&eacute;s</h2>
<p align="justify">Les navigateurs ne supportent pas tous le Javascript de la
  m&ecirc;me fa&ccedil;on, ainsi, suivant les instructions Javascript que l'on
  utilisera (suivant qu'il s'agit de Javascript 1.0, 1.1, ou 1.2) il faudra ex&eacute;cuter
  des instructions diff&eacute;rentes. Par respect pour vos visiteurs il est
  g&eacute;n&eacute;ralement bon de mettre en d&eacute;but de script une fonction
  qui permet de d&eacute;terminer la version du navigateur (et/ou sa marque)
  et ex&eacute;cuter les instructions appropri&eacute;es en fonction du r&eacute;sultat.
<p align="justify">Voici une grille avec les navigateurs, les valeurs de propri&eacute;t&eacute;s
  et quelques fonctionalit&eacute;s associ&eacute;es &agrave; ceux-ci&nbsp;:
<p align="center">
  <!--Code � ins�rer jjspub -->
  <script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
  <!--Code � ins�rer jjspub -->
<br>
<table class="ccm">
  <tr>
    <th>Navigateur</th>
    <th>Version</th>
    <th>navigator.appName</th>
    <th>navigator.appVersion</th>
    <th>Javascript</th>
  </tr>
  <tr>
    <td>Ns Navigator</td>
    <td>2</td>
    <td>Netscape</td>
    <td>2.0 (Win95; I)</td>
    <td>1.0</td>
  </tr>
  <tr>
    <td>Ns Navigator</td>
    <td>3</td>
    <td>Netscape</td>
    <td>3.xx (Win95; I)</td>
    <td>1.1</td>
  </tr>
  <tr>
    <td>Ns Communicator</td>
    <td>4</td>
    <td>Netscape</td>
    <td>4.xx (Win95; I)</td>
    <td>1.1</td>
  </tr>
  <tr>
    <td>Ms Internet Explorer</td>
    <td>3</td>
    <td>Microsoft Internet Explorer</td>
    <td>2.0 (compatible; MSIE 3.0x; Win*)</td>
    <td>1.0</td>
  </tr>
  <tr>
    <td>Ms Internet Explorer</td>
    <td>4</td>
    <td>Microsoft Internet Explorer</td>
    <td>4.0x (compatible; MSIE 4.0x; Win*)</td>
    <td>1.2</td>
  </tr>
  <tr>
    <td>Ms Internet Explorer</td>
    <td>5</td>
    <td>Microsoft Internet Explorer</td>
    <td>5.xx (compatible; MSIE 5.0x; Win*)</td>
    <td>1.2</td>
  </tr>
</table>
<a name="exemple" class="ancre"></a>
<h2>Exemple de script</h2>
<p align="justify">Il est parfois bon de pouvoir ex&eacute;cuter un ensemble
  d'instructions diff&eacute;rent selon que le navigateur utilis&eacute; est
  Netscape Navigator ou Microsoft Internet Explorer, voici un exemple de petit
  script permettant la distinction&nbsp;:
<pre class="Code">Nom = navigator.appName;

&nbsp;

if (Nom == 'Netscape') {
placer ici les instructions &agrave; ex&eacute;cuter s'il s'agit
de Netscape Navigator 4 ou sup&eacute;rieur
}

&nbsp;

if (Nom == 'Microsoft Internet Explorer') {
placer ici les instructions &agrave; ex&eacute;cuter s'il s'agit
de Microsoft Internet Explorer 4 ou sup&eacute;rieur
}</pre>
<p align="justify">Une m&eacute;thode am&eacute;lior&eacute;e si jamais on a
  souvent besoin de faire le test de navigateur, car l'acc&egrave;s &agrave; l'objet <i>navigator</i> n'est
  effectu&eacute; qu'une seule fois. Ensuite deux variables bool&eacute;enne
  sont utilis&eacute;es, et le test consiste uniquement &agrave; regarder si
  la variable contient 1 au 0 et le navigateur n'a pas besoin de comparer la
  chaine <i>nom</i> &agrave; chaque test de navigateur...
<pre class="Code">Nom = navigator.appName;

ns = (Nom == 'Netscape') ? 1:0
ie = (Nom == 'Microsoft Internet Explorer') ? 1:0
&nbsp;

if (ns) {
placer ici les instructions &agrave; ex&eacute;cuter s'il s'agit
de Netscape Navigator 4 ou sup&eacute;rieur
}

&nbsp;

if (ie) {
placer ici les instructions &agrave; ex&eacute;cuter s'il s'agit
de Microsoft Internet Explorer 4 ou sup&eacute;rieur
}</pre>
<p align="justify">Imaginons que l'on veuille maintenant afficher du DHTML (HTML
  dynamique, c'est-&agrave;-dire dont les objets peuvent bouger et &ecirc;tre
  modifi&eacute;s &agrave; loisir...), il faut alors v&eacute;rifier que les
  versions des navigateurs sont sup&eacute;rieures &agrave; 4 (seuls Netscape
  Navigator 4 (ou sup&eacute;rieur) et Microsoft Internet Explorer 4 (ou sup&eacute;rieur)
  le supportent.
<p align="justify">Voici le script permettant de v&eacute;rifier que les versions
  sont sup&eacute;rieures &agrave; 4&nbsp;:
<pre class="Code">Nom = navigator.appName;

Version = navigator.appVersion;

ns4 = (Nom == 'Netscape' && Version &gt;= 4 ) ? 1:0
ie4 = (Nom == 'Microsoft Internet Explorer' && Version &gt;= 4 ) ? 1:0
&nbsp;

if (ns4) {
placer ici les instructions &agrave; ex&eacute;cuter s'il s'agit de
Netscape Navigator 4 ou sup&eacute;rieur
}

&nbsp;

if (ie4) {
placer ici les instructions &agrave; ex&eacute;cuter s'il s'agit de
Microsoft Internet Explorer 4 ou sup&eacute;rieur
}</pre>
<p align="center">&nbsp;</p>
              <table width="300" border="0">
                <tr>
                  <td width="100"><div align="center"></div>
                  </td>
                  <td width="100"><div align="center"><a href="js21window.php"><img src="images/flchg.gif" width="40" height="32" border="0"></a></div>
                  </td>
                  <td><div align="center"><a href="js23history.php"><img src="images/flchd.gif" width="40" height="32" border="0"></a></div>
                  </td>
                </tr>
              </table>
              <hr>

              <p align="justify"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Ce
                  document intitul&eacute; &laquo;Javascript - L'objet Navigator &raquo; issu
                de l'encyclop&eacute;die
                informatique Comment &Ccedil;a Marche (<a href="http://www.commentcamarche.net/" target="_blank">www.commentcamarche.net</a>)
                est mis &agrave; disposition sous les termes de la licence Creative
                Commons. Vous pouvez copier, modifier des copies de cette page,
                dans les conditions fix&eacute;es par la licence, tant que cette
              note appara&icirc;t clairement. </font></p>
              <p align="center">&nbsp;</p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
