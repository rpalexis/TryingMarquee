<html>
<head>
<title>Document sans titre</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#9966FF" link="#FFFFFF">
<div align="center"> 
<input name="button" type='button' onClick='window.close()' value='Fermer cette fen&ecirc;tre'>
</div>
<table width="90%" height="80%" border="0" align="center">
  <tr>
    <td><div align="center">
        <!--Code � ins�rer jjspub --><br><br><img src="http://www.monjavascript.net/im/mjs-logo.gif" width="90" height="85" border="0" alt="Mon JavaScript  http://www.monjavascript.net">
<br><br><br><br><br><br>
&nbsp;<!--Code � ins�rer jjspub -->
      </div></td>
  </tr>
</table>
<div align="center"><a href="javascript:window.close();">Fermer cette fen�tre</a> </div>
</body>
</html>
