<html>
<head>
<title>Mon JavaScript - Un effet de Zoom sur une Image au Survol de la Souris</title>
<meta name="Description" lang="fr" content="Webmasters, Mon JavaScript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
var coeff=4;//Coefficient de reduction
var larg=200;//largeur maxi de l'image
var haut=194;//hauteur maxi de l'image
var coeffinit=coeff;

function changer(nom_de_limage) {
if (document.images[nom_de_limage].width < larg) {
coeff = coeff-0.2;
document.images[nom_de_limage].width = Math.round(larg/coeff);
document.images[nom_de_limage].height = Math.round(haut/coeff);
chang=window.setTimeout('changer("'+document.images[nom_de_limage].name+'");',60);//vitesse de l'effet
}
else {window.clearTimeout(chang);}
}


function initial(nom_de_limage) {
if (document.images[nom_de_limage].width > larg/coeffinit) {
window.clearTimeout(chang);
coeff = coeff+0.2;
document.images[nom_de_limage].width = Math.round(larg/coeff);
document.images[nom_de_limage].height = Math.round(haut/coeff);
initi=window.setTimeout('initial("'+document.images[nom_de_limage].name+'");',60);//vitesse de l'effet
}

else {window.clearTimeout(initi);}

}
//-->
</script>
</head>
<body bgcolor="#FFFFFF">
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
		
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/cours_jjs/index.php" >Cours de javascript</a><br>
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="center"> 
              <p align="center"> 
                <br>
                <font size="2"><strong>Un Effet de Zoom sur Plusieurs Images Au Survol de La Souris</b></font></font><br>
                Merci &agrave; Sikko<br>
              voir aussi <a href="imag_zoom.php">Un Effet de Zoom sur une Image Au Survol de La Souris</a>              </p>
              <p align="center"><b>Placez votre souris sur les images ci-dessous
              pour voir l'effet.</b></p>
              <p align="center"><b> Evitez de mettre une petite image afin de
                  l'agrandir, vous risquez de perdre en qualit&eacute;. (Il est pr&eacute;f&eacute;rable 
                  que la taille maximale soit la taille r&eacute;elle)</b></p>
              <p align="center"> 
                <a href="#" onMouseOut="initial('image1')" onMouseOver="changer('image1')" ><img src="im/imaga.gif" name="image1" border="0"></a>
			  </p><p>&nbsp;</p>
				<script language="JavaScript">
                <!--
                //PLF-http://www.monjavascript.net/ 
                document.image1.width = Math.round(larg/coeff);
                document.image1.height = Math.round(haut/coeff);
                //-->
              	</script>
              	<p align="center">
			 	<a href="#" onMouseOut="initial('image2')" onMouseOver="changer('image2')" ><img src="im/imagb.gif" name="image2"  border="0"></a>
              	</p><p>&nbsp;</p>
                <script language="JavaScript">
				<!--
				//PLF-http://www.monjavascript.net/ 
				document.image2.width = Math.round(larg/coeff);
				document.image2.height = Math.round(haut/coeff);
				//-->
              	</script>
				
                <table width="100%" border="0">
                  <tr align="center">
                    <td>
				<a href="#" onMouseOut="initial('image4')" onMouseOver="changer('image4')" ><img src="im/imaga.gif" name="image4" border="0"></a>
              	<script language="JavaScript">
				<!--
				document.image4.width = Math.round(larg/coeff);
				document.image4.height = Math.round(haut/coeff);
				//-->
              	</script>
				</td><td>
				<a href="#" onMouseOut="initial('image3')" onMouseOver="changer('image3')" ><img src="im/imagc.gif" name="image3" border="0"></a>
              	<script language="JavaScript">
				<!--
				document.image3.width = Math.round(larg/coeff);
				document.image3.height = Math.round(haut/coeff);
				//-->
              	</script>
				</td><td>
				<a href="#" onMouseOut="initial('image5')" onMouseOver="changer('image5')" ><img src="im/imagb.gif" name="image5" border="0"></a>
              	<script language="JavaScript">
				<!--
				document.image5.width = Math.round(larg/coeff);
				document.image5.height = Math.round(haut/coeff);
				//-->
              	</script>
				</td>
                  </tr>
                </table>
                <p align="center">Si vous avez beaucoup d'images je vous propose <br>
                  <a href="http://www.monjavascript.net/protimage.php" target="_blank">Afficher
                  une Image dans une Popup en Neutralisant le Clic Droit</a></p>
              <div align="center"><font size="4" color="#000099">Ins&eacute;rez 
                le code ci-dessous dans votre page entre les balises d'ent&ecirc;te 
                <b><br>
                &lt;head&gt; ..... &lt;/head&gt;</b></font><br>
              </div>
              <table width="680" border="1" bordercolorlight="#000000" align="center">
                <tr> 
                  <td bgcolor="#CCCCCC"><p>&lt;script language=&quot;JavaScript&quot;&gt;<br>
&lt;!--<br>
                      //PLF-http://www.monjavascript.net/<br>                    
                      <font color="#FF0000">var coeff=4;//Coefficient de reduction<br>
                      var larg=200;//largeur maxi de l'image<br>
                      var haut=194;//hauteur maxi de l'image</font><br>
                      var coeffinit=coeff;<br>
                      <br>
                      function changer(nom_de_limage) {<br>
                      if (document.images[nom_de_limage].width &lt; larg)
                                          {<br>
                                          coeff = coeff-0.2;<br>
                                          document.images[nom_de_limage].width
                                          = Math.round(larg/coeff);<br>
                                          document.images[nom_de_limage].height
                                          = Math.round(haut/coeff);<br>
                                          chang=window.setTimeout('changer(&quot;'+document.images[nom_de_limage].name+'&quot;);',<font color="#FF00FF">60</font>);//vitesse
                                          de l'effet<br>
                                          }<br>
                                          else {window.clearTimeout(chang);}<br>
                                          } </p>
                    <p><br>
                                          function initial(nom_de_limage) {<br>
                                          if (document.images[nom_de_limage].width &gt; larg/coeffinit)
                                          {<br>
                                          window.clearTimeout(chang);<br>
                                          coeff = coeff+0.2;<br>
                                          document.images[nom_de_limage].width
                                          = Math.round(larg/coeff);<br>
                                          document.images[nom_de_limage].height
                                          = Math.round(haut/coeff);<br>
                                          initi=window.setTimeout('initial(&quot;'+document.images[nom_de_limage].name+'&quot;);',<font color="#FF00FF">60</font>);//vitesse
                                          de l'effet<br>
                                          }<br>
                      else {window.clearTimeout(initi);}<br>
                      }<br>
                      <br>
                      //--&gt;<br>
&lt;/script&gt;</p>
                    </td>
                </tr>
                <tr> 
                  <td> 
                    <div align="center"><font size="4" color="#FF0000">Corrigez 
                      comme suit</font></div>
                  </td>
                </tr>
                <tr> 
                  <td bgcolor="#FFFFFF"> 
                    <p><font color="#FF0000">Vous pouvez changer le coefficient 
                      de r&eacute;duction.<br>
                      Indiquez la taille de votre image agrandie.<br>
                      </font><font color="#FF0000"><br>
                      <font color="#FF00FF">Vous pouvez changer la vitesse de 
                      l'effet.</font></font></p>
                  </td>
                </tr>
              </table>
              <p align="center"><!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
</p>
              <div align="center"><font color="#000099" size="4">Puis ins&eacute;rez
                   le code ci-dessous &agrave; l'endroit des Images</font><br>
              </div>
              <table width="680" border="1" align="center">
                <tr> 
                  <td bgcolor="#CCCCCC">&lt;p align=&quot;center&quot;&gt; <br>
&lt;a href=&quot;#&quot; onMouseOut=&quot;initial('<font color="#FF00FF">image1</font>')&quot; onMouseOver=&quot;changer('<font color="#FF00FF">image1</font>')&quot; &gt;&lt;img
src=&quot;<font color="#FF0000">im/imaga.gif</font>&quot; name=&quot;<font color="#FF00FF">image1</font>&quot; border=&quot;0&quot;&gt;&lt;/a&gt;<br>
&lt;/p&gt;<br>
&lt;script language=&quot;JavaScript&quot;&gt;<br>
&lt;!--<br>
//PLF-http://www.monjavascript.net/ <br>
document.<font color="#FF00FF">image1</font>.width = Math.round(larg/coeff);<br>
document.<font color="#FF00FF">image1</font>.height = Math.round(haut/coeff);<br>
//--&gt;<br>
&lt;/script&gt;<br>
&lt;p align=&quot;center&quot;&gt;<br>
&lt;a href=&quot;#&quot; onMouseOut=&quot;initial('<font color="#FF00FF">image2</font>')&quot; onMouseOver=&quot;changer('<font color="#FF00FF">image2</font>')&quot; &gt;&lt;img
src=&quot;<font color="#FF0000">im/imagb.gif</font>&quot; name=&quot;<font color="#FF00FF">image2</font>&quot; border=&quot;0&quot;&gt;&lt;/a&gt;<br>
&lt;/p&gt;<br>
&lt;script language=&quot;JavaScript&quot;&gt;<br>
&lt;!--<br>
document.<font color="#FF00FF">image2</font>.width = Math.round(larg/coeff);<br>
document.<font color="#FF00FF">image2</font>.height = Math.round(haut/coeff);<br>
//--&gt;<br>
&lt;/script&gt;<br>
&lt;p align=&quot;center&quot;&gt;<br>
&lt;a href=&quot;#&quot; onMouseOut=&quot;initial('<font color="#FF00FF">image3</font>')&quot; onMouseOver=&quot;changer('<font color="#FF00FF">image3</font>')&quot; &gt;&lt;img
src=&quot;<font color="#FF0000">im/imagc.gif</font>&quot; name=&quot;<font color="#FF00FF">image3</font>&quot; border=&quot;0&quot;&gt;&lt;/a&gt;<br>
&lt;/p&gt;<br>
&lt;script language=&quot;JavaScript&quot;&gt;<br>
&lt;!--<br>
document.<font color="#FF00FF">image3</font>.width = Math.round(larg/coeff);<br>
document.<font color="#FF00FF">image3</font>.height = Math.round(haut/coeff);<br>
//--&gt;<br>
&lt;/script&gt;</td>
                </tr>
                <tr> 
                  <td> 
                    <div align="center"><font size="4" color="#FF0000">Corrigez 
                      comme suit</font></div>
                  </td>
                </tr>
                <tr> 
                  <td bgcolor="#FFFFFF">                    <p><font color="#FF0000">chemin/nom_image.(gif,jpg,...)</font><br>
                      <font color="#FF00FF">nom de l'image</font><br>
                      Lignes &agrave; &eacute;crire pour ins&eacute;rer une image:<br>
                      &lt;p align=&quot;center&quot;&gt; <br>
&lt;a href=&quot;#&quot; onMouseOut=&quot;initial('<font color="#FF00FF">image1</font>')&quot; onMouseOver=&quot;changer('<font color="#FF00FF">image1</font>')&quot; &gt;&lt;img
src=&quot;<font color="#FF0000">im/imaga.gif</font>&quot; name=&quot;<font color="#FF00FF">image1</font>&quot; border=&quot;0&quot;&gt;&lt;/a&gt;<br>
&lt;/p&gt;<br>
&lt;script language=&quot;JavaScript&quot;&gt;<br>
&lt;!--<br>
//PLF-http://www.monjavascript.net/ <br>
document.<font color="#FF00FF">image1</font>.width = Math.round(larg/coeff);<br>
document.<font color="#FF00FF">image1</font>.height = Math.round(haut/coeff);<br>
//--&gt;<br>
&lt;/script&gt; </p>
                  <p><strong>Les images peuvent &ecirc;tre plac&eacute;es s&eacute;par&eacute;ment</strong>.</p>
                  <p>En fait pour chaque image il faut &eacute;crire le code
                    suivant en modifiant le <font color="#FF00FF">nom de l'image</font>.
                    Vous pouvez le placer n'importe o&ucirc; dans votre page.</p>
                  <p>&lt;a href=&quot;#&quot; onMouseOut=&quot;initial('<font color="#FF00FF">image1</font>')&quot; onMouseOver=&quot;changer('<font color="#FF00FF">image1</font>')&quot; &gt;&lt;img
                    src=&quot;<font color="#FF0000">im/imaga.gif</font>&quot; name=&quot;<font color="#FF00FF">image1</font>&quot; border=&quot;0&quot;&gt;&lt;/a&gt;<br>
&lt;script language=&quot;JavaScript&quot;&gt;<br>
&lt;!--<br>
//PLF-http://www.monjavascript.net/ <br>
document.<font color="#FF00FF">image1</font>.width = Math.round(larg/coeff);<br>
document.<font color="#FF00FF">image1</font>.height = Math.round(haut/coeff);<br>
//--&gt;<br>
&lt;/script&gt;<br>
                  </p></td>
                </tr>
                <tr>
                  <td align="center"><font size="3" color="#FF0000">Pour des
                      images horizontales, mettez les dans un tableau</font></td>
                </tr>
                <tr>
                  <td bgcolor="#CCCCCC">&lt;table width=&quot;100%&quot; border=&quot;0&quot;&gt;<br>
&lt;tr align=&quot;center&quot;&gt;<br>
&lt;td&gt;<br>
&lt;a href=&quot;#&quot; onMouseOut=&quot;initial('image1')&quot; onMouseOver=&quot;changer('image1')&quot; &gt;&lt;img
src=&quot;im/imaga.gif&quot; name=&quot;image1&quot; border=&quot;0&quot;&gt;&lt;/a&gt;<br>
&lt;script language=&quot;JavaScript&quot;&gt;<br>
&lt;!--<br>
//PLF-http://www.monjavascript.net/ <br>
document.image1.width = Math.round(larg/coeff);<br>
document.image1.height = Math.round(haut/coeff);<br>
//--&gt;<br>
&lt;/script&gt;<br>
&lt;/td&gt;&lt;td&gt;<br>&lt;





a href=&quot;#&quot; onMouseOut=&quot;initial('image2')&quot; onMouseOver=&quot;changer('image2')&quot; &gt;&lt;img
src=&quot;im/imagc.gif&quot; name=&quot;image2&quot; border=&quot;0&quot;&gt;&lt;/a&gt;<br>
&lt;
script language=&quot;JavaScript&quot;&gt;<br>&lt;!--<br>
  document.image2.width = Math.round(larg/coeff);<br>
  document.image2.height = Math.round(haut/coeff);<br>
  //--&gt;<br>&lt;/script&gt;<br>&lt;/td&gt;&lt;td&gt;<br>&lt;
  
  
  
  
  a href=&quot;#&quot; onMouseOut=&quot;initial('image3')&quot; onMouseOver=&quot;changer('image3')&quot; &gt;&lt;img
src=&quot;im/imagb.gif&quot; name=&quot;image3&quot; border=&quot;0&quot;&gt;&lt;/a&gt;<br>
&lt;
script language=&quot;JavaScript&quot;&gt;<br>&lt;!--<br>
  document.image3.width = Math.round(larg/coeff);<br>
  document.image3.height = Math.round(haut/coeff);<br>
  //--&gt;<br>&lt;/script&gt;<br>&lt;/td&gt;<br>&lt;/tr&gt;<br>&lt;/table&gt;</td>
                </tr>
              </table>
              Si vous avez beaucoup d'images je vous propose <br>
              <a href="http://www.monjavascript.net/protimage.php" target="_blank">Afficher une Image dans une Popup en Neutralisant le Clic Droit</a><br>
              <p align="center"> </p>
              <p align="center"><a href="fairelien.php">Ce site vous a plu ?
                  Vous avez trouv&eacute; le script que vous cherchiez ?<br>
                  Faites en profiter vos visiteurs : ins&eacute;rez un lien sur
                  votre site</a></p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
