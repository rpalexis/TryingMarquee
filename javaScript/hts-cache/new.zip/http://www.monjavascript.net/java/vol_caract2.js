<!--
for (i=0;i<=message.length-1;i++) {
    document.write("<div id='spantxt"+i+"' class='spanstyle'>")
	document.write(message[i])
    document.write("</div>")
}

document.onmousemove = handlerMM;
//-->
