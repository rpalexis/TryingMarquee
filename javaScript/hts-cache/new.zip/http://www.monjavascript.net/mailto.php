<!--Code � ins�rer PUP : CPM -pubjjs -->
<!-- fin du Code � ins�rer PUP : CPM -pubjjs -->
<html>
<head>
<title>Mon JavaScript - Envoyer un mail par formulaire</title>
<meta name="Description" lang="fr" content="Webmasters, Mon JavaScript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, java script, html, langage, programme, programmation, javaScript, script, java, astuces, programmes">
<meta name="author" content="monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
function valider() {
var form_err = " "
if ( document.envoi.nom.value.length < 1) {
form_err += "Il manque le Nom. - ";
}
if ( document.envoi.PRENOM.value.length < 1) {
form_err += "Il manque le Prenom. ";
} 
if ( form_err != " ") {
alert(form_err);
return false;
}
return true 
}
//-->
</script>

</head>

<body bgcolor="#FFFFFF" >
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
		
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/cours_jjs/index.php" >Cours de javascript</a><br>
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="center"> 
              <p align="center"><font size="+3"><b>Un Formulaire pour Recevoir
                    des Mails <br>
                </b></font><b><font size="+2">sans serveur CGI<br>
                </font>Ce script utilise
le programme de messagerie associ&eacute; au navigateur de l&#8217;utilisateur.<br>
                Pour v&eacute;rifier la validit&eacute; des champs voir 
                mon script <a href="ecrivez-moi.php">Valider un Formulaire d'Envoi 
                de Mail</a><br>
                Pour <a href="mailcach.php">prot&eacute;ger votre @mail</a> des
              robots des spameurs qui collectent les adresses.</b></p>
              <p align="center">
                <!-- PLF - http://www.monjavascript.net/ -->
              </p>
              <center>
                <p>
                  <script language="JavaScript">
<!--
var monmail="<form action='mailto:";
monmail +="	formmailto";
monmail +="@jejava";
monmail +="script.net";
monmail +="?subject=Fomulaire Mon javascript' name='envoi' method=POST enctype='text/plain' onSubmit='return valider();'>";
document.write(monmail);
//-->
                </script>
                  <!-- <form> -->
                <font size="+1"><b>Le courriel ne me sera pas envoyer,<br>
                </b></font>(mais un robot vous le retournera). Trop de zzzzzzzz
                et de aaaaaaaa)</p>
                <table border="0">
                  <tr> 
                    <td><b><font face="Courier New, Courier, mono">Nom &nbsp;&nbsp;&nbsp;:</font></b><font face="Courier New, Courier, mono"> 
                      <input name="nom"size=50 maxlength=50>
                      <br>
                      <b>Prenom : </b> </font> 
                      <input name="PRENOM"size=50 maxlength=50>
                      <br>
                      <textarea name="message" cols="60" rows="5"></textarea>
                    </td>
                  </tr>
                </table>
                <br>
                Est-ce votre 1�re visite sur Mon javascript 
                <input type="radio" name="visite" value="oui">
                Oui - &nbsp; 
                <input type="radio" name="visite" value="2-3eme">
                Non 2 � 3�me - &nbsp; 
                <input type="radio" name="visite" value="4+">
                Non 4 � +<br>
                <br>
                Votre avis sur le site 
                <input type="radio" name="avis" value="tres bien">
                Tr&egrave;s Bien - &nbsp; 
                <input type="radio" name="avis" value="bien">
                Bien - &nbsp; 
                <input type="radio" name="avis" value="moyen">
                Moyen - &nbsp; 
                <input type="radio" name="avis" value="Pas bien">
                Pas bien<br>
                <input type="submit" value="Envoyer" name="Envoyer">
                <input type="reset" name="Submit" value="Effacer">
                <form>
                </form>
                <!-- <form></form> Dreameaver-->
                <hr>
              </center>
              <div align="center"> 
                <p><font size="+1" color="#000099">Si vous souhaitez avoir un 
                  formulaire d'envoi de mail.<br>
                  </font><font size="+1" color="#000099">Ins&eacute;rez le code 
                  ci-dessous dans votre page Web et corrigez le comme suit</font><br>
                  <br>
                </p>
              </div>
              <table width="680" border="1" bordercolorlight="#000000" bgcolor="#CCCCCC" align="center">
                <tr> 
                  <td> 
                    <p><font size="-1">&lt;!-- PLF - http://www.monjavascript.net/ 
                      --&gt;<br>
                      </font>&lt;center&gt;<br>
                      &lt;form action=&quot;mailto:marc@monjavascript.com?subject=Fomulaire 
                      Mon javascript&quot; name=&quot;envoi&quot; method=POST enctype=&quot;text/plain&quot;&gt;<br>
                      &lt;table border=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;<br>
                      &lt;b&gt;Nom : &lt;/b&gt;&lt;input name=&quot;nom&quot;size=50 
                      maxlength=50&gt;&lt;br&gt;<br>
                      &lt;b&gt;Prenom : &lt;/b&gt;&lt;input name=&quot;PRENOM&quot;size=50 
                      maxlength=50&gt;&lt;br&gt;<br>
                      &lt;textarea name=&quot;message&quot; cols=&quot;60&quot; 
                      rows=&quot;5&quot;&gt;&lt;/textarea&gt;<br>
                      &lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;br&gt;<br>
                      Est-ce votre 1&egrave;re visite sur Mon javascript <br>
                      &lt;input type=&quot;radio&quot; name=&quot;visite&quot; 
                      value=&quot;oui&quot;&gt;<br>
                      Oui - &amp;nbsp; <br>
                      &lt;input type=&quot;radio&quot; name=&quot;visite&quot; 
                      value=&quot;2-3eme&quot;&gt;<br>
                      Non 2 &agrave; 3&eacute;me - &amp;nbsp; <br>
                      &lt;input type=&quot;radio&quot; name=&quot;visite&quot; 
                      value=&quot;4+&quot;&gt;<br>
                      Non 4 &agrave; +&lt;br&gt;&lt;br&gt;<br>
                      Votre avis sur le site <br>
                      &lt;input type=&quot;radio&quot; name=&quot;avis&quot; value=&quot;tres 
                      bien&quot;&gt;<br>
                      Tr&amp;egrave;s Bien - &amp;nbsp; <br>
                      &lt;input type=&quot;radio&quot; name=&quot;avis&quot; value=&quot;bien&quot;&gt;<br>
                      Bien - &amp;nbsp; <br>
                      &lt;input type=&quot;radio&quot; name=&quot;avis&quot; value=&quot;moyen&quot;&gt;<br>
                      Moyen - &amp;nbsp; <br>
                      &lt;input type=&quot;radio&quot; name=&quot;avis&quot; value=&quot;Pas 
                      bien&quot;&gt;<br>
                      Pas bien&lt;br&gt;<br>
                      &lt;input type=&quot;submit&quot; value=&quot;Envoyer&quot; 
                      name=&quot;Envoyer&quot;&gt;<br>
                      &lt;input type=&quot;reset&quot; name=&quot;Submit&quot; 
                      value=&quot;Effacer&quot;&gt;<br>
                      &lt;/form&gt;<br>
                      &lt;hr&gt;<br>
                      &lt;/center&gt;</p>
                  </td>
                </tr>
              </table>
              <div align="center"><br><!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
<br>
              </div>
              <table width="680" border="0" align="center">
                <tr> 
                  <td bgcolor="#CCCCCC" width="57%"><font size="-1">&lt;FORM action=&quot;mailto:<font color="#FF0000">mon-mail@heberg.com</font>?subject=<font color="#FF00FF">Objet 
                    Message</font>&quot; name=&quot;envoi&quot; method=POST enctype=&quot;text/plain&quot;&gt;</font></td>
                  <td width="43%"><font color="#FF0000">Votre adresse e-mail</font><br>
                    <font color="#FF00FF">Appara&icirc;tra dans le champ &quot;Objet&quot; 
                    du mail</font></td>
                </tr>
                <tr> 
                  <td width="57%" height="5">&nbsp;</td>
                  <td width="43%">&nbsp;</td>
                </tr>
                <tr> 
                  <td bgcolor="#CCCCCC" width="57%">&lt;b&gt;<font color="#FF0000">Nom 
                    : </font>&lt;/b&gt;&lt;input name=&quot;<font color="#FF00FF">nom</font>&quot;<font color="#0000FF">size=50 
                    maxlength=50</font>&gt;&lt;br&gt;<br>
                    &lt;b&gt;<font color="#FF0000">Prenom : </font>&lt;/b&gt;&lt;input 
                    name=&quot;<font color="#FF00FF">prenom</font>&quot;<font color="#0000FF">size=50 
                    maxlength=50</font>&gt;</td>
                  <td width="43%"> 
                    <div align="left"><font color="#FF0000">Texte devant le champ</font><br>
                      <font color="#FF00FF">nom du champ</font><br>
                      <font color="#0000FF">taille du champ et nombre de caract&egrave;rtes 
                      autoris&eacute;</font></div>
                  </td>
                </tr>
                <tr> 
                  <td height="5" width="57%">&nbsp;</td>
                  <td width="43%">&nbsp;</td>
                </tr>
                <tr> 
                  <td bgcolor="#CCCCCC" width="57%"><font size="-1">&lt;TEXTAREA 
                    name=&quot;message&quot; <font color="#FF0000">cols=&quot;60&quot;</font> 
                    <font color="#FF00FF">rows=&quot;4&quot;</font>&gt;&lt;/TEXTAREA&gt;</font></td>
                  <td width="43%"> 
                    <div align="left"><font color="#FF0000">Nombre de caract&egrave;res 
                      par ligne</font><br>
                      <font color="#FF00FF">Nombre de lignes</font></div>
                  </td>
                </tr>
                <tr> 
                  <td height="5" width="57%">&nbsp;</td>
                  <td width="43%">&nbsp;</td>
                </tr>
                <tr> 
                  <td bgcolor="#CCCCCC" width="57%"><font size="-1" color="#006600">Est-ce 
                    votre 1&egrave;re visite sur Mon javascript</font><font size="-1"> 
                    <br>
                    &lt;INPUT type=&quot;radio&quot; name=&quot;<font color="#FF0000">visite</font>&quot; 
                    value=&quot;<font color="#FF00FF">oui</font>&quot;&gt;<br>
                    <font color="#0033CC">Oui </font>- &amp;nbsp; <br>
                    &lt;INPUT type=&quot;radio&quot; name=&quot;<font color="#FF0000">visite</font>&quot; 
                    value=&quot;<font color="#FF00FF">2-3eme</font>&quot;&gt;<br>
                    <font color="#0033CC">Non 2 &agrave; 3&eacute;me</font> - 
                    &amp;nbsp; <br>
                    &lt;INPUT type=&quot;radio&quot; name=&quot;<font color="#FF0000">visite</font>&quot; 
                    value=&quot;<font color="#FF00FF">4+</font>&quot;&gt;<br>
                    <font color="#0033CC">Non 4 &agrave; +</font></font></td>
                  <td width="43%"> 
                    <div align="left"><b> <font color="#006600">Question</font> 
                      &agrave; choix multiples</b><br>
                      <font color="#FF0000">Th&egrave;me de la question qui appara&icirc;tra 
                      dans le mail<br>
                      <font color="#FF00FF">R&eacute;ponse qui appara&icirc;tra 
                      dans le mail selon le choix<br>
                      <font color="#0033CC">R&eacute;ponses propos&eacute;es au 
                      visiteurs</font></font></font></div>
                  </td>
                </tr>
                <tr> 
                  <td height="5" width="57%">&nbsp;</td>
                  <td width="43%">&nbsp;</td>
                </tr>
                <tr> 
                  <td bgcolor="#CCCCCC" width="57%"> 
                    <div align="left">nom= Dupont<br>
                      prenom= Jean<br>
                      message=Je trouve ton site tr&egrave;s int&eacute;ressant<br>
                      visite=2-3eme<br>
                      avis=tres bien</div>
                  </td>
                  <td width="43%"><b>Exemple de message re&ccedil;u (ou &agrave; 
                    m'envoyer)</b></td>
                </tr>
              </table>
              <p>&nbsp; 
                
              </p>
              <p align="center"><font color="#0000FF"><a href="fairelien.php">Ce site vous a plu ?
                  Vous avez trouv&eacute; le script que vous cherchiez ?<br>
                  Faites en profiter vos visiteurs : ins&eacute;rez un lien sur
                  votre site</a><br>
                <!--Code � ins�rer jjspub --><iframe src="http://www.i-services.net/annonceurs/iframes/i-services.php?refid=8081" width="468" height="60" marginwidth="0" marginheight="0" hspace="0" vspace="0" frameborder="0" scrolling="no">&nbsp;</iframe><!--Code � ins�rer jjspub --> 
                </font></p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
