<html>
<head>
<title>Mon JavaScript - l'objet Math</title>
<meta name="description" content="Mon JavaScript vous propose : des javascript, generateurs, multimoteur, et autres astuces..., pour ->r de l'attrait � votre site perso">
<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF- http://www.monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
</head>
<body bgcolor="#FFFFFF">
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
		
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/cours_jjs/index.php" >Cours de javascript</a><br>
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="center">
              <p><font face="Verdana, Arial" size="3"><strong>L'objet Math</strong></font></p>
              <p align="left"> <font face="Verdana, Arial" size="1">L'objet Math est
                    un objet pr&eacute;d&eacute;fini, il permet  de manipuler
                    les nombres et  contient des fonctions math&eacute;matiques
                  courantes</font></p>
              <p>              
              <font><b>
			  <div align="left"><ul>
			  Les fonctions de bases et arrondis de l'objet Math
			  </ul></div>
			  </b></font>
              <p>
              <table width="680" border="1" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
                <tbody>
                  <tr>
                    <td width="100"><b>M�thode</b></td>
                    <td width="200"><b>description</b></td>
                    <td><b>Exemple</b></td>
                  </tr>
                  <tr>
                    <td width="100"><b>abs(</b>Valeur<b>)</b></td>
                    <td width="200">Retourne la valeur absolue d'un nombre.</td>
                    <td> x = Math.abs(3.2) -> x = 3.2<br>
                    x = Math.abs(-3.2) -> x = 3.2</td>
                  </tr>
                  <tr>
                    <td width="100"><b>ceil(</b>Valeur<b>)</b></td>
                    <td width="200">Retourne l'entier sup�rieur le plus proche.</td>
                    <td>
                        x = Math.ceil(3.2) -> x = 4</td>
                  </tr>
                  <tr>
                    <td width="100"><b>floor(</b>Valeur<b>)</b></td>
                    <td width="200">Retourne l'entier inf�rieur le plus proche.</td>
                    <td>
                        x = Math.floor(3.2) -> x = 3
                    </td>
                  </tr>
                  <tr>
                    <td width="100"><b>round(</b>Valeur<b>)</b></td>
                    <td width="200">Arrondit � l'entier le plus proche.</td>
                    <td>
                        x = Math.round(3.2) -> x = 3
                          <br>
                      x = Math.round(3.72) -> x = 4
                          <br>
                      x = Math.round(3.52) -> x = 4
                      
                    </td>
                  </tr>
                  <tr>
                    <td width="100">&nbsp;</td>
                    <td width="200">Pour arrondir &agrave; 1 ou plusieurs d&eacute;cimales
                      pr&egrave;s</td>
                    <td>x = Math.round(3.52678*10)/10 x = 3.5<br>
x = Math.round(3.52678*100)/100 x =3.53</td>
                  </tr>
                  <tr>
                    <td width="100"><b>pow(</b>Valeur1, Valeur2<b>)</b></td>
                    <td width="200">Retourne le nombre <i>Valeur1</i> � la puissance <i>Valeur2</i></td>
                    <td>
                        x = Math.pow(8,3) -> x = 512<br>
                    x = Math.pow(16,0.5)  -> x =4<font size="1"> (racine carr�e)</font></td>
                  </tr>
                  <tr>
                    <td width="100"><b>random()</b></td>
                    <td width="200">Retourne un nombre al�atoire compris entre 0 et 1</td>
                    <td>
                        x = Math.random() -> x = 0.8162365933063834 ou 0.5465412569919159
                          ou ...</td>
                  </tr>
                  <tr>
                    <td width="100"><b>sqrt(</b>Valeur<b>)</b></td>
                    <td width="200">Retourne la racine carr�e de la valeur.</td>
                    <td>
                        x = Math.sqrt(16) -> x = 4</td>
                  </tr>
                </tbody>
              </table><!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
<br>
			  <div align="left">
			    <ul>
			      <b>Statistique</b></ul>
		      </div>
			  <p>
              <table width="680" border="1" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
                <tbody>
                  <tr>
                    <td width="100"><b>M�thode</b></td>
                    <td width="200"><b>description</b></td>
                    <td><b>Exemple</b></td>
                  </tr>
                  <tr>
                    <td width="100"><b>max(</b>Valeur1, Valeur2<b>)</b></td>
                    <td width="200">Retourne le plus grand des deux entiers.</td>
                    <td> x = Math.max(3.2,3.25) -> x = 3.25 </td>
                  </tr>
                  <tr>
                    <td width="100"><b>min(</b>Valeur1, Valeur2<b>)</b></td>
                    <td width="200">Retourne le plus petit des deux entiers.</td>
                    <td> x = Math.min(3.2,3.25) -> x = 3.2</td>
                  </tr>
                </tbody>
              </table>
              <div align="left">
                <ul>
                  
                  <p><b><font><b>Logarithmes et exponentielle</b></font></b></p>
                </ul>
              </div>
              <p></p>
              <table width="680" border="1" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
                <tbody>
                  <tr>
                    <td width="100"><b>M�thode</b></td>
                    <td width="200"><b>description</b></td>
                    <td><b>Exemple</b></td>
                  </tr>
                  <tr>
                    <td width="100"><b>E</b></td>
                    <td width="200">Retourne le nombre d'Euler  </td>
                    <td>Math.E = 2.718 (et quelque chose)</td>
                  </tr>
                  <tr>
                    <td width="100"><b>LN2</b></td>
                    <td width="200">Retourne le logarithme naturel de 2 </td>
                    <td>Math.LN2 = 0.693 (et quelque chose)</td>
                  </tr>
                  <tr>
                    <td width="100"><b>LN10</b></td>
                    <td width="200">Retourne le logarithme naturel de 10 </td>
                    <td> Math.LN10 = 2.302 (et quelque chose)</td>
                  </tr>
                  <tr>
                    <td width="100"><b>LOG2E</b></td>
                    <td width="200">Retourne le logarithme de base 2 de E </td>
                    <td>Math.LOG2E = 1.442 (et quelque chose)</td>
                  </tr>
                  <tr>
                    <td width="100"><b>LOG10E</b></td>
                    <td width="200">Retourne le logarithme de base
                    10 de E </td>
                    <td>Math.LOG10E = 0.434 (et quelque chose)</td>
                  </tr>
                  <tr>
                    <td width="100"><b>SQRT1_2</b></td>
                    <td width="200">Retourne la racine carr&eacute;e de 1/2 </td>
                    <td>Math.SQRT1_2 = 0.707 (et quelque chose)</td>
                  </tr>
                  <tr>
                    <td width="100"><b>SQRT2</b></td>
                    <td width="200">Racine de 2 </td>
                    <td>Math.SQRT2 = 1.414 (et quelque chose)</td>
                  </tr>
                  <tr>
                    <td width="100"><b>exp(valeur)</b></td>
                    <td width="200">Retourne l'exponentielle de la valeur entr�e en param�tre </td>
                    <td> x = Math.exp(1) -> x = 2.718 (et quelque chose)</td>
                  </tr>
                  <tr>
                    <td width="100"><b>log(valeur)</b></td>
                    <td width="200">Retourne le logarithme de la valeur entr�e en param�tre </td>
                    <td>x = Math.exp(2) -> x = 0.693 (et quelque chose)</td>
                  </tr>
                </tbody>
              </table>
              <div align="left">
                <ul>
                  <b> <font><b>Trigonom�trie</b></font></b>
                </ul>
              </div>
              <p>
              <table width="680" border="1" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
                <tbody>
                  <tr>
                    <td width="100"><b>M�thode</b></td>
                    <td width="200"><b>description</b></td>
                    <td><b>Exemple</b></td>
                  </tr>
                  <tr>
                    <td width="100"><b>PI</b></td>
                    <td width="200">Retourne la valeur du nombre PI </td>
                    <td>Math.PI = 3.14159265358979 (et quelque chose)</td>
                  </tr>
                  <tr>
                    <td width="100"><b>sin(</b>valeur<b>)</b></td>
                    <td width="200">Retourne le sinus de la valeur  (valeur doit �tre en radians)</td>
                    <td>sans exemple</td>
                  </tr>
                  <tr>
                    <td width="100"><b>asin(</b>valeur<b>)</b></td>
                    <td width="200">Retourne l'arcsinus de la valeur  (valeur doit �tre en radians)</td>
                    <td>sans exemple</td>
                  </tr>
                  <tr>
                    <td width="100"><b>cos(</b>valeur<b>)</b></td>
                    <td width="200">Retourne le cosinus de la valeur  (valeur doit �tre en radians)</td>
                    <td>sans exemple</td>
                  </tr>
                  <tr>
                    <td width="100"><b>acos(</b>valeur<b>)</b></td>
                    <td width="200">Retourne l'arccosinus de la valeur  (valeur doit �tre en radians)</td>
                    <td>sans exemple</td>
                  </tr>
                  <tr>
                    <td width="100"><b>tan(</b>valeur<b>)</b></td>
                    <td width="200">Retourne la tangente de la valeur  (valeur doit �tre en radians)</td>
                    <td>sans exemple</td>
                  </tr>
                  <tr>
                    <td width="100"><b>atan(</b>valeur<b>)</b></td>
                    <td width="200">Retourne l'arctangente de la valeur  (valeur doit �tre en radians)</td>
                    <td>sans exemple</td>
              </table>
              <p align="center"><a href="fairelien.php">Ce site vous a plu ?
                  Vous avez trouv&eacute; le script que vous cherchiez ?<br>
                  Faites en profiter vos visiteurs : ins&eacute;rez un lien sur
                  votre site</a></p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
