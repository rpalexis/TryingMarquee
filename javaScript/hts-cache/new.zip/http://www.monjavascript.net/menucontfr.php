<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<title>Document sans titre</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<frameset rows="*" cols="50%,*" framespacing="0" frameborder="NO" border="0">
  <frame src="menucont1.php" name="gauche" frameborder="no" scrolling="NO" id="gauche">
  <frame src="menucont2.php" name="droite" frameborder="no" scrolling="NO" id="droite">
</frameset>
<noframes><body>

</body></noframes>
</html>
