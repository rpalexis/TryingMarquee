<!--Code � ins�rer PUP : CPM -pubjjs -->
<!-- fin du Code � ins�rer PUP : CPM -pubjjs -->
<html>
<head>
<title>Mon JavaScript -  Menu en forme de roue</title>
<meta name="Description" lang="fr" content="Webmasters, Mon JavaScript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">

<meta name="author" content="PLF - http://www.monjavascript.net/">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
<script language = "JavaScript">
<!--
//PLF-http://www.monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;	
window.moveTo(0,0)
window.resizeTo(screen.width,(screen.height-25))
	if ((screen.width <= 800) && (screen.height <= 600)) {
	document.write("<style>.lienmenu  { font-family: arial; font-size: 14px; position: absolute; width: 200px;visibility:hidden; z-index: 2;}</style>");
	}
	else {
	document.write("<style>.lienmenu  { font-family: arial; font-size: 18px; position: absolute; width: 200px;visibility:hidden; z-index: 2;}</style>");
	}
	
	
	window.setTimeout("sens()", 20000);
	window.setTimeout("sens2()",40000);
	function sens(){
	deg_rot =Math.PI / -180;
	window.setTimeout("sens()", 40000);
	}
	function sens2(){
	deg_rot =Math.PI / 180;
	window.setTimeout("sens2()", 40000);
	}

    

    function menu_roue() {
            for (var i = 0; i < dep.length; i++) {
                dep[i] += deg_rot; objlien[i].visibility = 'visible';
                objlien[i].left = (rayon * Math.cos(dep[i])) + cent_larg
                objlien[i].top = (rayon * Math.sin(dep[i])) + cent_long;
            }
        vit_roue = setTimeout("menu_roue()", 100);
	    }
	
     function creer_objlien() {
        objlien = new Array(lienmenu1, lienmenu2, lienmenu3, lienmenu4, lienmenu5, lienmenu6, lienmenu7, lienmenu8, lienmenu9, lienmenu10, lienmenu11, lienmenu12);
        dep = new Array();
        dep[0] = 0;
            for (var i = 1; i < objlien.length; i++) {
                dep[i] = parseFloat(dep[i - 1] + ((2 *Math.PI) / objlien.length));
            }
        menu_roue();
    }
     function mouss_stop() {
	 deg_old=deg_rot;
	 deg_rot=0
	 }
     function mouss_start() {
	 deg_rot=deg_old;
	 }
	 
    var deg_rot =Math.PI / 180; //  Math.PI / -180 rotation invers�e
    var rayon = ((screen.height)/4);
    var cent_larg = ((screen.width)/2)-60;
    var cent_long = ((screen.height)/2)-rayon/2;
	var objlien;
    var dep;
	//-->
</script>

</head>

<body>
<table width="100%" border="0" height="100%">
  <tr> 
    <td valign="top" height="80" bgcolor="#9966FF"> 
      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="im/230x60.gif" width="230" height="60" alt="http://www.monjavascript.net" align="middle" border="0"></a></font><font size="+3"><b> 
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>        <!--//-->
        <font size="+3"><b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font><font color="#0000FF" size="5"></font><font size="+3"><b><a href="http://www.monjavascript.net"><font face="Verdana, Arial, Helvetica, sans-serif" size="3">Retour 
        Accueil &nbsp;Mon javascript</font></a> </b></font></div>
    </td>
  </tr>
  <tr> 
    <td valign="middle" bgcolor="#CC99FF"> 
      <div align="center"> 
        <p> <font color="#000066" size="5">Menu en forme de Roue<br>
          <!--Code � ins�rer jjspub --><iframe src="http://www.i-services.net/annonceurs/iframes/i-services.php?refid=8081" width="468" height="60" marginwidth="0" marginheight="0" hspace="0" vspace="0" frameborder="0" scrolling="no">&nbsp;</iframe><!--Code � ins�rer jjspub --> 
          </font></p>
        <p><a href = "menuroue2.php" >Afficher le code et les explications</a> 
        </p>
      </div>
    </td>
  </tr>
  <tr> 
    <td valign="bottom" height="60" bgcolor="#9966FF">      
        <!--- Code � ins�rer allopass --->	  <div align="right"><br>
		<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
</div>
		<!--- fin du Code � ins�rer allopass --->
		Il y a 3 Visiteurs sur Mon JavaScript        <br>
      </div>
    </td>
  </tr>
</table>
<div id = "lienmenu1" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href = "http://www.lacuisinedemacopine.net" target="_blank" >La cuisine de ma Copine</a></div>
<div id = "lienmenu2" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href = "java/rouemenu.zip" >Fichier.ZIP</a></div>
<div id = "lienmenu3" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href = "menuroue2.php" >Afficher 
  LE CODE</a></div>
<div id = "lienmenu4" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href = "javascript:history.go(-1)" >Page pr&eacute;c&eacute;dente</a></div>
<div id = "lienmenu5" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href = "menuroue2.php" >Afficher 
  LE CODE</a></div>
<div id = "lienmenu6" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href="http://www.monjavascript.net/" >Accueil</a></div>
<div id = "lienmenu7" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href = "http://www.lacuisinedemacopine.net" target="_blank" >La cuisine de ma Copine</a></div>
<div id = "lienmenu8" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href = "java/rouemenu.zip" >Fichier.ZIP</a></div>
<div id = "lienmenu9" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href = "menuroue2.php" >Afficher 
  LE CODE</a></div>
<div id = "lienmenu10" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"><a href = "java/rouemenu.zip" >Fichier.ZIP</a></div>
<div id = "lienmenu11" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href = "javascript:history.go(-1)" >Page pr&eacute;c&eacute;dente</a></div>
<div id = "lienmenu12" onMouseOver="mouss_stop()" onMouseOut="mouss_start()" class = "lienmenu"> <a href="http://www.monjavascript.net/" >Accueil</a></div>
	  	 
        <script language = "JavaScript">
<!--
//PLF-http://www.monjavascript.net/
var lienmenu1 = eval(document.getElementById("lienmenu1").style); 
var lienmenu2 = eval(document.getElementById("lienmenu2").style); 
var lienmenu3 = eval(document.getElementById("lienmenu3").style); 
var lienmenu4 = eval(document.getElementById("lienmenu4").style); 
var lienmenu5 = eval(document.getElementById("lienmenu5").style); 
var lienmenu6 = eval(document.getElementById("lienmenu6").style); 
var lienmenu7 = eval(document.getElementById("lienmenu7").style); 
var lienmenu8 = eval(document.getElementById("lienmenu8").style); 
var lienmenu9 = eval(document.getElementById("lienmenu9").style); 
var lienmenu10 = eval(document.getElementById("lienmenu10").style); 
var lienmenu11 = eval(document.getElementById("lienmenu11").style); 
var lienmenu12 = eval(document.getElementById("lienmenu12").style); 
	
	creer_objlien();
//-->
</script>
 
</body>
</html>
