<html>
<head>
<title>Mon JavaScript - Generateur META-TAGS</title>
<meta name="Description" lang="fr" content="Webmasters, Mon JavaScript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
</head>
<body bgcolor="#FFFFFF" >
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
		
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/cours_jjs/index.php" >Cours de javascript</a><br>
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="center"> 
              <p align="center"><font size="3">Mon javascript vous propose <b><font size="5">un 
                G&eacute;n&eacute;rateur de balises Meta</font></b>, afin d'optimiser 
                votre r&eacute;f&eacute;rencement.</font></p>
              <p align="center"><font size="3">Ces balises renseignent les moteurs 
                de recherche sur le contenu de votre site, afin qu'ils puissent 
                l'ajouter dans leur base de donn&eacute;es.</font></p>
              <p align="center"><font size="3"><b>Ce g&eacute;n&eacute;rateur 
                sur votre site</b> : T&eacute;l&eacute;charger le <a href="java/genmetatag.zip">fichier 
                zip</a> </font></p>
              <p align="center"><font size="3">et ajouter le fichier metatagjjs.htm 
                sur votre site</font></p>
              <p align="center"><font size="2"><a href="metadescp.php" target="_blank">Description 
                des Balises META</a></font></p>
              <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                <script>
<!--
document.write(unescape("%3Cscript%20language%3DJavaScript%3E%0D%0A%20%20//%20PLF%20-%20http%3A//www.monjavascript.net/%0D%0A%20%20var%20toto%20%3D%20%27href%3D%22htt%27%0D%0A%20%20toto%20+%3D%20%27p%3A//www.je%27+%0D%0A%20%20%27javascri%27+%27pt.net/%22%20tar%27%0D%0Adocument.write%28%27%3Cfont%20face%3D%22Verdana%2C%20Arial%2C%20Helvetica%2C%20sans-serif%22%20size%3D%222%22%3E%3Cstrong%3E%3Cem%3ERetour%20%27+%20%20%0D%0A%20%20%27%E0%20l%5C%27accueil%20%3Ca%20%27+toto+%27get%3D%22_blank%22%3EJe%20%27+%20%0D%0A%20%20%27JavaScript%3C/a%3E%3C/em%3E%3C/strong%3E%3C/font%27%29%3B%0D%0Afunction%20fonct_meta%28form%29%20%7B%0D%0Aform.result.value%3D%27%3C%21--%20http%3A//www.monjavascript.net/%20//--%3E%5Cn%27%3B%0D%0A%20%20%20%20if%20%28form.input15.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20http-equiv%3D%5C%22Content-Language%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input15.value%20+%20%22%5C%22%3E%5Cn%22%3B%09%20%20%0D%0A%20%20%20%20%7D%0D%0A%09%0D%0A%09if%20%28form.input17.checked%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20http-equiv%3D%5C%22Content-Script-Type%5C%22%20content%3D%5C%22text/javascript%5C%22%3E%5Cn%22%3B%20%20%20%20%20%20%20%20%0D%0A%09%7D%0D%0A%09if%20%28form.input1.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Title%5C%22%20lang%3D%5C%22%22%20+form.input15.value%20+%22%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input1.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input2.value%20%21%3D%20%22http%3A//%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Identifier-url%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input2.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input3.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Description%5C%22%20lang%3D%5C%22%22%20+form.input15.value%20+%22%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input3.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input3.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Abstract%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input3.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input4.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22keywords%5C%22%20lang%3D%5C%22%22%20+form.input15.value%20+%22%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input4.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input7.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Category%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input7.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input8.value%20%21%3D%20%22yyyymmdd%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Date-Creation-yyyymmdd%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input8.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input9.value%20%21%3D%20%22yyyymmdd%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Date-Revision-yyyymmdd%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input9.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input10.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Author%5C%22%20lang%3D%5C%22%22%20+form.input15.value%20+%22%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input10.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input11.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Reply-to%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input11.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input12.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Publisher%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input12.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%0D%0A%20%20%20%20if%20%28form.input13.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Copyright%5C%22%20content%3D%5C%22%A9Copyright%20%3A%20%22%20+%0D%0A%20%20%20%20%20%20form.input13.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input14.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Location%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input14.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input16.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Generator%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input16.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input18.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Distribution%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input18.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input19.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Rating%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input19.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input20.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Robots%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input20.options%5Bform.input20.selectedIndex%5D.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input21.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20name%3D%5C%22Revisit-After%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input21.options%5Bform.input21.selectedIndex%5D.value%20+%20%22%20days%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input22.checked%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20http-equiv%3D%5C%22Cache-Control%5C%22%20content%3D%5C%22no-cache%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input22.checked%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20http-equiv%3D%5C%22Pragma%5C%22%20content%3D%5C%22no-cache%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%20%20%20%20if%20%28form.input23.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Cmeta%20http-equiv%3D%5C%22Refresh%5C%22%20content%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input23.options%5Bform.input23.selectedIndex%5D.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input1.value%20%21%3D%20%22%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Ctitle%3E%22%20+%0D%0A%20%20%20%20%20%20form.input1.value%20+%20%22%3C/title%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09if%20%28form.input5.value%20%21%3D%20%22http%3A//%22%29%20%7B%0D%0A%20%20%20%20%20%20form.result.value%20+%3D%22%3Clink%20rel%20name%3D%5C%22Shortcut%20Icon%5C%22%20href%3D%5C%22%22%20+%0D%0A%20%20%20%20%20%20form.input5.value%20+%20%22%5C%22%3E%5Cn%22%3B%0D%0A%20%20%20%20%7D%0D%0A%09%0D%0Aform.result.value%20+%3D%22%3C%21--%20http%3A//www.monjavascript.net/%20//--%3E%22%3B%0D%0A%7D%0D%0A%0D%0A%3C/script%3E"));
//-->
</script>
                </font></p>
              <form>
                <table bordercolor=#f3f3f3 cellspacing=1 cellpadding=2 width=560 align=center 
border=0>
                  <tbody> 
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Titre 
                      de votre site :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input1 maxlength="100">
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">URL 
                      de votre site :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input2 value="http://">
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Description 
                      :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input type="text" size="40" name="input3" maxlength="200">
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Mots 
                      cl�s s�par�s par des virgules :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input4 maxlength="1000">
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Ic�ne 
                      Internet Explorer :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input5 value="http://">
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Cat�gorie, 
                      Sujet du site :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input name=input7 size="40">
                      </font></td>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Date 
                      de cr�ation de votre site yyyymmdd :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=10 name=input8 maxlength="8" value="yyyymmdd">
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Date 
                      de la derni�re mise � jour yyyymmdd :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=10 name=input9 maxlength="8" value="yyyymmdd">
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Auteur 
                      du site :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input10>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Adresse 
                      e-mail :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input11>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Editeur 
                      du site (Designer) :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input12>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Infos 
                      de Copyright :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input13>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Votre 
                      lieu de r�sidence :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input14>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Langue 
                      du site :</font></td>
                    <td class=contenu> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <select name=input15>
                        <option value="af">Africain</option>
                        <option value="sq">Albanais</option>
                        <option value="ar-dz">Alg�rien</option>
                        <option value="de">Allemand</option>
                        <option value="de-at">Allemand (Austrian)</option>
                        <option value="de-li">Allemand (Liechtenstein)</option>
                        <option value="de-lu">Allemand (Luxembourg)</option>
                        <option value="de-ch">Allemand (Suisse)</option>
                        <option value="en-us">Am�ricain</option>
                        <option value="en">Anglais</option>
                        <option value="en-za">Anglais (Afrique du sud)</option>
                        <option value="en-bz">Anglais (B�lize)</option>
                        <option value="en-gb">Anglais (Grande Bretagne)</option>
                        <option value="ar">Arabe</option>
                        <option value="ar-sa">Arabe (Arabie Saoudite)</option>
                        <option value="ar-bh">Arabe (Bahre�n)</option>
                        <option value="ar-ae">Arabe (Emirat arabe uni)</option>
                        <option value="en-au">Australien</option>
                        <option value="eu">Basque</option>
                        <option value="be">Bi�lorussie</option>
                        <option value="bg">Bulgarre</option>
                        <option value="en-ca">Canadien</option>
                        <option value="ca">Catalan</option>
                        <option value="zh">Chinois</option>
                        <option value="zh-hk">Chinois (Hong-Kong)</option>
                        <option value="zh-cn">Chinois (PRC)</option>
                        <option value="zh-sg">Chinois (Singapourg)</option>
                        <option value="zh-tw">Chinois (Ta�wan)</option>
                        <option value="ko">Cor�ein</option>
                        <option value="cs">Cr�te</option>
                        <option value="hr">Croate</option>
                        <option value="da">Danois</option>
                        <option value="ar-eg">Egyptien</option>
                        <option value="es">Espagnol</option>
                        <option value="es-ar">Espagnol (Argentine)</option>
                        <option value="es-bo">Espagnol (Bolivie)</option>
                        <option value="es-cl">Espagnol (Chilie)</option>
                        <option value="es-co">Espagnol (Colombie)</option>
                        <option value="es-cr">Espagnol (Costa Rica)</option>
                        <option value="es-sv">Espagnol (El Salvador)</option>
                        <option value="es-ec">Espagnol (Equateur)</option>
                        <option value="es-gt">Espagnol (Guatemala)</option>
                        <option value="es-hn">Espagnol (Honduras)</option>
                        <option value="es-mx">Espagnol (Mexique)</option>
                        <option value="es-ni">Espagnol (Nicaragua)</option>
                        <option value="es-pa">Espagnol (Panama)</option>
                        <option value="es-py">Espagnol (Paraguay)</option>
                        <option value="es-pe">Espagnol (P�rou)</option>
                        <option value="es-pr">Espagnol (Puerto Rico)</option>
                        <option value="en-tt">Espagnol (Trinidad)</option>
                        <option value="es-uy">Espagnol (Uruguay)</option>
                        <option value="es-ve">Espagnol (Venezuela)</option>
                        <option value="et">Estonien</option>
                        <option value="fo">Faeroese</option>
                        <option value="fi">Finlandais</option>
                        <option value="fr" selected>Fran�ais</option>
                        <option value="fr-be">Fran�ais (Belgique)</option>
                        <option value="fr-ca">Fran�ais (Canada)</option>
                        <option value="fr-lu">Fran�ais (Luxembourg)</option>
                        <option value="fr-ch">Fran�ais (Suisse)</option>
                        <option value="gd">Galicien</option>
                        <option value="el">Grec</option>
                        <option value="he">H�breux</option>
                        <option value="nl">Hollandais</option>
                        <option value="hu">Hongrois</option>
                        <option value="in">Indon�sien</option>
                        <option value="hi">Indou</option>
                        <option value="fa">Iranien</option>
                        <option value="ar-iq">Iraquien</option>
                        <option value="en-ie">Irlandais</option>
                        <option value="is">Islandais</option>
                        <option value="it">Italien</option>
                        <option value="it-ch">Italien (Suisse)</option>
                        <option value="en-jm">Jamaicain</option>
                        <option value="ja">Japonais</option>
                        <option value="ar-jo">Jordanien</option>
                        <option value="ar-kw">Koweitien</option>
                        <option value="lv">Lettische</option>
                        <option value="ar-lb">Libanais</option>
                        <option value="lt">Littuanien</option>
                        <option value="ar-ly">Lybien</option>
                        <option value="mk">Mac�doine</option>
                        <option value="ms">Mal�sien</option>
                        <option value="mt">Maltais</option>
                        <option value="ar-ma">Marocain</option>
                        <option value="nl-be">N�erlandais (Belgique)</option>
                        <option value="en-nz">N�o-z�landais</option>
                        <option value="no">Norv�gien</option>
                        <option value="ar-om">Oman</option>
                        <option value="pl">Polonais</option>
                        <option value="pt">Portugais</option>
                        <option value="pt-br">Portugais (Br�sil)</option>
                        <option value="ar-qa">Quatar</option>
                        <option value="rm">Rhaeto-Romanic</option>
                        <option value="ro">Roumain</option>
                        <option value="ro-mo">Roumain (Moldavie)</option>
                        <option value="ru">Russe</option>
                        <option value="ru-mo">Russe (Moldavie)</option>
                        <option value="sr">Serbe</option>
                        <option value="sk">Slovaque</option>
                        <option value="sl">Slov�ne</option>
                        <option value="sb">Sorbian</option>
                        <option value="sv">Su�dois</option>
                        <option value="sv-fi">Su�dois (Finlande)</option>
                        <option value="ar-sy">Syrien</option>
                        <option value="th">Tha�landais</option>
                        <option value="ts">Tsonga (Afrique du sud)</option>
                        <option value="tn">Tswana (Afrique du sud)</option>
                        <option value="ar-tn">Tunisien</option>
                        <option value="tr">Turc</option>
                        <option value="uk">Ukrainien</option>
                        <option value="ur">Urdu</option>
                        <option value="vi">Vietnamien</option>
                        <option value="xh">Xhosa (Afrique)</option>
                        <option value="ar-ye">Y�men</option>
                        <option value="ji">Yiddish</option>
                        <option value="zu">Zulu (Afrique)</option>
                      </select>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Logiciel(s) 
                      utilis�(s) pour cr�er votre site :</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input size=40 name=input16>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Vous 
                      utilisez du Javascript dans vos pages ?</font></td>
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <input type=checkbox 
            name=input17>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Type 
                      d'acc�s � votre site :</font></td>
                    <td class=contenu> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <select name=input18>
                        <option value="Global">Acc�s depuis Internet</option>
                        <option value="Local">Acc�s local</option>
                        <option value="IU">Acc�s depuis un Intranet</option>
                      </select>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Public 
                      cible de votre site :</font></td>
                    <td class=contenu> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <select name=input19>
                        <option value="General">G�n�ral</option>
                        <option value="Mature">Pour adultes</option>
                        <option value="Restricted">Acc�s restreint</option>
                        <option value="14 years">14 ans et plus</option>
                      </select>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Indexation 
                      des pages :</font></td>
                    <td class=contenu> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <select name=input20>
                        <option value="index, follow">Indexe et suit les liens</option>
                        <option value="noindex, follow">N'indexe pas mais suit 
                        les liens</option>
                        <option value="index, nofollow">Indexe mais ne suit pas 
                        les liens</option>
                        <option value="none">N'indexe pas et ne suit pas les liens</option>
                      </select>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Revisiter 
                      le site tous les :</font></td>
                    <td class=contenu> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <select name=input21>
                        <option value=10>10 jours</option>
                        <option value=15 selected>15 jours</option>
                        <option value=20>20 jours</option>
                        <option value=25>25 jours</option>
                        <option value=30>30 jours</option>
                        <option value=35>35 jours</option>
                        <option value=40>40 jours</option>
                      </select>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Ne 
                      pas mettre le site dans <br>
                      le cache du visiteur ?</font></td>
                    <td class=contenu> 
                      <table cellspacing=0 cellpadding=2 border=0>
                        <tbody> 
                        <tr> 
                          <td> 
                            <p align=right><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                              <input type=checkbox 
            name=input22>
                              </font></p>
                          </td>
                          <center>
                            <td></td>
                          </center>
                        </tr>
                        </tbody> 
                      </table>
                    </td>
                  </tr>
                  <tr> 
                    <td class=contenu><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Auto-Refresh 
                      de la page ?</font></td>
                    <td class=contenu> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                      <select name=input23>
                        <option value="" selected>Non 
                        <option value=60>Toutes les 1 Minute 
                        <option 
        value=300>Toutes les 5 Minutes 
                        <option value=600>Toutes les 10 Minutes 
                        <option value=900>Toutes les 15 Minutes 
                        <option value=1200>Toutes les 20 Minutes</option>
                      </select>
                      </font></td>
                  </tr>
                  <tr> 
                    <td class=contenu> 
                      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                        <input onClick=fonct_meta(this.form) type=button value="G�n�rer les Meta Tags" name=button>
                        </font></div>
                    </td>
                    <td class=contenu> 
                      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                        <input type=reset value=R�tablir name=reset>
                        </font></div>
                    </td>
                  </tr>
                  </tbody> 
                </table>
                <div align="center"><!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
<font face="Verdana, Arial, Helvetica, sans-serif" size="2"><br>
                  </font> </div>
                <div align=center> 
                  <center>
                    <table width="680" border="0">
                      <tr> 
                        <td> 
                          <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                            <br>
                            <b>Recopiez le code suivant entre vos balises &lt;HEAD&gt; 
                            et &lt;/HEAD&gt;. <br>
                            </b> 
                            <textarea name=result rows=10 wrap=PHYSICAL cols=65></textarea>
                            <br>
                            <input onClick=form.result.focus();form.result.select() type=button value="S&eacute;lectionner le code" name=grab>
                            </font></div>
                        </td>
                      </tr>
                    </table>
                  </center>
                </div>
              </form>
              <p align="center"></p>
              <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="fairelien.php">Ce site vous a plu ?
                  Vous avez trouv&eacute; le script que vous cherchiez ?<br>
                  Faites en profiter vos visiteurs : ins&eacute;rez un lien sur
                  votre site</a></font> 
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
