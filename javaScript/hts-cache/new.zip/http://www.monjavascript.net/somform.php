<html>
<head>
<title>Mon JavaScript - Tous les Scripts Accueil des Visiteurs</title>
<meta name="Title" lang="fr" content="Mon JavaScript - programmation en javascript">
<meta name="Abstract" content="Mon JavaScript  pour donner plus d'attrait � votre site perso">
<meta name="Description" lang="fr" content="Mon JavaScript vous propose : des javascript, generateurs, multimoteur, et autres astuces..., pour donner de l'attrait � votre site perso">
<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="monjavascript - Patrice ">
<meta name="identifier-url" content="http://www.monjavascript.net/">
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta name="Author" lang="fr" content="PLF">
<meta name="Location" content="LBM-FRANCE">
<meta name="Copyright" content="�PLF siteweb">
<meta name="Category" content="internet languages javascript">
<meta name="Date-Creation-yyyymmdd" content="20011101">
<meta name="Robots" content="index, follow">
<meta name="Revisit-After" content="15 days">
<link rel name="Shortcut Icon" href="http://www.monjavascript.net/favicon.ico">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="mjs.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" >
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
		
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/cours_jjs/index.php" >Cours de javascript</a><br>
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="center"> 
              <p align="center"><i><b><font color="#666666" size="3" face="Verdana, Arial, Helvetica, sans-serif">
              </font></b><font size="-1" color="#666666"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="3">                <br>
              FORMULAIRES</font></b></font></i></p>
              <p align="left"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><img src="im/fleche.gif" width="11" height="11"><a href="mailto.php">Un 
                formulaire d'envoi de mail</a>                <br>
                <br>
                <img src="im/fleche.gif" width="11" height="11"><a href="ecrivez-moi.php">Valider 
                un Formulaire d'Envoi de Mail, ou Autre</a><br>
				<br>
				<img src="im/fleche.gif" width="11" height="11"><a href="validnbre.php">Valider
                des nombres dans un formulaire</a><br>
				<br>
				<img src="im/fleche.gif" width="11" height="11"><a href="style.php">Un peu 
				de &quot;style&quot; dans vos formulaires</a><br>				
                <br>
				<img src="im/fleche.gif" width="11" height="11"><a href="validdate.php">V&eacute;rifier
				si une date est valide dans un formulaire</a><br>
				<br>
                <img src="im/fleche.gif" width="11" height="11"><a href="form_chpage.php">Un
                Formulaire avec 2 boutons de d'envoi</a><br>
                <br>
                <img src="im/fleche.gif" width="11" height="11"><a href="resultform.php">Traiter
                le r&eacute;sultat d'un formulaire</a><br>
                <br>
                <img src="im/fleche.gif" width="11" height="11"><a href="mailcach.php">Cach&eacute; votre
                adresse @mail pour emp&ecirc;cher les robots des spameurs de
                collecter votre adresse</a><br>
                <br>
                <img src="im/fleche.gif" width="11" height="11"><a href="metatag.php">Un
                g&eacute;n&eacute;rateur de Meta-Tags sur votre site</a><br>
                <br>
                <img src="im/fleche.gif" width="11" height="11"><a href="gencss.php">Un
              g&eacute;n&eacute;rateur de CSS sur votre site</a><br>
              <br>
              <img src="im/fleche.gif" width="11" height="11"><a href="annivers.php">Trouver
              le Jour de la Semaine et le Nombre de Jours Pass&eacute;s pour
              une Date</a>              </font></p>
              <p align="center"><!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
</p>
              <table width="680" border="0" align="center">
                <tr> 
                  <td valign="top" width="33%"> 
                    <table width="100%" border="0">
                      <tr> 
                        <td height="25"><div align="center">
<font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#990000"><b>Les derniers scripts</b></font>
</div></td></tr><tr><td height="25"><p><font face="Verdana, Arial, Helvetica, sans-serif" size="1" >

<img src="im/fleche.gif" width="11" height="11"><a href="style.php">Un peu de &quot;style&quot; dans vos formulaires</a><br>
<!--
<img src="im/fleche.gif" width="11" height="11"><a href="section_php/graph_sect.php">Un Graphique en Secteurs (php)</a><br>
  //-->
<img src="im/fleche.gif" width="11" height="11"><a href="validdate.php">V&eacute;rifier
si une date est valide dans un formulaire</a><br>
<img src="im/fleche.gif" width="11" height="11"><a href="ban_menu.php">Une banni&egrave;re avec un menu d&eacute;roulant</a><br>
<img src="im/fleche.gif" width="11" height="11"><a href="textdefil_2.php">Une Fen&ecirc;tre de Texte D&eacute;filant dans Votre Page</a> <br>
<img src="im/fleche.gif" width="11" height="11"><a href="cpte_rebours.php">Compte &agrave; Rebours en jours</a><br>
<img src="im/fleche.gif" width="11" height="11"><a href="memory.php">Le Jeu de Memory</a><br>
<img src="im/fleche.gif" width="11" height="11"><a href="resultform.php">Traiter le r&eacute;sultat d'un formulaire</a><br>
<img src="im/fleche.gif" width="11" height="11"><a href="nbaleat.php">Trouver un nombre al&eacute;atoire ou tirage de nombres</a><br>
</font></p></td>                       </tr>
                    </table>
                  </td>
                  <td valign="top" width="33%"> 
                    <div align="center">
                <!--Code � ins�rer jjspub --><br><br><img src="http://www.monjavascript.net/im/mjs-logo.gif" width="90" height="85" border="0" alt="Mon JavaScript  http://www.monjavascript.net">
<br><br><br><br><br><br>
&nbsp;<!--Code � ins�rer jjspub -->
                    </div>
                  </td>
                  <td valign="top" width="33%"> 
                    <table width="100%" border="0">
                      <tr> 
                        <td height="25"><div align="center">
<font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#990000"><b>Les 
plus demand&eacute;s</b></font></div>
</td></tr><tr><td height="25"><p><font face="Verdana, Arial, Helvetica, sans-serif" size="1" >
<img src="im/fleche.gif" width="11" height="11">
<a href="menu.php" >Menu D&eacute;roulant</a><br>
<img src="im/fleche.gif" width="11" height="11">
<a href="ban_menu.php" >Une banni&egrave;re avec un menu d&eacute;roulant</a><br>
<img src="im/fleche.gif" width="11" height="11">
<a href="imag_zoom.php" >Un Effet de Zoom sur une Image Au Survol de La Souris</a><br>
<img src="im/fleche.gif" width="11" height="11">
<a href="textdefil_2.php" >Une Fen&ecirc;tre de Texte D&eacute;filant dans Votre Page</a><br>
<img src="im/fleche.gif" width="11" height="11">
<a href="visionn.php">La Visionneuse d'images</a><br>
<img src="im/fleche.gif" width="11" height="11">
<a href="cpte_rebours.php" >Compte &agrave; Rebours en jours</a><br>
<img src="im/fleche.gif" width="11" height="11">
<a href="menucont.php">Un Menu Contextuel avec des Liens Internes ou Externes</a><br>
<img src="im/fleche.gif" width="11" height="11">
<a href="menuroue.php" >Un menu en Forme de Roue</a><br>
<img src="im/fleche.gif" width="11" height="11">
<a href="menux2sim.php" >Un Menu D�roulant a Deux Listes</a><br>
<img src="im/fleche.gif" width="11" height="11">
<a href="protimage.php" >Afficher une Image dans une Popup en Neutralisant le Clic Droit</a><br>
</font></p></td>    

                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              <p><i><b><font color="#666666" size="3" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;
              </font></b></i></p>
              <!--Code � ins�rer jjspub --><!-- SiteSearch Google -->
                    
                    <form method="get" action="http://www.google.fr/custom" target="google_window">
                          <table height="40" border="0" bgcolor="#9966FF">
                            <tr>
                              <td nowrap="nowrap">
                                  <div align="left">
                                    <input type="hidden" name="domains" value="www.monjavascript.net">
                                    <input type="text" name="q" size="32" maxlength="255">
                                  </div></td>

                              <td nowrap="nowrap">
                                      <input type="radio" name="sitesearch" value="" checked="checked">
                                      <font size="-1" color="#000000">Web</font> </td>
                              <td nowrap="nowrap">
                                      <input type="radio" name="sitesearch" value="www.monjavascript.net">
                                      <font size="-1" color="#000000">monjavascript
                                      </font></td>
                              <td nowrap="nowrap">
                                <div align="center"></div>
                                <div align="center">
                                  <input type="submit" name="sa" value="Recherche Google">
                                  <input type="hidden" name="client" value="pub-2085185646476169">
                                  <input type="hidden" name="forid" value="1">
                                  <input type="hidden" name="ie" value="ISO-8859-1">
                                  <input type="hidden" name="oe" value="ISO-8859-1">
                                  <input type="hidden" name="cof" value="GALT:#008000;GL:1;DIV:#9966FF;VLC:663399;AH:center;BGC:FFFFFF;LBGC:9966FF;ALC:0000FF;LC:0000FF;T:000000;GFNT:0000FF;GIMP:0000FF;LH:50;LW:158;L:http://www.monjavascript.net/im/jjs-net2.gif;S:http://www.monjavascript.net/;FORID:1">
                                  <input type="hidden" name="hl" value="fr">
                                </div></td>
                            </tr>
                          </table>
                    </form>
                        <!-- SiteSearch Google --><!--Code � ins�rer jjspub -->            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
