<html>
<head>
<title>Mon JavaScript - Une Fen&ecirc;tre de Texte D&eacute;filant</title>
<meta name="Description" lang="fr" content="Webmasters, Mon JavaScript vous propose: des scripts en javascript, mais aussi des cours de javascript, des g�n�rateurs, le multimoteur, du PHP et autres astuces..., pour donner de l'attrait � votre site web.">

<meta name="keywords" content="javascript, html, langage, programme, programmation, javascript, site, perso, script, java, astuces, programmes, texte d�filant, barre d'�tat, ins�rer favoris, heure gmt, javascript menu, script de redirection, javascript heure, javascript menu deroulant, rollover, javascript fenetre, menu d�roulant, envoyer mail, formulaire, menu javascript, mail, date, Plein Ecran, pop up">
<meta name="author" content="monjavascript - PLF">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="mjs.css" type="text/css">
<script language="JavaScript">
<!--
//PLF- http://www.monjavascript.net/
if (parent.frames.length > 0)
window.top.location.href = location.href;
//-->
</script>
</head>
<body bgcolor="#FFFFFF">
<table width="1100" border="0" align="center" bgcolor="#9966FF">
  <tr>    <td ><table width="1100" border="0" background="im/header_tile.gif">
      <tr> 
    <td width="240" ><font face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/im/mjs160x60_2.gif" alt="http://www.monjavascript.net" width="160" height="60" border="0"></a></font></td>
    <td valign="middle"> 
      	 <div align="right"><br>
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-05-06: jjshaut
google_ad_channel = "0643568426";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->
		</div>
    </td>
      </tr>
    </table></td>
  </tr>
  <tr> 
    <td> 
      <table width="1100" border="0" align="center">
        <tr> 
          <td width="162" valign="top"> 
<script language="JavaScript">
<!--
//PLF-http://www.monjavascript.net/
  function fenetreCentre(url,largeur,hauteur,options) {
  var haut=(screen.height -(hauteur+130));
  var Gauche=(screen.width-(largeur+30));
  window.open(url,"","top="+haut+",left="+Gauche+",width="+largeur+",height="+hauteur+","+options);
  }
  adfav = "'http://www.monjavascript.net/', 'Mon javascript : Programation en javascript et autres...'"
  adreco = "'http://www.monjavascript.net/recomail.htm',400,520,'menubar=no,scrollbars=yes,statusbar=no'"
  adcont = "'http://www.monjavascript.net/contact.php',600,600,'menubar=no,scrollbars=yes,statusbar=no'" 
  //-->
</script>

  
<div align="center">
  <table width="160" border="0" align="center" bordercolor="#9966FF">
    <tr><td>
    <div align="center">
	<a href="http://www.monjavascript.net"><img src="http://www.monjavascript.net/menujs/menuaccu.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><p><font size="1"><img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net">ACCUEIL</a>
	  </font></font><br>
	  
	<font size="1">
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:fenetreCentre("contact.php",600,400,"menubar=no,scrollbars=yes,statusbar=no")'>Contact</a>	<br>
	  <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/acmoteujjs.php">Rechercher </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href='javascript:window.external.addfavorite("http://www.monjavascript.net/", "Mon JavaScript : Programation en javascript et autres...")'>Ins�rez
      dans vos<br>
&nbsp; favoris</a></font> <br>
<!-- Placez cette balise o� vous souhaitez faire appara�tre le gadget Bouton +1. -->
</p>
          <div class="g-plusone" data-size="medium"></div>
          <!-- Placez cette ballise apr�s la derni�re balise Bouton +1. -->
          <script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
          </script>
</td>
    </tr></table>
    <div align="center">
		<a href="http://www.monjavascript.net/somscript.php"><img src="http://www.monjavascript.net/menujs/menuscrpt.gif" border="0" width="139" height="24"></a></div>
    <table border="1" width="160"><tr><td align="left" ><font size="1">
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somac_visit.php">ACCUEIL DES<br>&nbsp;  VISITEURS </a> <br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdat_h.php">DATE & HEURE </a><br>
      <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somtexte.php">EFFETS
    DE TEXTE </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somfenetres.php">FENETRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somform.php">FORMULAIRES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somimages.php">IMAGES </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sommenus.php">MENUS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompratique.php">PRATIQUE</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/sompopup.php">POP UP </a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/somdivers.php">DIVERS</a><br>
    <br>
    <!--
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/section_php/index.php">PHP</a>
	  //-->
		</font></td>
    </tr></table>
	
    <div align="center">  <img src="http://www.monjavascript.net/menujs/menuplus.gif" width="139" height="24"></div>
	    <table border="1" width="160"><tr><td align="left" ><font size="1">
		
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/cours_jjs/index.php" >Cours de javascript</a><br>
		<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/gencss.php" target="_blank">G�n�rer vos Fichiers<br>&nbsp; 
	
	CSS</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net/html_css/genmetatag.php" target="_blank">G�n�rer vos Meta-Tags</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/metadescp.php">Description des Balises<br>&nbsp;  Meta</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/couleurs.php">Les Codes Couleur</a> <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/math.php">L'objet Math</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/lissage.php">Lissage De Pr&ecirc;t</a><br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/li/ta.php">Tableau
	d'Amortissement</a><br>
		
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/moteur.php">un Multi-Moteurs de recherche sur Votre Site</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/mailcryp.php">Cryptez votre e-mail<br>&nbsp;  pour contrer le Spam</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.monjavascript.net/scriptcryp.php">Cryptez vos Scripts</a><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">Moteurs de recherches </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A href="http://www.monjavascript.net/acmoteu.php">R�f�rencement </A><br>
    <img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><a href="http://www.jecreemonsite.net" target="_blank" title="javascript, HTML, PHP, tout pour le webmaster">Je
    Cr&eacute;e Mon Site</a>
    <br>
	<img src="http://www.monjavascript.net/im/flechep.gif" width="7" height="7"><A HREF=http://www.editeurjavascript.com/partenaires/concours.php?id=mjs TARGET=_blank>L'�diteur JavaScript</A>
    </font></td>
    </tr></table>
	
	
	
	
	
	<br>

  <div align="center">
<!--Code � ins�rer jjspub --><script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
//2006-11-24: jjsmenu
google_ad_channel = "6413686093";
google_color_border = "9966FF";
google_color_bg = "9966FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script><!--Code � ins�rer jjspub -->




  </div>
 <table width="160" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>





<div align="center">
<a href="http://www.xiti.com/xiti.asp?s=504527" title="WebAnalytics" target="_top">
<script type="text/javascript">
<!--
Xt_param = 's=504527&p=';
try {Xt_r = top.document.referrer;}
catch(e) {Xt_r = document.referrer; }
Xt_h = new Date();
Xt_i = '<img width="39" height="25" border="0" alt="" ';
Xt_i += 'src="http://logv17.xiti.com/hit.xiti?'+Xt_param;
Xt_i += '&hl='+Xt_h.getHours()+'x'+Xt_h.getMinutes()+'x'+Xt_h.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_s=screen;Xt_i+='&r='+Xt_s.width+'x'+Xt_s.height+'x'+Xt_s.pixelDepth+'x'+Xt_s.colorDepth;}
document.write(Xt_i+'&ref='+Xt_r.replace(/[<>"]/g, '').replace(/&/g, '$')+'" title="Internet Audience">');
//-->
</script>
<noscript>
Mesure d'audience ROI statistique webanalytics par <img width="39" height="25" src="http://logv17.xiti.com/hit.xiti?s=504527&p=" alt="WebAnalytics" />
</noscript></a>
</div>

</td></tr></table>
 
  
    </td></tr>
  </table>
</div>

                
		  </td>          <td valign="top" bgcolor="#CC99FF" colspan="2"> 
            <div align="center"> 
              <p align="center"> 
                <br>
                <font face="Verdana, Arial, Helvetica, sans-serif" size="4">Une
                Fen&ecirc;tre de Texte D&eacute;filant dans Votre Page</font></p>
              <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Une
                fen&ecirc;tre o&ugrave; d&eacute;filent vos informations sous
                forme de liens, textes, images, iframes.<br>
                Chaque information 
                peut avoir un format diff&eacute;rent <br>
                (possibilit&eacute; d'ins&eacute;rer les balises
              HTML) <br>
              Le d&eacute;filement s'arr&ecirc;te au passage de la souris</font></p>
              <p align="left">

<!-- PLF - http://www.monjavascript.net/ //-->
<STYLE TYPE="text/css">
.txt_defil {font-size:11px;font-family:Verdana;color:#000000;;text-decoration:none}
.txt_defil:link {font-size:11px;font-family:Verdana;color:#FFFFFF;;text-decoration:none}
.txt_defil:visited {font-size:11px;font-family:Verdana;color:#FFFFFF;;text-decoration:none}
.txt_defil:hover {font-size:11px;font-family:Verdana;color:#FFCCFF;;text-decoration:underline}
</STYLE>
  <script language="JavaScript">  
<!--
//PLF - http://www.monjavascript.net/
var txt_defil_width  = 500; 		//largeur
var txt_defil_height = 100;			//hauteur
var txt_defil_bgcolor = '#9966FF';	//couleur de fond
var txt_defil_background = ""; 		//image de fond
var txt_defil_pause = 5000;			//Temps en milliemes de secondes 

var txt_defil_info = new Array;

txt_defil_info[3]='<div align="left"><a href="creatsite.php" CLASS=txt_defil><img src="im/mjs-minilogo.gif" width="25" height="24" border="0" align="middle"><b>Vous creez votre site ?</b></a><br>Vous trouverez sur cette page quelques adresses utiles pour vous aider � construire votre site et � le rentabiliser.</div>';
txt_defil_info[1]='<a href="memory.php" CLASS=txt_defil><div STYLE="color:#FFFF33;" align="center"><b>Le Jeu de Memory</b></div><br><div align="left"><table width="300" border="0" CLASS=txt_defil><tr><td><img src="im/memory.jpg" width="70" height="51" border="0" align="middle"></td><td>Un jeu bien connu, qui consiste � retrouver des paires dans un jeu de cartes.</td></tr></table></div></a>';
txt_defil_info[2]='<div STYLE="color:#FFFF33;" align="center"><b>Quelques liens</b></div><br><div align="left">'+
'<a href="http://www.monjavascript.net/cours_jjs/index.php" target="_blank" CLASS=txt_defil>Cours de JavaScript</a><br>'+
'<a href="http://www.i-services.net/?refid=8081" target="_blank" CLASS=txt_defil title="Avec I-Services">Services Webmasters</a> Avec I-Services<br>'+
'<a href="http://www.editeurjavascript.com/partenaires/concours.php?id=jejavascri&l=2" TARGET="_blank" CLASS=txt_defil title="EditeurJavascript">Recherche  javascript</a> avec Editeur Javascript</div>';
txt_defil_info[0]='<iframe src="textdefil_pub.php" width="480" height="70" scrolling="no" frameborder="0"></iframe>';
//-->
</script>
<script language="JavaScript" src="java/textdefil2.js"></script>
<!-- PLF - http://www.monjavascript.net/ //-->

			  
			  </p>
              <p align="left">Voir aussi <font size="2" face="Verdana, Arial, Helvetica, sans-serif">:<br>
                <a href="textdefil_1.php">Une Fen�tre de Texte D&eacute;filant
                en <strong>Continu</strong> </a><br>
                <a href="textdefil_ho_2.php">Une Fen&ecirc;tre de Texte D&eacute;filant <strong>Horizontalement</strong></a><br>
                <a href="textdefil_ho_1.php">Une Fen�tre de Texte D&eacute;filant <strong>Horizontalement</strong> et
              en <strong>Continu</strong><br>
                </a><a href="textdefil.php">Un Texte D&eacute;filant Dans Votre
                Page</a><a href="textdefil_ho_1.php">              </a></font></p>
              <p align="center">
                <!--Code � ins�rer jjspub -->
                <script type="text/javascript"><!--
google_ad_client = "pub-2085185646476169";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2006-11-23: jjscentre
google_ad_channel = "2311992272";
google_color_border = "CC99FF";
google_color_bg = "CC99FF";
google_color_link = "FFFFFF";
google_color_text = "000000";
google_color_url = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
                <!--Code � ins�rer jjspub -->
 </p>

              <p align="center"> <font color="#000099" size="4">T&eacute;l&eacute;chargez
                </font><a href="java/textdefil2.js" target="_blank"><font size="2">textdefil2.js</font></a><font color="#000099" size="4"><br>
                Transferez le sur votre site </font><br> 
                (Sous Firefox le fichier
                s'ouvre dans une page. Copiez collez dans votre &eacute;diteur
                <br>
              et enregistrez-sous textdefil2.js)</p>
              <p align="center">&nbsp;</p>
              <p align="center"><font size="4" color="#000099" face="Verdana, Arial, Helvetica, sans-serif">Ins&eacute;rez
                      le code ci-dessous dans votre page Web l'endroit<br>
                o&ugrave; vous souhaitez installer la fen&ecirc;tre de
                      texte</font><font color="#000099" size="+1"> 
                            </font><font size="4" color="#000099" face="Verdana, Arial, Helvetica, sans-serif">et
                  corrigez le comme suit</font></p>
              <br>
              <table width="680" border="1" bordercolorlight="#000000" bgcolor="#CCCCCC" align="center">
                <tr> 
                  <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&lt;!--
                      PLF - http://www.monjavascript.net/ //--&gt;<br>
&lt;STYLE TYPE=&quot;text/css&quot;&gt;<br>
                    .txt_defil {font-size:11px;font-family:Verdana;color:#000000;;text-decoration:none}<br>
                    .txt_defil:link {font-size:11px;font-family:Verdana;color:#FFFFFF;;text-decoration:none}<br>
                    .txt_defil:visited {font-size:11px;font-family:Verdana;color:#FFFFFF;;text-decoration:none}<br>
                    .txt_defil:hover {font-size:11px;font-family:Verdana;color:#FFCCFF;;text-decoration:underline}<br>
&lt;/STYLE&gt;<br>
&lt;script language=&quot;JavaScript&quot;&gt; <br>
&lt;!--<br>
//PLF - http://www.monjavascript.net/<br>
var txt_defil_width = 450;	//largeur<br>
var txt_defil_height = 100;	//hauteur<br>
var txt_defil_bgcolor = '#9966FF';	//couleur de fond<br>
var txt_defil_background = &quot;&quot;;	//image de fond<br>
var txt_defil_pause = 5000;	//Temps en milliemes de secondes
</font><font face="Verdana, Arial, Helvetica, sans-serif"><font face="Verdana, Arial, Helvetica, sans-serif"><p><font size="1">var txt_defil_info = new Array;</font></p>
                  </font></font>                    <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">txt_defil_info[0]='&lt;a href=&quot;page1.htm&quot; CLASS=txt_defil&gt;lien1&lt;/a&gt; texte
  1';<br>
  txt_defil_info[1]='&lt;a href=&quot;page2.htm&quot; CLASS=txt_defil&gt;lien2&lt;/a&gt; texte
  2';<br>
  txt_defil_info[2]='&lt;a href=&quot;page3.htm&quot; CLASS=txt_defil&gt;lien3&lt;/a&gt; texte
  3';<br>
  txt_defil_info[3]='&lt;iframe src=&quot;mon_iframe.htm&quot; width=&quot;468&quot; height=&quot;60&quot; scrolling=&quot;no&quot; frameborder=&quot;0&quot;&gt;&lt;/iframe&gt;';<br>
  txt_defil_info[4]='&lt;a href=&quot;http://www.monjavascript.net&quot; target=&quot;_blank&quot; CLASS=txt_defil&gt; Mon javascript&lt;/a&gt;&lt;br&gt;'+<br>
  '&lt;a href=&quot;http://www.monjavascript.net&quot; target=&quot;_blank&quot; CLASS=txt_defil&gt; Mon javascript&lt;/a&gt;&lt;br&gt;'+<br>
  '&lt;a href=&quot;http://www.monjavascript.net&quot; target=&quot;_blank&quot; CLASS=txt_defil&gt; Mon javascript&lt;/a&gt;&lt;br&gt;';<br>
  //--&gt;<br>
&lt;/script&gt;<br>
&lt;script language=&quot;JavaScript&quot; src=&quot;textdefil2.js&quot;&gt;&lt;/script&gt;<br>
&lt;!-- PLF - http://www.monjavascript.net/ //--&gt;</font><br>
</p></td>
                </tr>
                <tr> 
                  <td bgcolor="#FFFFFF"><p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&lt;STYLE TYPE=&quot;text/css&quot;&gt; <font color="#0000FF">Indiquez
                    le format de votre texte</font><br>
                    .txt_defil format <font color="#0000FF">texte simple</font><br>
  .txt_defil:link <font color="#0000FF">format des liens</font><br>
  .txt_defil:visited <font color="#0000FF">format des liens d&eacute;j&agrave; visit&eacute;s </font><br>
  .txt_defil:hover <font color="#0000FF">format des liens au passage de la souris</font></font></p>
                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">var txt_defil_width = 450;	<font color="#0000FF">largeur
                      de la fen&ecirc;tre</font><br>
var txt_defil_height = 100;	<font color="#0000FF">hauteur de la fen&ecirc;tre</font><br>
var txt_defil_bgcolor = '#9966FF';	<font color="#0000FF">couleur de fond</font><br>
var txt_defil_background = &quot;&quot;; <font color="#0000FF">image de fond
(vide dans l'exemple)</font><br>
var txt_defil_pause = 5000;	<font color="#0000FF">Temps entre chaque infos en milliemes de secondes</font> </font></p>
                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">txt_defil_info<font color="#FF00FF">[0]</font>='<font color="#FF0000">&lt;a
                      href=&quot;page1.htm&quot; CLASS=txt_defil&gt;</font></font><font color="#0000FF" size="1" face="Verdana, Arial, Helvetica, sans-serif">lien1</font><font color="#FF0000" size="1" face="Verdana, Arial, Helvetica, sans-serif">&lt;/a&gt;</font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> texte
                  1';<br>
                  <font color="#FF00FF">n&deg; de l'information ( indice
                      du tableau txt_defil_info, commence &agrave; 0)</font><br>
                      <font color="#FF0000">liens page1.htm &eacute;tant la page &agrave; ouvrir </font><br>
                      <font color="#0000FF">Texte de votre lien</font></font></p>
                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
  txt_defil_info[3]='&lt;iframe src=&quot;mon_iframe.htm&quot; width=&quot;468&quot; height=&quot;60&quot; scrolling=&quot;no&quot; frameborder=&quot;0&quot;&gt;&lt;/iframe&gt;';<br>
                      Ici l'iformation est dans une iframe.<font color="#000099"> </font><a href="http://www.google.fr/search?hl=fr&q=iframe&btnG=Recherche%2BGoogle&meta=lr=lang_fr" target="_blank"><img src="im/interro.jpg" width="13" height="17" border="0"></a>  Lors
                      de vos test pensez &agrave; indiquer une page existante, pour
                      ne pas &ecirc;tre redirig&eacute; sur une page Erreur 404.<br>
                      L'Utilisation
                      d'une iframe peut servir &agrave; afficher vos pubs<br> 
                    ex: les emplacement rotatifs de  <a href="http://www.netaffiliation.com/direct.php?mclic=S2B241AE0121" title="plateforme affiliation pour webmaster regie pub" target="_blank"><font color="#0000FF">NetAffiliation</font></a></font></p>
                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
  txt_defil_info[4]='&lt;a href=&quot;http://www.monjavascript.net&quot;  CLASS=txt_defil&gt; Mon javascript&lt;/a&gt;&lt;br&gt;<font color="#0000FF">'+</font><br>
                    <font color="#0000FF">'</font>&lt;a href=&quot;http://www.monjavascript.net&quot; target=&quot;_blank&quot; CLASS=txt_defil&gt; Mon javascript&lt;/a&gt;&lt;br&gt;<font color="#0000FF">'+</font><br>
<font color="#0000FF">'</font>&lt;a href=&quot;http://www.monjavascript.net&quot; target=&quot;_blank&quot; CLASS=txt_defil&gt; Mon javascript&lt;/a&gt;&lt;br&gt;';<br>
                      <br>
                      Si votre ligne est trop longue vous pouvez revenir &agrave; la
                      ligne avec le signe <strong><font color="#0000FF">+</font></strong> (n'oubliez pas le<font color="#0000FF"> ' </font>en d&eacute;but et fin
                      de ligne)<br>
                    </font></p>
                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
  Vous pouvez utiliser les balises HTML pour ins&eacute;rer des images, des tableaux,
                      ou mettre en forme le texte de toute 
                    ou partie de votre info.<br>
                      <br>
                      txt_defil_info[1]='&lt;a href=&quot;fic.htm&quot; CLASS=txt_defil&gt;&lt;div
                      STYLE=&quot;color:#FFFF33;&quot; '+<br>
                      '
                      align=&quot;center&quot;&gt;&lt;b&gt;Le
                      Jeu de Memory&lt;/b&gt;&lt;/div&gt;&lt;br&gt;&lt;div align=&quot;left&quot;&gt;'+<br>
                      '&lt;                      table
                      width=&quot;300&quot; border=&quot;0&quot; CLASS=txt_defil&gt;&lt;tr&gt;&lt;td&gt;&lt;img
                      src=&quot;imag.jpg&quot; width=&quot;70&quot;'+<br>
                      ' 
                      height=&quot;51&quot; border=&quot;0&quot; align=&quot;middle&quot;&gt;&lt;/td&gt;&lt;td&gt;votre
                      texte.&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/div&gt;&lt;/a&gt;';</font><br>
                      <br>
                      <br>
                  </p></td>
                </tr>
              </table>
              <p align="center">&nbsp;</p>
              <p align="center"> </p>
              <p align="center"><a href="fairelien.php">Ce site vous a plu ?
                  Vous avez trouv&eacute; le script que vous cherchiez ?<br>
                  Faites en profiter vos visiteurs : ins&eacute;rez un lien sur
                  votre site</a></p>
            </div>
          </td>
          <td width="6" valign="top">
            <div align="center">
<table width="6" border="0" align="center" bordercolor="#9966FF">
<tr><td>

    <div align="center">	</div>
    <div align="center">  </div>
<div align="center"></div>
<div align="center">&nbsp;</div>

</td></tr></table>
            </div>
          </td>
        </tr>
        <tr valign="middle"> 
          <td>&nbsp;</td>
          <td align="center">


                  <table border="0" cellspacing="0" width="700">
                    <tr bordercolor="#00CCFF"> 
                      <td width="280">
					  <div align="center">
<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href='http://www.jecreemonsite.net/php/jcmscompteur.php'>Il y a 3 Visiteurs</a> sur <a href='http://www.monjavascript.net'>Mon JavaScript</a><noscript><a href="http://www.jecreemonsite.net/">javascript php html</a></noscript>
</font>					  </div></td>
                      <td><div align="center">
					  
					   <img src="http://www.monjavascript.net/im/mjs-minilogo.gif"></div></td>
                      <td width="280"> 
                      <div align="center"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.monjavascript.net">Mon javascript</a> </font>
					  &nbsp;&nbsp;<font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">
              10-08-2015          
			  </font>
					  </div>
                      </td>
                    </tr>
                    <tr align="center"> 
                      <td bgcolor="#003399" height="2" colspan="2"></td>
                      <td bgcolor="#003399" height="2"></td>
                    </tr>
                  </table>
				  <br>

          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
